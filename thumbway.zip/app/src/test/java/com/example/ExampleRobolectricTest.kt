package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.ChatMessageType
import com.example.data.local.SpotType
import com.example.data.local.ThumbWayDatabase
import com.example.data.local.TravelerLevelSystem
import com.example.data.local.TravelerRank
import com.example.data.local.UserPreferencesDataStore
import com.example.data.location.GeoMeasurementHelper
import com.example.data.location.RouteStop
import com.example.data.remote.OpenMeteoCurrent
import com.example.data.remote.OpenMeteoHourly
import com.example.data.remote.OpenMeteoResponse
import com.example.data.remote.WeatherRepository
import com.example.data.remote.WeatherSeverity
import com.example.data.repository.ThumbWayRepository
import com.example.ui.i18n.AppLanguage
import com.example.ui.i18n.stringsFor
import com.example.ui.i18n.titleFor
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.runTest
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    private lateinit var context: Context
    private lateinit var db: ThumbWayDatabase
    private lateinit var repository: ThumbWayRepository

    @Before
    fun setUp() {
        context = ApplicationProvider.getApplicationContext()
        db = Room.inMemoryDatabaseBuilder(context, ThumbWayDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        repository = ThumbWayRepository(db.dao(), UserPreferencesDataStore(context))
    }

    @After
    fun tearDown() {
        db.close()
    }

    @Test
    fun `read string from context`() {
        val appName = context.getString(R.string.app_name)
        assertEquals("ThumbWay", appName)
    }

    @Test
    fun `create profile login update password and manage notes and posts`() = runTest {
        repository.ensureSeeded()

        val created = repository.createProfile(
            username = "hiker_ali",
            displayName = "Ali Yilmaz",
            password = "secret123",
            aboutUs = "Exploring coastal highways",
            avatarUri = null,
            lat = 37.42,
            lng = -122.08
        ).getOrThrow()

        assertTrue(repository.login("hiker_ali", "secret123").isSuccess)
        assertTrue(repository.login("hiker_ali", "wrong").isFailure)

        assertTrue(repository.updatePassword(created.id, "secret123", "newpass456").isSuccess)
        assertTrue(repository.login("hiker_ali", "newpass456").isSuccess)

        repository.addMapNote(
            author = created,
            title = "Quiet layby",
            noteText = "Good visibility for drivers",
            spotType = SpotType.ROADSIDE,
            latitude = 37.421,
            longitude = -122.081,
            locationLabel = "Hwy 101 Shoulder",
            photoUri = null
        )
        val notes = repository.allMapNotes.first()
        val myNote = notes.first { it.authorId == created.id }
        assertEquals("Quiet layby", myNote.title)

        repository.dismissNoteBubble(created.id, myNote.id)
        val dismissed = repository.dismissedNoteIds.first()
        assertTrue(myNote.id in dismissed)

        repository.createPost(
            author = created,
            caption = "Made it north!",
            photoUri = null,
            locationName = "Bayshore Exit",
            latitude = 37.42,
            longitude = -122.08
        )
        val post = repository.allPosts.first().first { it.authorId == created.id }
        repository.toggleSavePost(created.id, post.id, currentlySaved = false)
        assertTrue(post.id in repository.savedPostIds.first())

        repository.blockUser(created.id, "seed_maya")
        assertTrue("seed_maya" in repository.blockedIds.first())
        assertFalse("seed_maya" in repository.followedIds.first())
    }

    @Test
    fun `geo measurement calculates distance bearing and estimates`() {
        val result = GeoMeasurementHelper.measure(
            fromLat = 37.421999,
            fromLng = -122.084057,
            toLat = 37.431000,
            toLng = -122.084057
        )
        assertTrue(result.distanceMeters in 990.0..1015.0)
        assertEquals("N", result.compassDirection)
        assertTrue(result.walkMinutes in 11..14)
        assertEquals("1.00 km", result.metricFormatted)
        assertTrue(result.milesFormatted.endsWith("mi"))
    }

    @Test
    fun `multi-stop travel route calculates legs and persists in room`() = runTest {
        repository.ensureSeeded()
        val created = repository.createProfile(
            username = "route_tester",
            displayName = "Route Tester",
            password = "secret123",
            aboutUs = "Testing multi-stop routes",
            avatarUri = null,
            lat = 37.42,
            lng = -122.08
        ).getOrThrow()

        val stops = listOf(
            RouteStop("s1", "Shoreline Ramp", 37.421999, -122.084057),
            RouteStop("s2", "Halfway Diner", 37.431000, -122.084057),
            RouteStop("s3", "North Junction", 37.440000, -122.084057)
        )
        val summary = GeoMeasurementHelper.measureRoute(stops)
        assertEquals(2, summary.legs.size)
        assertTrue(summary.totalDistanceMeters in 1980.0..2030.0)
        assertTrue(summary.totalRideMinutes >= 22)

        val saved = repository.saveTravelRoute(created.id, null, "North Coast Hitch", stops).getOrThrow()
        val routes = repository.savedRoutes.first()
        assertEquals(1, routes.size)
        assertEquals("North Coast Hitch", routes.first().title)
        assertEquals(3, GeoMeasurementHelper.decodeStops(routes.first().stopsJson).size)

        repository.deleteTravelRoute(saved.id)
        assertTrue(repository.savedRoutes.first().isEmpty())
    }

    @Test
    fun `friend chat sends text photo video and audio messages and persists in room`() = runTest {
        repository.ensureSeeded()
        val created = repository.createProfile(
            username = "chat_tester",
            displayName = "Chat Tester",
            password = "secret123",
            aboutUs = "Testing friend chat",
            avatarUri = null,
            lat = 37.42,
            lng = -122.08
        ).getOrThrow()

        // Blank text fails validation
        assertTrue(
            repository.sendChatMessage(
                senderId = created.id,
                recipientId = "seed_maya",
                type = ChatMessageType.TEXT,
                text = "   "
            ).isFailure
        )

        val textMsg = repository.sendChatMessage(
            senderId = created.id,
            recipientId = "seed_maya",
            type = ChatMessageType.TEXT,
            text = "Hey Maya, safe spot near Shoreline?"
        ).getOrThrow()

        repository.sendChatMessage(
            senderId = created.id,
            recipientId = "seed_maya",
            type = ChatMessageType.PHOTO,
            mediaUri = "file:///photos/img_1.jpg"
        ).getOrThrow()

        repository.sendChatMessage(
            senderId = created.id,
            recipientId = "seed_maya",
            type = ChatMessageType.VIDEO,
            mediaUri = "file:///media/vid_1.mp4",
            durationMs = 8_500L
        ).getOrThrow()

        val audioMsg = repository.sendChatMessage(
            senderId = "seed_maya",
            recipientId = created.id,
            type = ChatMessageType.AUDIO,
            mediaUri = "file:///audio/voice_1.m4a",
            durationMs = 4_200L
        ).getOrThrow()

        val conversation = repository.observeConversation(created.id, "seed_maya").first()
        assertEquals(4, conversation.size)
        assertEquals(ChatMessageType.TEXT.code, conversation[0].type)
        assertEquals(ChatMessageType.PHOTO.code, conversation[1].type)
        assertEquals(ChatMessageType.VIDEO.code, conversation[2].type)
        assertEquals(8_500L, conversation[2].durationMs)
        assertEquals(ChatMessageType.AUDIO.code, conversation[3].type)
        assertEquals(4_200L, conversation[3].durationMs)

        repository.deleteChatMessage(textMsg.id)
        val afterDelete = repository.observeConversation(created.id, "seed_maya").first()
        assertEquals(3, afterDelete.size)
        assertFalse(afterDelete.any { it.id == textMsg.id })
        assertTrue(afterDelete.any { it.id == audioMsg.id })
    }

    @Test
    fun `sos emergency contacts persist and distress signal includes coordinates`() = runTest {
        repository.ensureSeeded()
        val created = repository.createProfile(
            username = "sos_tester",
            displayName = "SOS Tester",
            password = "secret123",
            aboutUs = "Safety testing",
            avatarUri = null,
            lat = 37.421999,
            lng = -122.084057
        ).getOrThrow()

        val phoneContact = repository.addEmergencyContact(
            ownerId = created.id,
            name = "Mom",
            phoneNumber = "+15551234567"
        ).getOrThrow()

        val friendContact = repository.addEmergencyContact(
            ownerId = created.id,
            name = "Maya Lin",
            phoneNumber = "",
            linkedFriendId = "seed_maya"
        ).getOrThrow()

        val contacts = repository.emergencyContacts.first()
        assertEquals(2, contacts.size)

        val distress = ThumbWayRepository.buildSosDistressMessage(
            sender = created,
            latitude = 37.421999,
            longitude = -122.084057,
            localityLabel = "Shoreline Hwy",
            customNote = "Flat tire on shoulder"
        )
        assertTrue(distress.contains("37.42200, -122.08406"))
        assertTrue(distress.contains("Flat tire on shoulder"))
        assertTrue(distress.contains("https://maps.google.com/?q=37.42200, -122.08406"))

        val dispatched = repository.dispatchInAppSos(
            senderId = created.id,
            recipientFriendIds = listOfNotNull(friendContact.linkedFriendId),
            distressMessage = distress
        )
        assertEquals(1, dispatched)

        val mayaThread = repository.observeConversation(created.id, "seed_maya").first()
        assertEquals(1, mayaThread.size)
        assertTrue(mayaThread.first().text.contains("SOS DISTRESS SIGNAL"))

        repository.removeEmergencyContact(phoneContact.id)
        assertEquals(1, repository.emergencyContacts.first().size)
    }

    @Test
    fun `weather overlay mapping interprets WMO codes hourly forecast and hitch advisories`() {
        val rainyResponse = OpenMeteoResponse(
            latitude = 37.42,
            longitude = -122.08,
            current = OpenMeteoCurrent(
                temperature2m = 14.5,
                apparentTemperature = 12.2,
                precipitation = 3.4,
                rain = 3.4,
                weatherCode = 63,
                windSpeed10m = 28.0,
                isDay = 1
            ),
            hourly = OpenMeteoHourly(
                time = listOf("2026-11-14T14:00", "2026-11-14T15:00", "2026-11-14T16:00"),
                temperature2m = listOf(14.5, 14.0, 13.5),
                precipitationProbability = listOf(80, 70, 50),
                weatherCode = listOf(63, 61, 3)
            )
        )

        val overlay = WeatherRepository.mapToOverlay(
            id = "w_1",
            label = "1. Shoreline Ramp",
            lat = 37.42,
            lng = -122.08,
            response = rainyResponse
        )

        assertEquals("Rain", overlay.conditionLabel)
        assertEquals(WeatherSeverity.CAUTION, overlay.severity)
        assertTrue(overlay.hitchAdvisory.contains("Wet weather"))
        assertEquals(2, overlay.nextHours.size)
        assertEquals("14:00", overlay.nextHours.first().timeLabel)

        val storm = WeatherRepository.interpretWmoCode(95)
        assertEquals("Thunderstorm", storm.first)
        assertEquals(WeatherSeverity.SEVERE, storm.second)
    }

    @Test
    fun `traveler level system evaluates all rank thresholds and progress accurately`() {
        val cases = listOf(
            0 to TravelerRank.STARTER,
            9 to TravelerRank.STARTER,
            10 to TravelerRank.NOVICE_TRAVELER,
            19 to TravelerRank.NOVICE_TRAVELER,
            20 to TravelerRank.SEASONED_TRAVELER,
            29 to TravelerRank.SEASONED_TRAVELER,
            30 to TravelerRank.ROAD_ENTHUSIAST,
            39 to TravelerRank.ROAD_ENTHUSIAST,
            40 to TravelerRank.MASTER_OF_ROAD,
            49 to TravelerRank.MASTER_OF_ROAD,
            50 to TravelerRank.ADVENTURER,
            59 to TravelerRank.ADVENTURER,
            60 to TravelerRank.EVLIYA_CELEBI,
            85 to TravelerRank.EVLIYA_CELEBI
        )

        cases.forEach { (posts, expectedRank) ->
            val progress = TravelerLevelSystem.evaluate(posts)
            assertEquals("Failed for post count $posts", expectedRank, progress.rank)
        }

        val halfway = TravelerLevelSystem.evaluate(15)
        assertEquals(TravelerRank.NOVICE_TRAVELER, halfway.rank)
        assertEquals(TravelerRank.SEASONED_TRAVELER, halfway.nextRank)
        assertEquals(5, halfway.postsRemainingForNext)
        assertEquals(0.5f, halfway.progressToNext, 0.001f)
        assertEquals(0.25f, halfway.overallScaleFraction, 0.001f)

        val legend = TravelerLevelSystem.evaluate(60)
        assertEquals(TravelerRank.EVLIYA_CELEBI, legend.rank)
        assertNull(legend.nextRank)
        assertEquals(0, legend.postsRemainingForNext)
        assertEquals(1f, legend.progressToNext, 0.001f)
        assertEquals(1f, legend.overallScaleFraction, 0.001f)

        val enStrings = stringsFor(AppLanguage.EN)
        assertEquals("Novice Traveler", enStrings.titleFor(TravelerRank.NOVICE_TRAVELER))
        assertEquals("Seasoned Traveler", enStrings.titleFor(TravelerRank.SEASONED_TRAVELER))
        assertEquals("Road Enthusiast", enStrings.titleFor(TravelerRank.ROAD_ENTHUSIAST))
        assertEquals("Master of the Road", enStrings.titleFor(TravelerRank.MASTER_OF_ROAD))
        assertEquals("Adventurer", enStrings.titleFor(TravelerRank.ADVENTURER))
        assertEquals("Evliya Çelebi", enStrings.titleFor(TravelerRank.EVLIYA_CELEBI))
    }
}

