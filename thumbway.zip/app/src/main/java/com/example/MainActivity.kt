package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.navigation.ThumbWayAppRoot
import com.example.ui.theme.ThumbWayTheme
import com.example.ui.viewmodel.ThumbWayViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val viewModel: ThumbWayViewModel = viewModel()
            val uiState by viewModel.uiState.collectAsStateWithLifecycle()
            ThumbWayTheme(themeMode = uiState.themeMode) {
                ThumbWayAppRoot(
                    uiState = uiState,
                    viewModel = viewModel
                )
            }
        }
    }
}
