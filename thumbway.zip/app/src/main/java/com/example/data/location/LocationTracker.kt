package com.example.data.location

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Geocoder
import android.os.Build
import android.os.Looper
import androidx.core.content.ContextCompat
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationResult
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.Locale

data class LiveLocationState(
    val latitude: Double = 37.4220,
    val longitude: Double = -122.0841,
    val accuracyMeters: Float = 0f,
    val speedKmh: Float = 0f,
    val hasRealFix: Boolean = false,
    val localityLabel: String = "Syncing GPS...",
    val tsmLatitude: Double = 37.4220,
    val tsmLongitude: Double = -122.0841,
    val tsmLabel: String = "TSM Spot Ready",
    val updatedAt: Long = System.currentTimeMillis()
)

class LocationTracker(private val context: Context) {
    private val fusedClient: FusedLocationProviderClient =
        LocationServices.getFusedLocationProviderClient(context)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val _locationState = MutableStateFlow(LiveLocationState())
    val locationState: StateFlow<LiveLocationState> = _locationState.asStateFlow()

    private var isTracking = false

    private val locationCallback = object : LocationCallback() {
        override fun onLocationResult(result: LocationResult) {
            val loc = result.lastLocation ?: return
            val speedKmh = if (loc.hasSpeed()) loc.speed * 3.6f else 0f
            val previous = _locationState.value
            val tsmLat = if (!previous.hasRealFix) loc.latitude else previous.tsmLatitude
            val tsmLng = if (!previous.hasRealFix) loc.longitude else previous.tsmLongitude
            _locationState.value = previous.copy(
                latitude = loc.latitude,
                longitude = loc.longitude,
                accuracyMeters = loc.accuracy,
                speedKmh = speedKmh,
                hasRealFix = true,
                tsmLatitude = tsmLat,
                tsmLongitude = tsmLng,
                updatedAt = System.currentTimeMillis()
            )
            resolveAddress(loc.latitude, loc.longitude)
        }
    }

    fun hasLocationPermission(): Boolean {
        val fine = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
        val coarse = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.ACCESS_COARSE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
        return fine || coarse
    }

    @SuppressLint("MissingPermission")
    fun startUpdates() {
        if (!hasLocationPermission() || isTracking) return
        isTracking = true

        fusedClient.lastLocation.addOnSuccessListener { loc ->
            if (loc != null) {
                _locationState.value = _locationState.value.copy(
                    latitude = loc.latitude,
                    longitude = loc.longitude,
                    accuracyMeters = loc.accuracy,
                    hasRealFix = true,
                    tsmLatitude = loc.latitude,
                    tsmLongitude = loc.longitude,
                    updatedAt = System.currentTimeMillis()
                )
                resolveAddress(loc.latitude, loc.longitude)
            }
        }

        val request = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 4000L)
            .setMinUpdateIntervalMillis(2000L)
            .setMinUpdateDistanceMeters(3f)
            .build()

        fusedClient.requestLocationUpdates(
            request,
            locationCallback,
            Looper.getMainLooper()
        )
    }

    fun stopUpdates() {
        if (!isTracking) return
        isTracking = false
        fusedClient.removeLocationUpdates(locationCallback)
    }

    fun syncTsmToCurrent(): LiveLocationState {
        val current = _locationState.value
        val updated = current.copy(
            tsmLatitude = current.latitude,
            tsmLongitude = current.longitude,
            tsmLabel = if (current.localityLabel.isNotBlank() && current.localityLabel != "Syncing GPS...") {
                "TSM • ${current.localityLabel}"
            } else {
                "TSM • ${"%.4f".format(Locale.US, current.latitude)}, ${"%.4f".format(Locale.US, current.longitude)}"
            },
            updatedAt = System.currentTimeMillis()
        )
        _locationState.value = updated
        return updated
    }

    fun updateTsmPoint(lat: Double, lng: Double, label: String? = null): LiveLocationState {
        val current = _locationState.value
        val updated = current.copy(
            tsmLatitude = lat,
            tsmLongitude = lng,
            tsmLabel = label ?: "TSM • ${"%.4f".format(Locale.US, lat)}, ${"%.4f".format(Locale.US, lng)}",
            updatedAt = System.currentTimeMillis()
        )
        _locationState.value = updated
        return updated
    }

    private fun resolveAddress(lat: Double, lng: Double) {
        scope.launch {
            try {
                if (!Geocoder.isPresent()) return@launch
                val geocoder = Geocoder(context, Locale.getDefault())
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    geocoder.getFromLocation(lat, lng, 1) { addresses ->
                        val addr = addresses.firstOrNull()
                        val label = listOfNotNull(
                            addr?.thoroughfare,
                            addr?.locality ?: addr?.subAdminArea
                        ).distinct().joinToString(", ")
                        if (label.isNotBlank()) {
                            val curr = _locationState.value
                            _locationState.value = curr.copy(
                                localityLabel = label,
                                tsmLabel = if (curr.tsmLabel == "TSM Spot Ready") "TSM • $label" else curr.tsmLabel
                            )
                        }
                    }
                } else {
                    @Suppress("DEPRECATION")
                    val addr = geocoder.getFromLocation(lat, lng, 1)?.firstOrNull()
                    val label = listOfNotNull(
                        addr?.thoroughfare,
                        addr?.locality ?: addr?.subAdminArea
                    ).distinct().joinToString(", ")
                    if (label.isNotBlank()) {
                        val curr = _locationState.value
                        _locationState.value = curr.copy(
                            localityLabel = label,
                            tsmLabel = if (curr.tsmLabel == "TSM Spot Ready") "TSM • $label" else curr.tsmLabel
                        )
                    }
                }
            } catch (_: Exception) {
                // Geocoder unavailable on device or offline; keep coordinate fallback
            }
        }
    }
}
