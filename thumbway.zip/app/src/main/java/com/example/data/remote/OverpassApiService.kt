package com.example.data.remote

import com.squareup.moshi.JsonClass
import retrofit2.http.Field
import retrofit2.http.FormUrlEncoded
import retrofit2.http.POST

@JsonClass(generateAdapter = true)
data class OverpassResponse(
    val elements: List<OverpassElement> = emptyList()
)

@JsonClass(generateAdapter = true)
data class OverpassElement(
    val id: Long = 0L,
    val lat: Double? = null,
    val lon: Double? = null,
    val center: OverpassCenter? = null,
    val tags: Map<String, String>? = null
)

@JsonClass(generateAdapter = true)
data class OverpassCenter(
    val lat: Double = 0.0,
    val lon: Double = 0.0
)

interface OverpassApiService {
    @FormUrlEncoded
    @POST("api/interpreter")
    suspend fun queryNearbyPlaces(
        @Field("data") query: String
    ): OverpassResponse
}
