package com.example.data.local

import java.time.Instant
import java.time.ZoneId

enum class MilestoneBadgeId {
    FIRST_100KM,
    NIGHT_TRAVELER,
    SPOT_SCOUT,
    ROUTE_PIONEER,
    ROAD_CHRONICLER,
    TRAIL_ALLY,
    ROADSIDE_VOICE,
    DAWN_CATCHER
}

data class MilestoneBadgeStatus(
    val id: MilestoneBadgeId,
    val isUnlocked: Boolean,
    val currentValue: Int,
    val targetValue: Int,
    val unitSuffix: String = ""
) {
    val progressFraction: Float
        get() = if (targetValue <= 0) 1f else (currentValue.toFloat() / targetValue.toFloat()).coerceIn(0f, 1f)
}

object TravelMilestoneEvaluator {
    const val FIRST_100KM_METERS = 100_000.0

    fun evaluateForUser(
        userId: String,
        posts: List<PostEntity>,
        mapNotes: List<MapNoteEntity>,
        savedRoutes: List<TravelRouteEntity>,
        followedCount: Int,
        chatMessages: List<ChatMessageEntity>,
        zoneId: ZoneId = ZoneId.systemDefault()
    ): List<MilestoneBadgeStatus> {
        val userPosts = posts.filter { it.authorId == userId }
        val userNotes = mapNotes.filter { it.authorId == userId }
        val userRoutes = savedRoutes.filter { it.ownerId == userId }

        val totalRouteKm = (userRoutes.sumOf { it.totalDistanceMeters } / 1000.0).toInt().coerceAtLeast(0)

        val allTimestamps = userPosts.map { it.createdAt } +
            userNotes.map { it.createdAt } +
            userRoutes.map { it.createdAt }

        val nightActivityCount = allTimestamps.count { ts ->
            val hour = Instant.ofEpochMilli(ts).atZone(zoneId).hour
            hour >= 20 || hour < 5
        }

        val dawnActivityCount = allTimestamps.count { ts ->
            val hour = Instant.ofEpochMilli(ts).atZone(zoneId).hour
            hour in 5..8
        }

        val photoShareCount = userPosts.count { !it.photoUri.isNullOrBlank() } +
            userNotes.count { !it.photoUri.isNullOrBlank() }

        val mediaChatCount = chatMessages.count { msg ->
            msg.senderId == userId && ChatMessageType.fromCode(msg.type) != ChatMessageType.TEXT
        }

        return listOf(
            MilestoneBadgeStatus(
                id = MilestoneBadgeId.FIRST_100KM,
                isUnlocked = totalRouteKm >= 100,
                currentValue = totalRouteKm.coerceAtMost(100),
                targetValue = 100,
                unitSuffix = "km"
            ),
            MilestoneBadgeStatus(
                id = MilestoneBadgeId.NIGHT_TRAVELER,
                isUnlocked = nightActivityCount >= 1,
                currentValue = nightActivityCount.coerceAtMost(1),
                targetValue = 1
            ),
            MilestoneBadgeStatus(
                id = MilestoneBadgeId.SPOT_SCOUT,
                isUnlocked = userNotes.isNotEmpty(),
                currentValue = userNotes.size.coerceAtMost(1),
                targetValue = 1
            ),
            MilestoneBadgeStatus(
                id = MilestoneBadgeId.ROUTE_PIONEER,
                isUnlocked = userRoutes.isNotEmpty(),
                currentValue = userRoutes.size.coerceAtMost(1),
                targetValue = 1
            ),
            MilestoneBadgeStatus(
                id = MilestoneBadgeId.ROAD_CHRONICLER,
                isUnlocked = photoShareCount >= 1,
                currentValue = photoShareCount.coerceAtMost(1),
                targetValue = 1
            ),
            MilestoneBadgeStatus(
                id = MilestoneBadgeId.TRAIL_ALLY,
                isUnlocked = followedCount >= 2,
                currentValue = followedCount.coerceAtMost(2),
                targetValue = 2
            ),
            MilestoneBadgeStatus(
                id = MilestoneBadgeId.ROADSIDE_VOICE,
                isUnlocked = mediaChatCount >= 1,
                currentValue = mediaChatCount.coerceAtMost(1),
                targetValue = 1
            ),
            MilestoneBadgeStatus(
                id = MilestoneBadgeId.DAWN_CATCHER,
                isUnlocked = dawnActivityCount >= 1 || userPosts.size >= 5,
                currentValue = if (dawnActivityCount >= 1) 1 else userPosts.size.coerceAtMost(5),
                targetValue = if (dawnActivityCount >= 1) 1 else 5
            )
        )
    }
}
