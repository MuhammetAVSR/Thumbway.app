package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class SpotType(val code: String) {
    ROADSIDE("ROADSIDE"),
    BUSINESS("BUSINESS"),
    OPEN_SPACE("OPEN_SPACE"),
    SAFE_SPOT("SAFE_SPOT");

    companion object {
        fun fromCode(code: String): SpotType =
            entries.firstOrNull { it.code == code } ?: ROADSIDE
    }
}

@Entity(tableName = "users")
data class UserEntity(
    @PrimaryKey val id: String,
    val username: String,
    val displayName: String,
    val passwordHash: String,
    val aboutUs: String,
    val avatarUri: String? = null,
    val isLocationSharingEnabled: Boolean = true,
    val latitude: Double? = null,
    val longitude: Double? = null,
    val tsmLatitude: Double? = null,
    val tsmLongitude: Double? = null,
    val tsmLabel: String = "",
    val lastUpdatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "follows", primaryKeys = ["followerId", "followedId"])
data class FollowEntity(
    val followerId: String,
    val followedId: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "blocked_users", primaryKeys = ["blockerId", "blockedId"])
data class BlockedUserEntity(
    val blockerId: String,
    val blockedId: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "map_notes")
data class MapNoteEntity(
    @PrimaryKey val id: String,
    val authorId: String,
    val authorName: String,
    val authorAvatarUri: String? = null,
    val title: String,
    val noteText: String,
    val spotType: String = SpotType.ROADSIDE.code,
    val latitude: Double,
    val longitude: Double,
    val locationLabel: String = "",
    val photoUri: String? = null,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "dismissed_notes", primaryKeys = ["userId", "noteId"])
data class DismissedNoteEntity(
    val userId: String,
    val noteId: String,
    val dismissedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "community_posts")
data class PostEntity(
    @PrimaryKey val id: String,
    val authorId: String,
    val authorName: String,
    val authorAvatarUri: String? = null,
    val caption: String,
    val photoUri: String? = null,
    val locationName: String? = null,
    val latitude: Double? = null,
    val longitude: Double? = null,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "saved_posts", primaryKeys = ["userId", "postId"])
data class SavedPostEntity(
    val userId: String,
    val postId: String,
    val savedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "travel_routes")
data class TravelRouteEntity(
    @PrimaryKey val id: String,
    val ownerId: String,
    val title: String,
    val stopsJson: String,
    val totalDistanceMeters: Double,
    val estimatedRideMinutes: Int,
    val estimatedWalkMinutes: Int,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

enum class ChatMessageType(val code: String) {
    TEXT("TEXT"),
    PHOTO("PHOTO"),
    VIDEO("VIDEO"),
    AUDIO("AUDIO");

    companion object {
        fun fromCode(code: String): ChatMessageType =
            entries.firstOrNull { it.code == code } ?: TEXT
    }
}

@Entity(tableName = "chat_messages")
data class ChatMessageEntity(
    @PrimaryKey val id: String,
    val senderId: String,
    val recipientId: String,
    val type: String = ChatMessageType.TEXT.code,
    val text: String = "",
    val mediaUri: String? = null,
    val durationMs: Long = 0L,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "emergency_contacts")
data class EmergencyContactEntity(
    @PrimaryKey val id: String,
    val ownerId: String,
    val name: String,
    val phoneNumber: String = "",
    val linkedFriendId: String? = null,
    val createdAt: Long = System.currentTimeMillis()
)
