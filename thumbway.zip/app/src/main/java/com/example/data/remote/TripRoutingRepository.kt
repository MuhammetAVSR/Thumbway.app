package com.example.data.remote

import com.example.data.local.MapNoteEntity
import com.example.data.location.GeoMeasurementHelper
import com.example.data.location.RouteStop
import com.google.android.gms.maps.model.LatLng
import com.squareup.moshi.Json
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query
import java.util.UUID
import java.util.concurrent.TimeUnit
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

data class OsrmRouteGeometry(
    val coordinates: List<List<Double>> = emptyList()
)

data class OsrmLeg(
    val summary: String? = null,
    val distance: Double = 0.0,
    val duration: Double = 0.0
)

data class OsrmRouteItem(
    val geometry: OsrmRouteGeometry? = null,
    val legs: List<OsrmLeg> = emptyList(),
    val distance: Double = 0.0,
    val duration: Double = 0.0
)

data class OsrmRouteResponse(
    val code: String = "",
    val routes: List<OsrmRouteItem> = emptyList()
)

interface OsrmRoutingService {
    @GET("route/v1/driving/{coordinates}")
    suspend fun getDrivingRoute(
        @Path("coordinates", encoded = true) coordinates: String,
        @Query("overview") overview: String = "full",
        @Query("geometries") geometries: String = "geojson"
    ): OsrmRouteResponse
}

data class SuggestedTripRoute(
    val origin: RouteStop,
    val destination: RouteStop,
    val stops: List<RouteStop>,
    val pathPoints: List<LatLng>,
    val distanceMeters: Double,
    val drivingMinutes: Int,
    val hitchEstimateMinutes: Int,
    val walkMinutes: Int,
    val viaSummary: String,
    val isRealRoadGeometry: Boolean
)

class TripRoutingRepository {
    private val moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()

    private val okHttp = OkHttpClient.Builder()
        .addInterceptor { chain ->
            val req = chain.request().newBuilder()
                .header("User-Agent", "ThumbWay-Android/1.0")
                .build()
            chain.proceed(req)
        }
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .build()

    private val osrmApi: OsrmRoutingService = Retrofit.Builder()
        .baseUrl("https://router.project-osrm.org/")
        .client(okHttp)
        .addConverterFactory(MoshiConverterFactory.create(moshi))
        .build()
        .create(OsrmRoutingService::class.java)

    suspend fun calculateSuggestedRoute(
        origin: RouteStop,
        destination: RouteStop,
        preferSafeStops: Boolean,
        nearbyNotes: List<MapNoteEntity> = emptyList(),
        nearbyBusinesses: List<NearbyBusiness> = emptyList()
    ): Result<SuggestedTripRoute> = withContext(Dispatchers.IO) {
        val optionalSafeWaypoint = if (preferSafeStops) {
            findBestCorridorSafeStop(origin, destination, nearbyNotes, nearbyBusinesses)
        } else {
            null
        }

        val plannedStops = listOfNotNull(origin, optionalSafeWaypoint, destination)
        val coordsString = plannedStops.joinToString(";") { "${it.longitude},${it.latitude}" }

        try {
            val response = osrmApi.getDrivingRoute(coordinates = coordsString)
            val route = response.routes.firstOrNull()
            val rawCoords = route?.geometry?.coordinates.orEmpty()
            if (response.code.equals("Ok", ignoreCase = true) && route != null && rawCoords.size >= 2) {
                val points = rawCoords.mapNotNull { pair ->
                    if (pair.size >= 2) LatLng(pair[1], pair[0]) else null
                }
                val distanceM = route.distance.coerceAtLeast(1.0)
                val driveMins = (route.duration / 60.0).roundToInt().coerceAtLeast(1)
                val waitBuffer = (plannedStops.size - 1) * 10
                val walkMins = (distanceM / 80.0).roundToInt().coerceAtLeast(1)
                val summary = route.legs
                    .mapNotNull { it.summary?.takeIf { s -> s.isNotBlank() } }
                    .distinct()
                    .joinToString(" → ")
                    .ifBlank {
                        if (optionalSafeWaypoint != null) {
                            "Via ${optionalSafeWaypoint.label}"
                        } else {
                            "Direct Highway"
                        }
                    }

                return@withContext Result.success(
                    SuggestedTripRoute(
                        origin = origin,
                        destination = destination,
                        stops = plannedStops,
                        pathPoints = points,
                        distanceMeters = distanceM,
                        drivingMinutes = driveMins,
                        hitchEstimateMinutes = driveMins + waitBuffer,
                        walkMinutes = walkMins,
                        viaSummary = summary,
                        isRealRoadGeometry = true
                    )
                )
            }
        } catch (_: Exception) {
            // Graceful offline geodesic corridor fallback below
        }

        val fallback = buildFallbackRoute(plannedStops, optionalSafeWaypoint)
        Result.success(fallback)
    }

    companion object {
        fun buildFallbackRoute(
            stops: List<RouteStop>,
            viaStop: RouteStop? = null
        ): SuggestedTripRoute {
            val summary = GeoMeasurementHelper.measureRoute(stops)
            val points = buildInterpolatedCorridor(stops)
            val origin = stops.first()
            val destination = stops.last()
            val driveMins = (summary.totalDistanceMeters / 1083.33).roundToInt().coerceAtLeast(1)
            return SuggestedTripRoute(
                origin = origin,
                destination = destination,
                stops = stops,
                pathPoints = points,
                distanceMeters = summary.totalDistanceMeters,
                drivingMinutes = driveMins,
                hitchEstimateMinutes = summary.totalRideMinutes,
                walkMinutes = summary.totalWalkMinutes,
                viaSummary = viaStop?.let { "Corridor via ${it.label}" } ?: "Direct Hitchhiking Corridor",
                isRealRoadGeometry = false
            )
        }

        internal fun findBestCorridorSafeStop(
            origin: RouteStop,
            destination: RouteStop,
            notes: List<MapNoteEntity>,
            businesses: List<NearbyBusiness>
        ): RouteStop? {
            val directMeters = GeoMeasurementHelper.distanceMetersExact(
                origin.latitude,
                origin.longitude,
                destination.latitude,
                destination.longitude
            )
            if (directMeters < 400.0) return null

            val minLat = min(origin.latitude, destination.latitude) - 0.03
            val maxLat = max(origin.latitude, destination.latitude) + 0.03
            val minLng = min(origin.longitude, destination.longitude) - 0.03
            val maxLng = max(origin.longitude, destination.longitude) + 0.03

            val noteCandidate = notes.firstOrNull { note ->
                note.latitude in minLat..maxLat &&
                    note.longitude in minLng..maxLng &&
                    GeoMeasurementHelper.distanceMetersExact(origin.latitude, origin.longitude, note.latitude, note.longitude) > 150.0 &&
                    GeoMeasurementHelper.distanceMetersExact(destination.latitude, destination.longitude, note.latitude, note.longitude) > 150.0
            }
            if (noteCandidate != null) {
                return RouteStop(
                    id = "stop_safe_${UUID.randomUUID()}",
                    label = noteCandidate.title,
                    latitude = noteCandidate.latitude,
                    longitude = noteCandidate.longitude
                )
            }

            val bizCandidate = businesses.firstOrNull { biz ->
                biz.latitude in minLat..maxLat &&
                    biz.longitude in minLng..maxLng &&
                    GeoMeasurementHelper.distanceMetersExact(origin.latitude, origin.longitude, biz.latitude, biz.longitude) > 150.0 &&
                    GeoMeasurementHelper.distanceMetersExact(destination.latitude, destination.longitude, biz.latitude, biz.longitude) > 150.0
            }
            return bizCandidate?.let {
                RouteStop(
                    id = "stop_biz_${UUID.randomUUID()}",
                    label = it.name,
                    latitude = it.latitude,
                    longitude = it.longitude
                )
            }
        }

        private fun buildInterpolatedCorridor(stops: List<RouteStop>): List<LatLng> {
            if (stops.size < 2) return stops.map { LatLng(it.latitude, it.longitude) }
            val result = mutableListOf<LatLng>()
            for (i in 0 until stops.lastIndex) {
                val a = stops[i]
                val b = stops[i + 1]
                val steps = 8
                for (step in 0 until steps) {
                    val t = step.toDouble() / steps.toDouble()
                    result += LatLng(
                        a.latitude + (b.latitude - a.latitude) * t,
                        a.longitude + (b.longitude - a.longitude) * t
                    )
                }
            }
            result += LatLng(stops.last().latitude, stops.last().longitude)
            return result
        }
    }
}
