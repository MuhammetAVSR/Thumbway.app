package com.example.data.remote

import com.squareup.moshi.JsonClass
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.POST
import retrofit2.http.Query

@JsonClass(generateAdapter = true)
data class GooglePlacesTextSearchRequest(
    val textQuery: String,
    val pageSize: Int = 10,
    val locationBias: GooglePlacesLocationBias? = null,
    val languageCode: String = "en"
)

@JsonClass(generateAdapter = true)
data class GooglePlacesLocationBias(
    val circle: GooglePlacesCircle
)

@JsonClass(generateAdapter = true)
data class GooglePlacesCircle(
    val center: GooglePlacesLatLng,
    val radius: Double = 5000.0
)

@JsonClass(generateAdapter = true)
data class GooglePlacesLatLng(
    val latitude: Double,
    val longitude: Double
)

@JsonClass(generateAdapter = true)
data class GooglePlacesSearchResponse(
    val places: List<GooglePlaceItem> = emptyList()
)

@JsonClass(generateAdapter = true)
data class GooglePlaceItem(
    val id: String = "",
    val displayName: GooglePlaceDisplayName? = null,
    val formattedAddress: String? = null,
    val location: GooglePlacesLatLng? = null,
    val primaryTypeDisplayName: GooglePlaceDisplayName? = null,
    val rating: Double? = null
)

@JsonClass(generateAdapter = true)
data class GooglePlaceDisplayName(
    val text: String = "",
    val languageCode: String? = null
)

interface GooglePlacesApiService {
    @POST("v1/places:searchText")
    suspend fun searchText(
        @Header("X-Goog-Api-Key") apiKey: String,
        @Header("X-Goog-FieldMask") fieldMask: String = "places.id,places.displayName,places.formattedAddress,places.location,places.primaryTypeDisplayName,places.rating",
        @Header("X-Android-Package") androidPackage: String? = null,
        @Header("X-Android-Cert") androidCertSha1: String? = null,
        @Body request: GooglePlacesTextSearchRequest
    ): GooglePlacesSearchResponse
}

@JsonClass(generateAdapter = true)
data class NominatimPlace(
    val place_id: Long = 0L,
    val display_name: String = "",
    val name: String? = null,
    val lat: String = "0.0",
    val lon: String = "0.0",
    val type: String? = null,
    val category: String? = null
)

interface NominatimSearchService {
    @GET("search")
    suspend fun search(
        @Query("q") query: String,
        @Query("format") format: String = "jsonv2",
        @Query("limit") limit: Int = 8,
        @Query("viewbox") viewbox: String? = null,
        @Query("bounded") bounded: Int = 0
    ): List<NominatimPlace>
}
