package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [
        UserEntity::class,
        FollowEntity::class,
        BlockedUserEntity::class,
        MapNoteEntity::class,
        DismissedNoteEntity::class,
        PostEntity::class,
        SavedPostEntity::class,
        TravelRouteEntity::class,
        ChatMessageEntity::class,
        EmergencyContactEntity::class
    ],
    version = 4,
    exportSchema = false
)
abstract class ThumbWayDatabase : RoomDatabase() {
    abstract fun dao(): ThumbWayDao

    companion object {
        @Volatile
        private var INSTANCE: ThumbWayDatabase? = null

        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `travel_routes` (
                        `id` TEXT NOT NULL,
                        `ownerId` TEXT NOT NULL,
                        `title` TEXT NOT NULL,
                        `stopsJson` TEXT NOT NULL,
                        `totalDistanceMeters` REAL NOT NULL,
                        `estimatedRideMinutes` INTEGER NOT NULL,
                        `estimatedWalkMinutes` INTEGER NOT NULL,
                        `createdAt` INTEGER NOT NULL,
                        `updatedAt` INTEGER NOT NULL,
                        PRIMARY KEY(`id`)
                    )
                    """.trimIndent()
                )
            }
        }

        private val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `chat_messages` (
                        `id` TEXT NOT NULL,
                        `senderId` TEXT NOT NULL,
                        `recipientId` TEXT NOT NULL,
                        `type` TEXT NOT NULL,
                        `text` TEXT NOT NULL,
                        `mediaUri` TEXT,
                        `durationMs` INTEGER NOT NULL,
                        `createdAt` INTEGER NOT NULL,
                        PRIMARY KEY(`id`)
                    )
                    """.trimIndent()
                )
            }
        }

        private val MIGRATION_3_4 = object : Migration(3, 4) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `emergency_contacts` (
                        `id` TEXT NOT NULL,
                        `ownerId` TEXT NOT NULL,
                        `name` TEXT NOT NULL,
                        `phoneNumber` TEXT NOT NULL,
                        `linkedFriendId` TEXT,
                        `createdAt` INTEGER NOT NULL,
                        PRIMARY KEY(`id`)
                    )
                    """.trimIndent()
                )
            }
        }

        fun getInstance(context: Context): ThumbWayDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    ThumbWayDatabase::class.java,
                    "thumbway_database.db"
                )
                    .addMigrations(MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4)
                    .fallbackToDestructiveMigration(dropAllTables = true)
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }
}
