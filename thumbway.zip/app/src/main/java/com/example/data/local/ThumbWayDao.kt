package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface ThumbWayDao {
    @Query("SELECT * FROM users ORDER BY displayName ASC")
    fun observeAllUsers(): Flow<List<UserEntity>>

    @Query("SELECT * FROM users WHERE id = :userId LIMIT 1")
    fun observeUserById(userId: String): Flow<UserEntity?>

    @Query("SELECT * FROM users WHERE id = :userId LIMIT 1")
    suspend fun getUserById(userId: String): UserEntity?

    @Query("SELECT * FROM users WHERE LOWER(username) = LOWER(:username) LIMIT 1")
    suspend fun getUserByUsername(username: String): UserEntity?

    @Query("SELECT COUNT(*) FROM users")
    suspend fun getUserCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUser(user: UserEntity)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertUsers(users: List<UserEntity>)

    @Update
    suspend fun updateUser(user: UserEntity)

    @Query("UPDATE users SET latitude = :lat, longitude = :lng, lastUpdatedAt = :updatedAt WHERE id = :userId")
    suspend fun updateLiveCoordinates(userId: String, lat: Double, lng: Double, updatedAt: Long)

    @Query("UPDATE users SET tsmLatitude = :lat, tsmLongitude = :lng, tsmLabel = :label, lastUpdatedAt = :updatedAt WHERE id = :userId")
    suspend fun updateTsmCoordinates(userId: String, lat: Double, lng: Double, label: String, updatedAt: Long)

    @Query("UPDATE users SET isLocationSharingEnabled = :enabled WHERE id = :userId")
    suspend fun updateLocationSharing(userId: String, enabled: Boolean)

    @Query("UPDATE users SET displayName = :displayName, aboutUs = :aboutUs, avatarUri = :avatarUri WHERE id = :userId")
    suspend fun updateProfile(userId: String, displayName: String, aboutUs: String, avatarUri: String?)

    @Query("UPDATE users SET passwordHash = :passwordHash WHERE id = :userId")
    suspend fun updatePasswordHash(userId: String, passwordHash: String)

    // Follows
    @Query("SELECT followedId FROM follows WHERE followerId = :userId")
    fun observeFollowedIds(userId: String): Flow<List<String>>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun followUser(follow: FollowEntity)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertFollows(follows: List<FollowEntity>)

    @Query("DELETE FROM follows WHERE followerId = :followerId AND followedId = :followedId")
    suspend fun unfollowUser(followerId: String, followedId: String)

    // Blocked Users
    @Query("SELECT blockedId FROM blocked_users WHERE blockerId = :userId")
    fun observeBlockedIds(userId: String): Flow<List<String>>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun blockUser(block: BlockedUserEntity)

    @Query("DELETE FROM blocked_users WHERE blockerId = :blockerId AND blockedId = :blockedId")
    suspend fun unblockUser(blockerId: String, blockedId: String)

    // Map Notes
    @Query("SELECT * FROM map_notes ORDER BY createdAt DESC")
    fun observeAllMapNotes(): Flow<List<MapNoteEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMapNote(note: MapNoteEntity)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertMapNotes(notes: List<MapNoteEntity>)

    @Query("DELETE FROM map_notes WHERE id = :noteId")
    suspend fun deleteMapNote(noteId: String)

    @Query("UPDATE map_notes SET authorName = :authorName, authorAvatarUri = :avatarUri WHERE authorId = :authorId")
    suspend fun syncAuthorInNotes(authorId: String, authorName: String, avatarUri: String?)

    // Dismissed Note Bubbles
    @Query("SELECT noteId FROM dismissed_notes WHERE userId = :userId")
    fun observeDismissedNoteIds(userId: String): Flow<List<String>>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun dismissNoteBubble(dismissed: DismissedNoteEntity)

    @Query("DELETE FROM dismissed_notes WHERE userId = :userId")
    suspend fun restoreDismissedNotes(userId: String)

    // Community Posts
    @Query("SELECT * FROM community_posts ORDER BY createdAt DESC")
    fun observeAllPosts(): Flow<List<PostEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPost(post: PostEntity)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertPosts(posts: List<PostEntity>)

    @Query("DELETE FROM community_posts WHERE id = :postId")
    suspend fun deletePost(postId: String)

    @Query("UPDATE community_posts SET authorName = :authorName, authorAvatarUri = :avatarUri WHERE authorId = :authorId")
    suspend fun syncAuthorInPosts(authorId: String, authorName: String, avatarUri: String?)

    // Saved Posts
    @Query("SELECT postId FROM saved_posts WHERE userId = :userId")
    fun observeSavedPostIds(userId: String): Flow<List<String>>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun savePost(saved: SavedPostEntity)

    @Query("DELETE FROM saved_posts WHERE userId = :userId AND postId = :postId")
    suspend fun unsavePost(userId: String, postId: String)

    // Multi-Stop Travel Routes
    @Query("SELECT * FROM travel_routes WHERE ownerId = :ownerId ORDER BY updatedAt DESC")
    fun observeRoutesForUser(ownerId: String): Flow<List<TravelRouteEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRoute(route: TravelRouteEntity)

    @Query("DELETE FROM travel_routes WHERE id = :routeId")
    suspend fun deleteRoute(routeId: String)

    // Friend Chat Messages
    @Query(
        "SELECT * FROM chat_messages " +
            "WHERE senderId = :userId OR recipientId = :userId " +
            "ORDER BY createdAt ASC"
    )
    fun observeAllMessagesForUser(userId: String): Flow<List<ChatMessageEntity>>

    @Query(
        "SELECT * FROM chat_messages " +
            "WHERE (senderId = :userA AND recipientId = :userB) " +
            "OR (senderId = :userB AND recipientId = :userA) " +
            "ORDER BY createdAt ASC"
    )
    fun observeConversation(userA: String, userB: String): Flow<List<ChatMessageEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessage(message: ChatMessageEntity)

    @Query("DELETE FROM chat_messages WHERE id = :messageId")
    suspend fun deleteMessage(messageId: String)

    // Emergency Contacts
    @Query("SELECT * FROM emergency_contacts WHERE ownerId = :ownerId ORDER BY createdAt ASC")
    fun observeEmergencyContacts(ownerId: String): Flow<List<EmergencyContactEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEmergencyContact(contact: EmergencyContactEntity)

    @Query("DELETE FROM emergency_contacts WHERE id = :contactId")
    suspend fun deleteEmergencyContact(contactId: String)
}
