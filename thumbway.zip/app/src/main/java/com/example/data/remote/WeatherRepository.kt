package com.example.data.remote

import com.example.data.location.RouteStop
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import java.util.concurrent.TimeUnit
import kotlin.math.roundToInt

enum class WeatherSeverity {
    GOOD,
    CAUTION,
    SEVERE
}

data class HourlyWeatherSlot(
    val timeLabel: String,
    val temperatureC: Double,
    val precipProbPercent: Int,
    val weatherCode: Int,
    val conditionLabel: String
)

data class WeatherPointOverlay(
    val id: String,
    val label: String,
    val latitude: Double,
    val longitude: Double,
    val temperatureC: Double,
    val apparentTempC: Double,
    val windSpeedKmh: Double,
    val precipitationMm: Double,
    val weatherCode: Int,
    val isDay: Boolean,
    val conditionLabel: String,
    val severity: WeatherSeverity,
    val hitchAdvisory: String,
    val nextHours: List<HourlyWeatherSlot> = emptyList()
)

data class MapWeatherState(
    val isLoading: Boolean = false,
    val error: String? = null,
    val primaryWeather: WeatherPointOverlay? = null,
    val overlayPoints: List<WeatherPointOverlay> = emptyList(),
    val radarTileUrlTemplate: String? = null,
    val lastUpdatedAtMs: Long = 0L
)

class WeatherRepository {
    private val moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()

    private val okHttp = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .build()

    private val openMeteoApi: OpenMeteoApiService = Retrofit.Builder()
        .baseUrl("https://api.open-meteo.com/")
        .client(okHttp)
        .addConverterFactory(MoshiConverterFactory.create(moshi))
        .build()
        .create(OpenMeteoApiService::class.java)

    private val rainViewerApi: RainViewerApiService = Retrofit.Builder()
        .baseUrl("https://api.rainviewer.com/")
        .client(okHttp)
        .addConverterFactory(MoshiConverterFactory.create(moshi))
        .build()
        .create(RainViewerApiService::class.java)

    suspend fun fetchMapWeather(
        centerLat: Double,
        centerLng: Double,
        centerLabel: String,
        routeStops: List<RouteStop>
    ): Result<MapWeatherState> = withContext(Dispatchers.IO) {
        try {
            val targetPoints: List<Triple<String, String, Pair<Double, Double>>> =
                if (routeStops.isNotEmpty()) {
                    val stopPoints = routeStops.take(5).mapIndexed { idx, stop ->
                        Triple(
                            "weather_stop_${stop.id}",
                            "${idx + 1}. ${stop.label}",
                            stop.latitude to stop.longitude
                        )
                    }
                    listOf(
                        Triple(
                            "weather_center",
                            centerLabel.ifBlank { "Current Area" },
                            centerLat to centerLng
                        )
                    ) + stopPoints
                } else {
                    // Map center plus two nearby regional corridor checkpoints (~4 km N & S/E)
                    listOf(
                        Triple(
                            "weather_center",
                            centerLabel.ifBlank { "Current Area" },
                            centerLat to centerLng
                        ),
                        Triple(
                            "weather_north",
                            "North Corridor",
                            (centerLat + 0.036).coerceIn(-85.0, 85.0) to (centerLng + 0.025)
                        ),
                        Triple(
                            "weather_south",
                            "South Corridor",
                            (centerLat - 0.036).coerceIn(-85.0, 85.0) to (centerLng - 0.025)
                        )
                    )
                }

            val radarDeferred = coroutineScope {
                async {
                    runCatching {
                        val rv = rainViewerApi.getWeatherMaps()
                        val latestPath = rv.radar?.past?.lastOrNull()?.path
                            ?: rv.radar?.nowcast?.firstOrNull()?.path
                        if (!latestPath.isNullOrBlank()) {
                            "${rv.host.trimEnd('/')}$latestPath/256/{z}/{x}/{y}/2/1_1.png"
                        } else {
                            null
                        }
                    }.getOrNull()
                }
            }

            val weatherList = coroutineScope {
                targetPoints.map { (id, label, coords) ->
                    async {
                        runCatching {
                            val response = openMeteoApi.getWeather(
                                latitude = coords.first,
                                longitude = coords.second
                            )
                            mapToOverlay(id, label, coords.first, coords.second, response)
                        }.getOrNull()
                    }
                }.awaitAll().filterNotNull()
            }

            val radarTemplate = radarDeferred.await()

            if (weatherList.isEmpty()) {
                return@withContext Result.failure(IllegalStateException("Unable to load weather forecast"))
            }

            val primary = weatherList.first()
            val overlays = if (routeStops.isNotEmpty()) {
                weatherList.drop(1) // Route stop weather markers
            } else {
                weatherList
            }

            Result.success(
                MapWeatherState(
                    isLoading = false,
                    error = null,
                    primaryWeather = primary,
                    overlayPoints = overlays,
                    radarTileUrlTemplate = radarTemplate,
                    lastUpdatedAtMs = System.currentTimeMillis()
                )
            )
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    companion object {
        fun mapToOverlay(
            id: String,
            label: String,
            lat: Double,
            lng: Double,
            response: OpenMeteoResponse
        ): WeatherPointOverlay {
            val cur = response.current ?: OpenMeteoCurrent()
            val isDay = cur.isDay == 1
            val (condition, baseSeverity) = interpretWmoCode(cur.weatherCode)
            val finalSeverity = when {
                baseSeverity == WeatherSeverity.SEVERE || cur.windSpeed10m >= 45.0 || cur.precipitation >= 5.0 ->
                    WeatherSeverity.SEVERE
                baseSeverity == WeatherSeverity.CAUTION || cur.windSpeed10m >= 25.0 || cur.precipitation > 0.2 ->
                    WeatherSeverity.CAUTION
                else -> WeatherSeverity.GOOD
            }
            val advisory = buildHitchAdvisory(
                weatherCode = cur.weatherCode,
                tempC = cur.temperature2m,
                windKmh = cur.windSpeed10m,
                precipMm = cur.precipitation,
                severity = finalSeverity
            )

            val hourlySlots = buildList {
                val hourly = response.hourly
                if (hourly != null) {
                    val count = minOf(
                        hourly.time.size,
                        hourly.temperature2m.size,
                        hourly.precipitationProbability.size,
                        hourly.weatherCode.size
                    )
                    val step = 2
                    var i = 0
                    while (i < count && size < 6) {
                        val timeRaw = hourly.time[i]
                        val hhmm = timeRaw.substringAfter("T", timeRaw).take(5)
                        val hCode = hourly.weatherCode[i]
                        add(
                            HourlyWeatherSlot(
                                timeLabel = hhmm,
                                temperatureC = hourly.temperature2m[i],
                                precipProbPercent = hourly.precipitationProbability[i],
                                weatherCode = hCode,
                                conditionLabel = interpretWmoCode(hCode).first
                            )
                        )
                        i += step
                    }
                }
            }

            return WeatherPointOverlay(
                id = id,
                label = label,
                latitude = lat,
                longitude = lng,
                temperatureC = cur.temperature2m,
                apparentTempC = cur.apparentTemperature,
                windSpeedKmh = cur.windSpeed10m,
                precipitationMm = cur.precipitation,
                weatherCode = cur.weatherCode,
                isDay = isDay,
                conditionLabel = condition,
                severity = finalSeverity,
                hitchAdvisory = advisory,
                nextHours = hourlySlots
            )
        }

        fun interpretWmoCode(code: Int): Pair<String, WeatherSeverity> = when (code) {
            0 -> "Clear" to WeatherSeverity.GOOD
            1, 2 -> "Partly Cloudy" to WeatherSeverity.GOOD
            3 -> "Overcast" to WeatherSeverity.GOOD
            45, 48 -> "Fog" to WeatherSeverity.CAUTION
            51, 53, 55, 56, 57 -> "Drizzle" to WeatherSeverity.CAUTION
            61, 63, 66, 80, 81 -> "Rain" to WeatherSeverity.CAUTION
            65, 67, 82 -> "Heavy Rain" to WeatherSeverity.SEVERE
            71, 73, 75, 77, 85, 86 -> "Snow" to WeatherSeverity.SEVERE
            95, 96, 99 -> "Thunderstorm" to WeatherSeverity.SEVERE
            else -> "Cloudy" to WeatherSeverity.GOOD
        }

        fun buildHitchAdvisory(
            weatherCode: Int,
            tempC: Double,
            windKmh: Double,
            precipMm: Double,
            severity: WeatherSeverity
        ): String = when {
            weatherCode >= 95 ->
                "Thunderstorm risk — pause roadside waiting and seek indoor shelter."
            weatherCode in listOf(71, 73, 75, 77, 85, 86) ->
                "Snowy conditions — wear insulated layers and choose lit, plowed pullouts."
            weatherCode in listOf(45, 48) ->
                "Low visibility fog — use high-visibility gear and pick safe wide shoulders."
            precipMm > 0.2 || weatherCode in listOf(51, 53, 55, 61, 63, 65, 80, 81, 82) ->
                "Wet weather (${precipMm} mm) — keep rain shell ready; drivers may stop slower."
            windKmh >= 30.0 ->
                "Gusty winds (${windKmh.roundToInt()} km/h) — stand clear of loose debris and stay visible."
            tempC <= 4.0 ->
                "Cold air (${tempC.roundToInt()}°C) — bring warm layers while waiting at junctions."
            tempC >= 32.0 ->
                "High heat (${tempC.roundToInt()}°C) — carry extra water and look for shaded pullouts."
            severity == WeatherSeverity.GOOD ->
                "Good roadside visibility and dry travel conditions."
            else ->
                "Moderate weather — monitor conditions along your route."
        }
    }
}
