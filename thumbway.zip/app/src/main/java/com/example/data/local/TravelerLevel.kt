package com.example.data.local

enum class TravelerRank(
    val level: Int,
    val minPosts: Int
) {
    STARTER(level = 0, minPosts = 0),
    NOVICE_TRAVELER(level = 1, minPosts = 10),
    SEASONED_TRAVELER(level = 2, minPosts = 20),
    ROAD_ENTHUSIAST(level = 3, minPosts = 30),
    MASTER_OF_ROAD(level = 4, minPosts = 40),
    ADVENTURER(level = 5, minPosts = 50),
    EVLIYA_CELEBI(level = 6, minPosts = 60)
}

data class TravelerLevelProgress(
    val postCount: Int,
    val rank: TravelerRank,
    val nextRank: TravelerRank?,
    val progressToNext: Float,
    val overallScaleFraction: Float,
    val postsRemainingForNext: Int
)

object TravelerLevelSystem {
    val scaleMilestones: List<TravelerRank> = listOf(
        TravelerRank.NOVICE_TRAVELER,
        TravelerRank.SEASONED_TRAVELER,
        TravelerRank.ROAD_ENTHUSIAST,
        TravelerRank.MASTER_OF_ROAD,
        TravelerRank.ADVENTURER,
        TravelerRank.EVLIYA_CELEBI
    )

    const val MAX_SCALE_POSTS = 60

    fun evaluate(postCount: Int): TravelerLevelProgress {
        val safeCount = postCount.coerceAtLeast(0)
        val ordered = TravelerRank.entries.sortedBy { it.minPosts }
        val current = ordered.last { safeCount >= it.minPosts }
        val currentIndex = ordered.indexOf(current)
        val next = ordered.getOrNull(currentIndex + 1)

        val progressToNext = if (next == null) {
            1f
        } else {
            val span = (next.minPosts - current.minPosts).coerceAtLeast(1)
            ((safeCount - current.minPosts).toFloat() / span.toFloat()).coerceIn(0f, 1f)
        }

        val overall = (safeCount.toFloat() / MAX_SCALE_POSTS.toFloat()).coerceIn(0f, 1f)
        val remaining = if (next == null) 0 else (next.minPosts - safeCount).coerceAtLeast(0)

        return TravelerLevelProgress(
            postCount = safeCount,
            rank = current,
            nextRank = next,
            progressToNext = progressToNext,
            overallScaleFraction = overall,
            postsRemainingForNext = remaining
        )
    }
}
