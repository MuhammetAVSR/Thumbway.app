package com.example.data.repository

import com.example.data.local.BlockedUserEntity
import com.example.data.local.ChatMessageEntity
import com.example.data.local.ChatMessageType
import com.example.data.local.DismissedNoteEntity
import com.example.data.local.EmergencyContactEntity
import com.example.data.local.FollowEntity
import com.example.data.local.MapNoteEntity
import com.example.data.local.PasswordHasher
import com.example.data.local.PostEntity
import com.example.data.local.SavedPostEntity
import com.example.data.local.SpotType
import com.example.data.local.ThumbWayDao
import com.example.data.local.TravelRouteEntity
import com.example.data.local.UserEntity
import com.example.data.local.UserPreferencesDataStore
import com.example.data.location.GeoMeasurementHelper
import com.example.data.location.RouteStop
import com.example.ui.i18n.AppLanguage
import com.example.ui.theme.ThemeMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import java.util.UUID

class ThumbWayRepository(
    private val dao: ThumbWayDao,
    private val prefs: UserPreferencesDataStore
) {
    val currentUserId: Flow<String?> = prefs.currentUserId
    val themeMode: Flow<ThemeMode> = prefs.themeMode
    val language: Flow<AppLanguage> = prefs.language

    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    val currentUser: Flow<UserEntity?> = prefs.currentUserId.flatMapLatest { id ->
        if (id.isNullOrBlank()) flowOf(null) else dao.observeUserById(id)
    }

    val allUsers: Flow<List<UserEntity>> = dao.observeAllUsers()
    val allMapNotes: Flow<List<MapNoteEntity>> = dao.observeAllMapNotes()
    val allPosts: Flow<List<PostEntity>> = dao.observeAllPosts()

    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    val followedIds: Flow<List<String>> = prefs.currentUserId.flatMapLatest { id ->
        if (id.isNullOrBlank()) flowOf(emptyList()) else dao.observeFollowedIds(id)
    }

    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    val blockedIds: Flow<List<String>> = prefs.currentUserId.flatMapLatest { id ->
        if (id.isNullOrBlank()) flowOf(emptyList()) else dao.observeBlockedIds(id)
    }

    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    val dismissedNoteIds: Flow<List<String>> = prefs.currentUserId.flatMapLatest { id ->
        if (id.isNullOrBlank()) flowOf(emptyList()) else dao.observeDismissedNoteIds(id)
    }

    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    val savedPostIds: Flow<List<String>> = prefs.currentUserId.flatMapLatest { id ->
        if (id.isNullOrBlank()) flowOf(emptyList()) else dao.observeSavedPostIds(id)
    }

    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    val savedRoutes: Flow<List<TravelRouteEntity>> = prefs.currentUserId.flatMapLatest { id ->
        if (id.isNullOrBlank()) flowOf(emptyList()) else dao.observeRoutesForUser(id)
    }

    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    val chatMessagesForCurrentUser: Flow<List<ChatMessageEntity>> = prefs.currentUserId.flatMapLatest { id ->
        if (id.isNullOrBlank()) flowOf(emptyList()) else dao.observeAllMessagesForUser(id)
    }

    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    val emergencyContacts: Flow<List<EmergencyContactEntity>> = prefs.currentUserId.flatMapLatest { id ->
        if (id.isNullOrBlank()) flowOf(emptyList()) else dao.observeEmergencyContacts(id)
    }

    suspend fun ensureSeeded() {
        if (dao.getUserCount() > 0) return
        val now = System.currentTimeMillis()
        val defaultPass = PasswordHasher.hash("travel2026")
        val travelers = listOf(
            UserEntity(
                id = "seed_maya",
                username = "maya_road",
                displayName = "Maya Lin",
                passwordHash = defaultPass,
                aboutUs = "Solo coastal hitchhiker & sketch artist heading south with a 35L pack. Happy to share safe pullouts and coffee tips!",
                isLocationSharingEnabled = true,
                latitude = 37.4268,
                longitude = -122.0785,
                tsmLatitude = 37.4268,
                tsmLongitude = -122.0785,
                tsmLabel = "TSM • Shoreline Ramp",
                lastUpdatedAt = now - 120_000L
            ),
            UserEntity(
                id = "seed_emre",
                username = "emre_trail",
                displayName = "Emre Kaya",
                passwordHash = defaultPass,
                aboutUs = "Cross-country traveler mapping friendly truck stops, water fountains, and quiet camp spots.",
                isLocationSharingEnabled = true,
                latitude = 37.4175,
                longitude = -122.0912,
                tsmLatitude = 37.4175,
                tsmLongitude = -122.0912,
                tsmLabel = "TSM • Bayshore Overpass",
                lastUpdatedAt = now - 240_000L
            ),
            UserEntity(
                id = "seed_lucas",
                username = "lucas_north",
                displayName = "Lucas Vance",
                passwordHash = defaultPass,
                aboutUs = "Weekend ridge hiker and ride-share buddy. Always carrying extra reflective tape and trail snacks.",
                isLocationSharingEnabled = true,
                latitude = 37.4310,
                longitude = -122.0940,
                tsmLatitude = 37.4310,
                tsmLongitude = -122.0940,
                tsmLabel = "TSM • Creek Trailhead",
                lastUpdatedAt = now - 400_000L
            )
        )
        dao.insertUsers(travelers)

        val seedNotes = listOf(
            MapNoteEntity(
                id = "note_seed_1",
                authorId = "seed_maya",
                authorName = "Maya Lin",
                title = "Wide shaded shoulder & slow merge",
                noteText = "Cars slow down nicely right past the pedestrian crosswalk. Free drinking water tap near the park entrance 80m back.",
                spotType = SpotType.ROADSIDE.code,
                latitude = 37.4252,
                longitude = -122.0812,
                locationLabel = "Charleston Rd On-Ramp",
                createdAt = now - 3600_000L
            ),
            MapNoteEntity(
                id = "note_seed_2",
                authorId = "seed_emre",
                authorName = "Emre Kaya",
                title = "Friendly 24h Coffee & Restroom",
                noteText = "Staff lets backpackers refill thermoses and charge phones at the corner counter without hassle.",
                spotType = SpotType.BUSINESS.code,
                latitude = 37.4192,
                longitude = -122.0878,
                locationLabel = "Corner Roasters & Fuel",
                createdAt = now - 7200_000L
            ),
            MapNoteEntity(
                id = "note_seed_3",
                authorId = "seed_lucas",
                authorName = "Lucas Vance",
                title = "Open meadow rest clearing",
                noteText = "Well-lit open lawn beside the bike path, safe spot to regroup and check maps before sunset.",
                spotType = SpotType.OPEN_SPACE.code,
                latitude = 37.4290,
                longitude = -122.0890,
                locationLabel = "Creekside Open Field",
                createdAt = now - 10_800_000L
            )
        )
        dao.insertMapNotes(seedNotes)

        val seedPosts = listOf(
            PostEntity(
                id = "post_seed_1",
                authorId = "seed_maya",
                authorName = "Maya Lin",
                caption = "Caught a ride within 12 minutes at the Shoreline ramp! Remember to stand where drivers have 150m clear visibility and a safe pull-over pocket.",
                locationName = "Shoreline Blvd & Hwy 101",
                latitude = 37.4268,
                longitude = -122.0785,
                createdAt = now - 5400_000L
            ),
            PostEntity(
                id = "post_seed_2",
                authorId = "seed_emre",
                authorName = "Emre Kaya",
                caption = "Pinned a new safe spot near the service plaza. Warm soup, outlets, and plenty of truckers heading north toward the coast.",
                locationName = "Bayshore Service Plaza",
                latitude = 37.4175,
                longitude = -122.0912,
                createdAt = now - 9000_000L
            ),
            PostEntity(
                id = "post_seed_3",
                authorId = "seed_lucas",
                authorName = "Lucas Vance",
                caption = "Golden hour breeze by the creek trailhead. Sharing my TSM pin for anyone passing through tonight.",
                locationName = "Creek Trailhead Overlook",
                latitude = 37.4310,
                longitude = -122.0940,
                createdAt = now - 14_400_000L
            )
        )
        dao.insertPosts(seedPosts)
    }

    suspend fun createProfile(
        username: String,
        displayName: String,
        password: String,
        aboutUs: String,
        avatarUri: String?,
        lat: Double,
        lng: Double
    ): Result<UserEntity> {
        val cleanUsername = username.trim().lowercase()
        if (cleanUsername.length < 3) {
            return Result.failure(IllegalArgumentException("Username must be at least 3 characters."))
        }
        if (displayName.isBlank()) {
            return Result.failure(IllegalArgumentException("Display name is required."))
        }
        if (password.length < 4) {
            return Result.failure(IllegalArgumentException("Password must be at least 4 characters."))
        }
        if (dao.getUserByUsername(cleanUsername) != null) {
            return Result.failure(IllegalArgumentException("That username is already taken."))
        }

        val user = UserEntity(
            id = "user_${UUID.randomUUID()}",
            username = cleanUsername,
            displayName = displayName.trim(),
            passwordHash = PasswordHasher.hash(password),
            aboutUs = aboutUs.trim().ifBlank { "Hitchhiker exploring new highways with ThumbWay." },
            avatarUri = avatarUri,
            isLocationSharingEnabled = true,
            latitude = lat,
            longitude = lng,
            tsmLatitude = lat,
            tsmLongitude = lng,
            tsmLabel = "TSM • Starting Point",
            lastUpdatedAt = System.currentTimeMillis()
        )
        dao.insertUser(user)
        // Follow starter travelers so the community feed & map have immediate fellow travelers
        dao.insertFollows(
            listOf(
                FollowEntity(followerId = user.id, followedId = "seed_maya"),
                FollowEntity(followerId = user.id, followedId = "seed_emre")
            )
        )
        prefs.setCurrentUserId(user.id)
        return Result.success(user)
    }

    suspend fun login(username: String, password: String): Result<UserEntity> {
        val cleanUsername = username.trim().lowercase()
        val user = dao.getUserByUsername(cleanUsername)
            ?: return Result.failure(IllegalArgumentException("Account not found."))
        if (!PasswordHasher.verify(password, user.passwordHash)) {
            return Result.failure(IllegalArgumentException("Incorrect password."))
        }
        prefs.setCurrentUserId(user.id)
        return Result.success(user)
    }

    suspend fun quickLoginExisting(userId: String): Result<UserEntity> {
        val user = dao.getUserById(userId)
            ?: return Result.failure(IllegalArgumentException("Profile not found."))
        prefs.setCurrentUserId(user.id)
        return Result.success(user)
    }

    suspend fun logout() {
        prefs.setCurrentUserId(null)
    }

    suspend fun setThemeMode(mode: ThemeMode) = prefs.setThemeMode(mode)

    suspend fun setLanguage(language: AppLanguage) = prefs.setLanguage(language)

    suspend fun updateProfile(
        userId: String,
        displayName: String,
        aboutUs: String,
        avatarUri: String?
    ): Result<Unit> {
        if (displayName.isBlank()) {
            return Result.failure(IllegalArgumentException("Display name cannot be empty."))
        }
        val cleanName = displayName.trim()
        dao.updateProfile(userId, cleanName, aboutUs.trim(), avatarUri)
        dao.syncAuthorInNotes(userId, cleanName, avatarUri)
        dao.syncAuthorInPosts(userId, cleanName, avatarUri)
        return Result.success(Unit)
    }

    suspend fun updatePassword(
        userId: String,
        currentPassword: String,
        newPassword: String
    ): Result<Unit> {
        val user = dao.getUserById(userId)
            ?: return Result.failure(IllegalArgumentException("User not found."))
        if (!PasswordHasher.verify(currentPassword, user.passwordHash)) {
            return Result.failure(IllegalArgumentException("Current password is incorrect."))
        }
        if (newPassword.length < 4) {
            return Result.failure(IllegalArgumentException("New password must be at least 4 characters."))
        }
        dao.updatePasswordHash(userId, PasswordHasher.hash(newPassword))
        return Result.success(Unit)
    }

    suspend fun updateLiveLocation(userId: String, lat: Double, lng: Double) {
        dao.updateLiveCoordinates(userId, lat, lng, System.currentTimeMillis())
    }

    suspend fun updateTsmLocation(userId: String, lat: Double, lng: Double, label: String) {
        dao.updateTsmCoordinates(userId, lat, lng, label, System.currentTimeMillis())
    }

    suspend fun setLocationSharing(userId: String, enabled: Boolean) {
        dao.updateLocationSharing(userId, enabled)
    }

    suspend fun toggleFollow(currentUserId: String, targetUserId: String, isCurrentlyFollowing: Boolean) {
        if (isCurrentlyFollowing) {
            dao.unfollowUser(currentUserId, targetUserId)
        } else {
            dao.followUser(FollowEntity(followerId = currentUserId, followedId = targetUserId))
        }
    }

    suspend fun blockUser(currentUserId: String, targetUserId: String) {
        if (currentUserId == targetUserId) return
        dao.blockUser(BlockedUserEntity(blockerId = currentUserId, blockedId = targetUserId))
        dao.unfollowUser(currentUserId, targetUserId)
    }

    suspend fun unblockUser(currentUserId: String, targetUserId: String) {
        dao.unblockUser(currentUserId, targetUserId)
    }

    suspend fun addMapNote(
        author: UserEntity,
        title: String,
        noteText: String,
        spotType: SpotType,
        latitude: Double,
        longitude: Double,
        locationLabel: String,
        photoUri: String?
    ) {
        val note = MapNoteEntity(
            id = "note_${UUID.randomUUID()}",
            authorId = author.id,
            authorName = author.displayName,
            authorAvatarUri = author.avatarUri,
            title = title.trim(),
            noteText = noteText.trim(),
            spotType = spotType.code,
            latitude = latitude,
            longitude = longitude,
            locationLabel = locationLabel.trim().ifBlank { "Roadside Pin" },
            photoUri = photoUri,
            createdAt = System.currentTimeMillis()
        )
        dao.insertMapNote(note)
    }

    suspend fun deleteMapNote(noteId: String) {
        dao.deleteMapNote(noteId)
    }

    suspend fun dismissNoteBubble(userId: String, noteId: String) {
        dao.dismissNoteBubble(DismissedNoteEntity(userId = userId, noteId = noteId))
    }

    suspend fun restoreDismissedNotes(userId: String) {
        dao.restoreDismissedNotes(userId)
    }

    suspend fun createPost(
        author: UserEntity,
        caption: String,
        photoUri: String?,
        locationName: String?,
        latitude: Double?,
        longitude: Double?
    ) {
        val post = PostEntity(
            id = "post_${UUID.randomUUID()}",
            authorId = author.id,
            authorName = author.displayName,
            authorAvatarUri = author.avatarUri,
            caption = caption.trim(),
            photoUri = photoUri,
            locationName = locationName?.trim()?.takeIf { it.isNotBlank() },
            latitude = latitude,
            longitude = longitude,
            createdAt = System.currentTimeMillis()
        )
        dao.insertPost(post)
    }

    suspend fun deletePost(postId: String) {
        dao.deletePost(postId)
    }

    suspend fun toggleSavePost(userId: String, postId: String, currentlySaved: Boolean) {
        if (currentlySaved) {
            dao.unsavePost(userId, postId)
        } else {
            dao.savePost(SavedPostEntity(userId = userId, postId = postId))
        }
    }

    suspend fun saveTravelRoute(
        ownerId: String,
        routeId: String?,
        title: String,
        stops: List<RouteStop>
    ): Result<TravelRouteEntity> {
        if (stops.size < 2) {
            return Result.failure(IllegalArgumentException("Add at least 2 stops to save a route."))
        }
        val summary = GeoMeasurementHelper.measureRoute(stops)
        val now = System.currentTimeMillis()
        val resolvedTitle = title.trim().ifBlank {
            "${stops.first().label} → ${stops.last().label}"
        }
        val entity = TravelRouteEntity(
            id = routeId ?: "route_${UUID.randomUUID()}",
            ownerId = ownerId,
            title = resolvedTitle,
            stopsJson = GeoMeasurementHelper.encodeStops(stops),
            totalDistanceMeters = summary.totalDistanceMeters,
            estimatedRideMinutes = summary.totalRideMinutes,
            estimatedWalkMinutes = summary.totalWalkMinutes,
            createdAt = now,
            updatedAt = now
        )
        dao.insertRoute(entity)
        return Result.success(entity)
    }

    suspend fun deleteTravelRoute(routeId: String) {
        dao.deleteRoute(routeId)
    }

    fun observeConversation(userA: String, userB: String): Flow<List<ChatMessageEntity>> =
        dao.observeConversation(userA, userB)

    suspend fun sendChatMessage(
        senderId: String,
        recipientId: String,
        type: ChatMessageType,
        text: String = "",
        mediaUri: String? = null,
        durationMs: Long = 0L
    ): Result<ChatMessageEntity> {
        val cleanText = text.trim()
        if (type == ChatMessageType.TEXT && cleanText.isBlank()) {
            return Result.failure(IllegalArgumentException("Message text cannot be empty."))
        }
        if (type != ChatMessageType.TEXT && mediaUri.isNullOrBlank()) {
            return Result.failure(IllegalArgumentException("Media attachment is missing."))
        }
        val msg = ChatMessageEntity(
            id = "msg_${UUID.randomUUID()}",
            senderId = senderId,
            recipientId = recipientId,
            type = type.code,
            text = cleanText,
            mediaUri = mediaUri,
            durationMs = durationMs.coerceAtLeast(0L),
            createdAt = System.currentTimeMillis()
        )
        dao.insertMessage(msg)
        return Result.success(msg)
    }

    suspend fun deleteChatMessage(messageId: String) {
        dao.deleteMessage(messageId)
    }

    suspend fun addEmergencyContact(
        ownerId: String,
        name: String,
        phoneNumber: String,
        linkedFriendId: String? = null
    ): Result<EmergencyContactEntity> {
        val cleanName = name.trim()
        val cleanPhone = phoneNumber.trim()
        if (cleanName.isBlank()) {
            return Result.failure(IllegalArgumentException("Contact name is required."))
        }
        if (cleanPhone.isBlank() && linkedFriendId.isNullOrBlank()) {
            return Result.failure(IllegalArgumentException("Enter a phone number or link a friend."))
        }
        val entity = EmergencyContactEntity(
            id = if (!linkedFriendId.isNullOrBlank()) {
                "ec_${ownerId}_${linkedFriendId}"
            } else {
                "ec_${UUID.randomUUID()}"
            },
            ownerId = ownerId,
            name = cleanName,
            phoneNumber = cleanPhone,
            linkedFriendId = linkedFriendId
        )
        dao.insertEmergencyContact(entity)
        return Result.success(entity)
    }

    suspend fun removeEmergencyContact(contactId: String) {
        dao.deleteEmergencyContact(contactId)
    }

    suspend fun dispatchInAppSos(
        senderId: String,
        recipientFriendIds: List<String>,
        distressMessage: String
    ): Int {
        var sentCount = 0
        val now = System.currentTimeMillis()
        recipientFriendIds.distinct().forEachIndexed { idx, friendId ->
            dao.insertMessage(
                ChatMessageEntity(
                    id = "sos_${UUID.randomUUID()}",
                    senderId = senderId,
                    recipientId = friendId,
                    type = ChatMessageType.TEXT.code,
                    text = distressMessage,
                    createdAt = now + idx
                )
            )
            sentCount++
        }
        return sentCount
    }

    companion object {
        fun buildSosDistressMessage(
            sender: UserEntity,
            latitude: Double,
            longitude: Double,
            localityLabel: String,
            customNote: String
        ): String {
            val coords = String.format(java.util.Locale.US, "%.5f, %.5f", latitude, longitude)
            val mapsUrl = "https://maps.google.com/?q=$coords"
            val notePart = customNote.trim().ifBlank {
                "I need help immediately. Please check my last known location."
            }
            val locationPart = if (localityLabel.isNotBlank()) "$localityLabel ($coords)" else coords
            return buildString {
                append("SOS DISTRESS SIGNAL from ${sender.displayName} (@${sender.username})\n")
                append("Message: $notePart\n")
                append("Last Known Location: $locationPart\n")
                append("Map Link: $mapsUrl")
            }
        }
    }
}
