package com.example.data.local

import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.webkit.MimeTypeMap
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID

data class PersistedChatMedia(
    val uriString: String,
    val isVideo: Boolean
)

object PhotoStorageHelper {
    suspend fun persistPickerUri(context: Context, sourceUri: Uri): String? = withContext(Dispatchers.IO) {
        try {
            val dir = File(context.filesDir, "photos").apply { mkdirs() }
            val outFile = File(dir, "img_${UUID.randomUUID()}.jpg")
            context.contentResolver.openInputStream(sourceUri)?.use { input ->
                outFile.outputStream().use { output ->
                    input.copyTo(output)
                }
            } ?: return@withContext null
            Uri.fromFile(outFile).toString()
        } catch (_: Exception) {
            null
        }
    }

    suspend fun persistChatMediaUri(context: Context, sourceUri: Uri): PersistedChatMedia? = withContext(Dispatchers.IO) {
        try {
            val mimeType = context.contentResolver.getType(sourceUri)?.lowercase()
            val isVideo = when {
                mimeType?.startsWith("video/") == true -> true
                mimeType?.startsWith("image/") == true -> false
                else -> {
                    val path = sourceUri.toString().lowercase()
                    path.endsWith(".mp4") || path.endsWith(".mov") || path.endsWith(".webm") || path.endsWith(".mkv")
                }
            }
            val extFromMime = mimeType?.let { MimeTypeMap.getSingleton().getExtensionFromMimeType(it) }
            val ext = when {
                !extFromMime.isNullOrBlank() -> extFromMime
                isVideo -> "mp4"
                else -> "jpg"
            }
            val prefix = if (isVideo) "vid" else "img"
            val dir = File(context.filesDir, "media").apply { mkdirs() }
            val outFile = File(dir, "${prefix}_${UUID.randomUUID()}.$ext")
            context.contentResolver.openInputStream(sourceUri)?.use { input ->
                outFile.outputStream().use { output ->
                    input.copyTo(output)
                }
            } ?: return@withContext null
            PersistedChatMedia(
                uriString = Uri.fromFile(outFile).toString(),
                isVideo = isVideo
            )
        } catch (_: Exception) {
            null
        }
    }

    fun createCameraOutputUri(context: Context): Pair<Uri, String> {
        val dir = File(context.filesDir, "photos").apply { mkdirs() }
        val file = File(dir, "cam_${UUID.randomUUID()}.jpg")
        val contentUri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )
        return contentUri to Uri.fromFile(file).toString()
    }

    fun createCameraVideoOutputUri(context: Context): Pair<Uri, String> {
        val dir = File(context.filesDir, "media").apply { mkdirs() }
        val file = File(dir, "vid_cam_${UUID.randomUUID()}.mp4")
        val contentUri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )
        return contentUri to Uri.fromFile(file).toString()
    }

    fun createAudioOutputFile(context: Context): File {
        val dir = File(context.filesDir, "audio").apply { mkdirs() }
        return File(dir, "voice_${UUID.randomUUID()}.m4a")
    }

    suspend fun getMediaDurationMs(context: Context, uriString: String): Long = withContext(Dispatchers.IO) {
        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(context, Uri.parse(uriString))
            retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        } catch (_: Exception) {
            0L
        } finally {
            runCatching { retriever.release() }
        }
    }

    suspend fun extractVideoThumbnail(context: Context, uriString: String): Bitmap? = withContext(Dispatchers.IO) {
        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(context, Uri.parse(uriString))
            retriever.getFrameAtTime(0L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
        } catch (_: Exception) {
            null
        } finally {
            runCatching { retriever.release() }
        }
    }
}
