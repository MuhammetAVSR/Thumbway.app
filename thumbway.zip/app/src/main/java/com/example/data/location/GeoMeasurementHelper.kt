package com.example.data.location

import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.util.Locale
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt

@Serializable
data class RouteStop(
    val id: String,
    val label: String,
    val latitude: Double,
    val longitude: Double
)

data class RouteLegSummary(
    val fromLabel: String,
    val toLabel: String,
    val distanceMeters: Double,
    val metricFormatted: String,
    val milesFormatted: String,
    val rideMinutes: Int,
    val walkMinutes: Int,
    val compassDirection: String
)

data class RouteSummary(
    val stops: List<RouteStop>,
    val legs: List<RouteLegSummary>,
    val totalDistanceMeters: Double,
    val totalMetricFormatted: String,
    val totalMilesFormatted: String,
    val totalRideMinutes: Int,
    val totalWalkMinutes: Int
)

data class DistanceMeasurement(
    val distanceMeters: Double,
    val bearingDegrees: Double,
    val compassDirection: String,
    val metricFormatted: String,
    val milesFormatted: String,
    val walkMinutes: Int,
    val driveMinutes: Int
)

object GeoMeasurementHelper {
    private const val EARTH_RADIUS_METERS = 6_371_000.0
    private const val METERS_PER_MILE = 1_609.344
    private const val HITCH_WAIT_BUFFER_MINUTES = 10
    private val json = Json { ignoreUnknownKeys = true }

    fun encodeStops(stops: List<RouteStop>): String = json.encodeToString(stops)

    fun decodeStops(stopsJson: String): List<RouteStop> = try {
        json.decodeFromString<List<RouteStop>>(stopsJson)
    } catch (_: Exception) {
        emptyList()
    }

    fun measureRoute(stops: List<RouteStop>): RouteSummary {
        if (stops.size < 2) {
            return RouteSummary(
                stops = stops,
                legs = emptyList(),
                totalDistanceMeters = 0.0,
                totalMetricFormatted = "0 m",
                totalMilesFormatted = "0.00 mi",
                totalRideMinutes = 0,
                totalWalkMinutes = 0
            )
        }
        val legs = mutableListOf<RouteLegSummary>()
        var totalMeters = 0.0
        var totalRide = 0
        var totalWalk = 0
        for (i in 0 until stops.lastIndex) {
            val from = stops[i]
            val to = stops[i + 1]
            val m = measure(from.latitude, from.longitude, to.latitude, to.longitude)
            totalMeters += m.distanceMeters
            // Include realistic roadside thumb wait buffer on multi-stop legs beyond simple point distance
            val legHitchMins = m.driveMinutes + HITCH_WAIT_BUFFER_MINUTES
            totalRide += legHitchMins
            totalWalk += m.walkMinutes
            legs += RouteLegSummary(
                fromLabel = from.label,
                toLabel = to.label,
                distanceMeters = m.distanceMeters,
                metricFormatted = m.metricFormatted,
                milesFormatted = m.milesFormatted,
                rideMinutes = legHitchMins,
                walkMinutes = m.walkMinutes,
                compassDirection = m.compassDirection
            )
        }
        return RouteSummary(
            stops = stops,
            legs = legs,
            totalDistanceMeters = totalMeters,
            totalMetricFormatted = formatMetric(totalMeters),
            totalMilesFormatted = formatMiles(totalMeters),
            totalRideMinutes = totalRide,
            totalWalkMinutes = totalWalk
        )
    }

    fun measure(
        fromLat: Double,
        fromLng: Double,
        toLat: Double,
        toLng: Double
    ): DistanceMeasurement {
        val meters = distanceMetersExact(fromLat, fromLng, toLat, toLng)
        val bearing = bearingDegrees(fromLat, fromLng, toLat, toLng)
        val walkMins = (meters / 80.0).roundToInt().coerceAtLeast(if (meters < 20.0) 0 else 1)
        val driveMins = (meters / 1083.33).roundToInt().coerceAtLeast(if (meters < 50.0) 0 else 1)
        return DistanceMeasurement(
            distanceMeters = meters,
            bearingDegrees = bearing,
            compassDirection = compassDirection(bearing),
            metricFormatted = formatMetric(meters),
            milesFormatted = formatMiles(meters),
            walkMinutes = walkMins,
            driveMinutes = driveMins
        )
    }

    fun distanceMetersExact(
        lat1: Double,
        lng1: Double,
        lat2: Double,
        lng2: Double
    ): Double {
        val dLat = Math.toRadians(lat2 - lat1)
        val dLng = Math.toRadians(lng2 - lng1)
        val a = sin(dLat / 2) * sin(dLat / 2) +
            cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) *
            sin(dLng / 2) * sin(dLng / 2)
        val c = 2 * atan2(sqrt(a), sqrt((1 - a).coerceAtLeast(0.0)))
        return EARTH_RADIUS_METERS * c
    }

    fun bearingDegrees(
        lat1: Double,
        lng1: Double,
        lat2: Double,
        lng2: Double
    ): Double {
        val phi1 = Math.toRadians(lat1)
        val phi2 = Math.toRadians(lat2)
        val dLambda = Math.toRadians(lng2 - lng1)
        val y = sin(dLambda) * cos(phi2)
        val x = cos(phi1) * sin(phi2) - sin(phi1) * cos(phi2) * cos(dLambda)
        val theta = Math.toDegrees(atan2(y, x))
        return (theta + 360.0) % 360.0
    }

    fun compassDirection(bearingDegrees: Double): String {
        val directions = arrayOf("N", "NE", "E", "SE", "S", "SW", "W", "NW")
        val index = (((bearingDegrees + 22.5) % 360.0) / 45.0).toInt().coerceIn(0, 7)
        return directions[index]
    }

    fun formatMetric(meters: Double): String = if (meters < 1000.0) {
        "${meters.roundToInt()} m"
    } else {
        String.format(Locale.US, "%.2f km", meters / 1000.0)
    }

    fun formatMiles(meters: Double): String {
        val miles = meters / METERS_PER_MILE
        return String.format(Locale.US, "%.2f mi", miles)
    }

    fun formatDurationMinutes(minutes: Int): String {
        if (minutes <= 0) return "<1 min"
        val hours = minutes / 60
        val mins = minutes % 60
        return when {
            hours == 0 -> "$mins min"
            mins == 0 -> "${hours}h"
            else -> "${hours}h ${mins}m"
        }
    }
}
