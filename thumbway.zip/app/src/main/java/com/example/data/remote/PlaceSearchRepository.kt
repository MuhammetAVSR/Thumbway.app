package com.example.data.remote

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import com.example.BuildConfig
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import java.security.MessageDigest
import java.util.Locale
import java.util.concurrent.TimeUnit

enum class PlaceResultSource {
    GOOGLE_PLACES,
    OSM_FALLBACK
}

data class PlaceSearchResult(
    val id: String,
    val name: String,
    val address: String,
    val category: String,
    val latitude: Double,
    val longitude: Double,
    val rating: Double? = null,
    val distanceMeters: Int = 0,
    val source: PlaceResultSource = PlaceResultSource.GOOGLE_PLACES
)

class PlaceSearchRepository(context: Context) {
    private val appContext = context.applicationContext
    private val moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()

    private val okHttp = OkHttpClient.Builder()
        .addInterceptor { chain ->
            val req = chain.request().newBuilder()
                .header("User-Agent", "ThumbWay-Android/1.0")
                .build()
            chain.proceed(req)
        }
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .build()

    private val googlePlacesApi: GooglePlacesApiService = Retrofit.Builder()
        .baseUrl("https://places.googleapis.com/")
        .client(okHttp)
        .addConverterFactory(MoshiConverterFactory.create(moshi))
        .build()
        .create(GooglePlacesApiService::class.java)

    private val nominatimApi: NominatimSearchService = Retrofit.Builder()
        .baseUrl("https://nominatim.openstreetmap.org/")
        .client(okHttp)
        .addConverterFactory(MoshiConverterFactory.create(moshi))
        .build()
        .create(NominatimSearchService::class.java)

    private val certSha1: String? by lazy { readSigningCertSha1() }

    fun hasGooglePlacesKey(): Boolean {
        val key = BuildConfig.MAPS_API_KEY
        return key.isNotBlank() && key != "MY_MAPS_API_KEY" && !key.startsWith("MY_")
    }

    suspend fun searchPlaces(
        query: String,
        centerLat: Double,
        centerLng: Double,
        languageCode: String = "en",
        cachedBusinesses: List<NearbyBusiness> = emptyList()
    ): Result<List<PlaceSearchResult>> = withContext(Dispatchers.IO) {
        val trimmed = query.trim()
        if (trimmed.isBlank()) return@withContext Result.success(emptyList())

        // 1. Try Google Places API (New) when MAPS_API_KEY is configured
        if (hasGooglePlacesKey()) {
            try {
                val request = GooglePlacesTextSearchRequest(
                    textQuery = trimmed,
                    pageSize = 10,
                    locationBias = GooglePlacesLocationBias(
                        circle = GooglePlacesCircle(
                            center = GooglePlacesLatLng(centerLat, centerLng),
                            radius = 5000.0
                        )
                    ),
                    languageCode = languageCode
                )
                val response = googlePlacesApi.searchText(
                    apiKey = BuildConfig.MAPS_API_KEY,
                    androidPackage = appContext.packageName,
                    androidCertSha1 = certSha1,
                    request = request
                )
                val results = response.places.mapNotNull { place ->
                    val loc = place.location ?: return@mapNotNull null
                    PlaceSearchResult(
                        id = place.id.ifBlank { "${loc.latitude}_${loc.longitude}" },
                        name = place.displayName?.text?.ifBlank { trimmed } ?: trimmed,
                        address = place.formattedAddress ?: "",
                        category = place.primaryTypeDisplayName?.text ?: "Place",
                        latitude = loc.latitude,
                        longitude = loc.longitude,
                        rating = place.rating,
                        distanceMeters = NearbyPlacesRepository.distanceMeters(
                            centerLat,
                            centerLng,
                            loc.latitude,
                            loc.longitude
                        ),
                        source = PlaceResultSource.GOOGLE_PLACES
                    )
                }
                if (results.isNotEmpty()) {
                    return@withContext Result.success(results)
                }
            } catch (_: Exception) {
                // Fall through to live OSM Nominatim + nearby businesses fallback if key lacks Places API (New)
            }
        }

        // 2. Fallback: Match local nearby businesses + query OpenStreetMap Nominatim
        val localMatches = cachedBusinesses
            .filter {
                it.name.contains(trimmed, ignoreCase = true) ||
                    it.category.label.contains(trimmed, ignoreCase = true) ||
                    it.address.contains(trimmed, ignoreCase = true)
            }
            .map { biz ->
                PlaceSearchResult(
                    id = biz.id,
                    name = biz.name,
                    address = biz.address,
                    category = biz.category.label,
                    latitude = biz.latitude,
                    longitude = biz.longitude,
                    distanceMeters = NearbyPlacesRepository.distanceMeters(
                        centerLat,
                        centerLng,
                        biz.latitude,
                        biz.longitude
                    ),
                    source = PlaceResultSource.OSM_FALLBACK
                )
            }

        try {
            val delta = 0.08
            val viewbox = String.format(
                Locale.US,
                "%.5f,%.5f,%.5f,%.5f",
                centerLng - delta,
                centerLat + delta,
                centerLng + delta,
                centerLat - delta
            )
            val remoteMatches = nominatimApi.search(
                query = trimmed,
                viewbox = viewbox
            ).mapNotNull { item ->
                val lat = item.lat.toDoubleOrNull() ?: return@mapNotNull null
                val lng = item.lon.toDoubleOrNull() ?: return@mapNotNull null
                val shortName = item.name?.takeIf { it.isNotBlank() }
                    ?: item.display_name.substringBefore(",").trim()
                PlaceSearchResult(
                    id = "nom_${item.place_id}",
                    name = shortName,
                    address = item.display_name,
                    category = item.type?.replace('_', ' ')?.replaceFirstChar { it.uppercase() } ?: "Location",
                    latitude = lat,
                    longitude = lng,
                    distanceMeters = NearbyPlacesRepository.distanceMeters(centerLat, centerLng, lat, lng),
                    source = PlaceResultSource.OSM_FALLBACK
                )
            }
            val combined = (localMatches + remoteMatches)
                .distinctBy { "${it.name.lowercase()}_${"%.4f".format(Locale.US, it.latitude)}" }
                .sortedBy { it.distanceMeters }
            Result.success(combined)
        } catch (e: Exception) {
            if (localMatches.isNotEmpty()) {
                Result.success(localMatches)
            } else {
                Result.failure(e)
            }
        }
    }

    @Suppress("DEPRECATION")
    private fun readSigningCertSha1(): String? {
        return try {
            val pm = appContext.packageManager
            val signatures = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                pm.getPackageInfo(appContext.packageName, PackageManager.GET_SIGNING_CERTIFICATES)
                    .signingInfo?.apkContentsSigners
            } else {
                pm.getPackageInfo(appContext.packageName, PackageManager.GET_SIGNATURES)
                    .signatures
            }
            val certBytes = signatures?.firstOrNull()?.toByteArray() ?: return null
            val digest = MessageDigest.getInstance("SHA-1").digest(certBytes)
            digest.joinToString("") { "%02X".format(it) }
        } catch (_: Exception) {
            null
        }
    }
}
