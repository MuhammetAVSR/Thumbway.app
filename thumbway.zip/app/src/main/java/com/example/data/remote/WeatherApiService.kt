package com.example.data.remote

import com.squareup.moshi.Json
import retrofit2.http.GET
import retrofit2.http.Query

interface OpenMeteoApiService {
    @GET("v1/forecast")
    suspend fun getWeather(
        @Query("latitude") latitude: Double,
        @Query("longitude") longitude: Double,
        @Query("current") current: String = "temperature_2m,apparent_temperature,precipitation,rain,weather_code,wind_speed_10m,is_day",
        @Query("hourly") hourly: String = "temperature_2m,precipitation_probability,weather_code",
        @Query("forecast_days") forecastDays: Int = 1,
        @Query("timezone") timezone: String = "auto"
    ): OpenMeteoResponse
}

data class OpenMeteoResponse(
    val latitude: Double = 0.0,
    val longitude: Double = 0.0,
    val current: OpenMeteoCurrent? = null,
    val hourly: OpenMeteoHourly? = null
)

data class OpenMeteoCurrent(
    @Json(name = "temperature_2m") val temperature2m: Double = 0.0,
    @Json(name = "apparent_temperature") val apparentTemperature: Double = 0.0,
    val precipitation: Double = 0.0,
    val rain: Double = 0.0,
    @Json(name = "weather_code") val weatherCode: Int = 0,
    @Json(name = "wind_speed_10m") val windSpeed10m: Double = 0.0,
    @Json(name = "is_day") val isDay: Int = 1
)

data class OpenMeteoHourly(
    val time: List<String> = emptyList(),
    @Json(name = "temperature_2m") val temperature2m: List<Double> = emptyList(),
    @Json(name = "precipitation_probability") val precipitationProbability: List<Int> = emptyList(),
    @Json(name = "weather_code") val weatherCode: List<Int> = emptyList()
)

interface RainViewerApiService {
    @GET("public/weather-maps.json")
    suspend fun getWeatherMaps(): RainViewerResponse
}

data class RainViewerResponse(
    val host: String = "https://tilecache.rainviewer.com",
    val radar: RainViewerRadar? = null
)

data class RainViewerRadar(
    val past: List<RainViewerFrame> = emptyList(),
    val nowcast: List<RainViewerFrame> = emptyList()
)

data class RainViewerFrame(
    val time: Long = 0L,
    val path: String = ""
)
