package com.example.data.remote

import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import java.util.Locale
import java.util.concurrent.TimeUnit
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

enum class BusinessCategory(val label: String) {
    FUEL("Gas Station"),
    CAFE("Cafe"),
    RESTAURANT("Restaurant"),
    SHOP("Market / Shop"),
    TRANSIT("Transit / Bus"),
    REST_AREA("Rest Stop"),
    HOSTEL("Hostel / Stay")
}

data class NearbyBusiness(
    val id: String,
    val name: String,
    val category: BusinessCategory,
    val latitude: Double,
    val longitude: Double,
    val address: String,
    val openingHours: String? = null,
    val distanceMeters: Int = 0
)

class NearbyPlacesRepository {
    private val moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()

    private val okHttp = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .build()

    private val api: OverpassApiService = Retrofit.Builder()
        .baseUrl("https://overpass-api.de/")
        .client(okHttp)
        .addConverterFactory(MoshiConverterFactory.create(moshi))
        .build()
        .create(OverpassApiService::class.java)

    suspend fun fetchNearbyBusinesses(
        centerLat: Double,
        centerLng: Double,
        radiusMeters: Int = 2500
    ): Result<List<NearbyBusiness>> = withContext(Dispatchers.IO) {
        try {
            val query = String.format(
                Locale.US,
                """
                [out:json][timeout:8];
                (
                  node["amenity"~"fuel|cafe|restaurant|fast_food|bus_station"](around:%d,%.6f,%.6f);
                  node["shop"~"supermarket|convenience|bakery"](around:%d,%.6f,%.6f);
                  node["highway"~"services|rest_area"](around:%d,%.6f,%.6f);
                  node["tourism"~"hostel|camp_site"](around:%d,%.6f,%.6f);
                );
                out body 35;
                """.trimIndent(),
                radiusMeters, centerLat, centerLng,
                radiusMeters, centerLat, centerLng,
                radiusMeters, centerLat, centerLng,
                radiusMeters, centerLat, centerLng
            )
            val response = api.queryNearbyPlaces(query)
            val places = response.elements.mapNotNull { el ->
                val lat = el.lat ?: el.center?.lat ?: return@mapNotNull null
                val lng = el.lon ?: el.center?.lon ?: return@mapNotNull null
                val tags = el.tags ?: emptyMap()
                val amenity = tags["amenity"]
                val shop = tags["shop"]
                val highway = tags["highway"]
                val tourism = tags["tourism"]

                val category = when {
                    amenity == "fuel" -> BusinessCategory.FUEL
                    amenity == "cafe" -> BusinessCategory.CAFE
                    amenity == "restaurant" || amenity == "fast_food" -> BusinessCategory.RESTAURANT
                    amenity == "bus_station" -> BusinessCategory.TRANSIT
                    highway == "services" || highway == "rest_area" -> BusinessCategory.REST_AREA
                    tourism == "hostel" || tourism == "camp_site" -> BusinessCategory.HOSTEL
                    shop != null -> BusinessCategory.SHOP
                    else -> BusinessCategory.SHOP
                }

                val name = tags["name"]
                    ?: tags["brand"]
                    ?: category.label

                val street = listOfNotNull(tags["addr:street"], tags["addr:housenumber"])
                    .joinToString(" ")
                    .ifBlank { category.label }

                NearbyBusiness(
                    id = "osm_${el.id}",
                    name = name,
                    category = category,
                    latitude = lat,
                    longitude = lng,
                    address = street,
                    openingHours = tags["opening_hours"],
                    distanceMeters = distanceMeters(centerLat, centerLng, lat, lng)
                )
            }.sortedBy { it.distanceMeters }
            Result.success(places)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    companion object {
        fun distanceMeters(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Int {
            val r = 6371000.0
            val dLat = Math.toRadians(lat2 - lat1)
            val dLon = Math.toRadians(lon2 - lon1)
            val a = sin(dLat / 2) * sin(dLat / 2) +
                cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) *
                sin(dLon / 2) * sin(dLon / 2)
            val c = 2 * atan2(sqrt(a), sqrt(1 - a))
            return (r * c).toInt()
        }
    }
}
