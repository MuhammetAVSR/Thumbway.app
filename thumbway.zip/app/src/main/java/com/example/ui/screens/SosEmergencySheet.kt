package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.MyLocation
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.Phone
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.local.UserEntity
import com.example.data.repository.ThumbWayRepository
import com.example.ui.i18n.AppStrings
import com.example.ui.theme.RoadSuccess
import com.example.ui.viewmodel.ThumbWayUiState
import java.util.Locale

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SosEmergencySheetContent(
    uiState: ThumbWayUiState,
    strings: AppStrings,
    onAddContact: (name: String, phone: String) -> Unit,
    onRemoveContact: (contactId: String) -> Unit,
    onToggleFriendEmergencyContact: (UserEntity) -> Unit,
    onSendSosSignal: (
        customNote: String,
        onPrepared: (distressText: String, phoneNumbers: List<String>, inAppCount: Int) -> Unit
    ) -> Unit,
    onClose: () -> Unit
) {
    val context = LocalContext.current
    val focusManager = LocalFocusManager.current
    val keyboardController = LocalSoftwareKeyboardController.current
    val currentUser = uiState.currentUser ?: return
    var customNote by remember { mutableStateOf("") }
    var newName by remember { mutableStateOf("") }
    var newPhone by remember { mutableStateOf("") }
    var sentSummary by remember { mutableStateOf<String?>(null) }

    DisposableEffect(Unit) {
        onDispose {
            focusManager.clearFocus(force = true)
            keyboardController?.hide()
        }
    }

    val phoneContacts = remember(uiState.emergencyContacts) {
        uiState.emergencyContacts.filter { it.linkedFriendId == null }
    }
    val linkedFriendIds = remember(uiState.emergencyContacts) {
        uiState.emergencyContacts.mapNotNull { it.linkedFriendId }.toSet()
    }

    val coordsText = String.format(
        Locale.US,
        "%.5f, %.5f",
        uiState.liveLocation.latitude,
        uiState.liveLocation.longitude
    )

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Emergency Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                shape = CircleShape,
                color = Color(0xFFD32F2F),
                modifier = Modifier.size(44.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.Rounded.Warning,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = strings.sosSheetTitle,
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFFD32F2F)
                )
                Text(
                    text = "${uiState.liveLocation.localityLabel} • $coordsText",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }

        // Last Known Coordinates Card
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.45f),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Rounded.MyLocation,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.error
                )
                Spacer(modifier = Modifier.width(10.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = strings.lastKnownLocationLabel,
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onErrorContainer
                    )
                    Text(
                        text = "$coordsText (${uiState.liveLocation.localityLabel})",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }

        // Distress Message Note
        OutlinedTextField(
            value = customNote,
            onValueChange = { customNote = it },
            label = { Text(strings.distressMessageHint) },
            minLines = 2,
            maxLines = 3,
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("sos_distress_note_input")
        )

        // ThumbWay Friends Emergency Contacts
        if (uiState.friendUsers.isNotEmpty()) {
            Text(
                text = strings.thumbWayFriendsContactsLabel,
                style = MaterialTheme.typography.titleSmall
            )
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                uiState.friendUsers.forEach { friend ->
                    val selected = friend.id in linkedFriendIds
                    FilterChip(
                        selected = selected,
                        onClick = { onToggleFriendEmergencyContact(friend) },
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Rounded.Person,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                        },
                        label = { Text(friend.displayName) },
                        modifier = Modifier.testTag("sos_friend_chip_${friend.id}")
                    )
                }
            }
        }

        HorizontalDivider()

        // Phone Emergency Contacts
        Text(
            text = "${strings.emergencyContactsLabel} (${uiState.emergencyContacts.size})",
            style = MaterialTheme.typography.titleSmall
        )

        if (uiState.emergencyContacts.isEmpty()) {
            Text(
                text = strings.noEmergencyContactsYet,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        } else {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                phoneContacts.forEach { contact ->
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = contact.name,
                                    style = MaterialTheme.typography.titleSmall,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = contact.phoneNumber,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            IconButton(
                                onClick = {
                                    runCatching {
                                        val dialIntent = Intent(
                                            Intent.ACTION_DIAL,
                                            Uri.parse("tel:${Uri.encode(contact.phoneNumber)}")
                                        )
                                        context.startActivity(dialIntent)
                                    }
                                },
                                modifier = Modifier.size(40.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Phone,
                                    contentDescription = contact.phoneNumber,
                                    tint = MaterialTheme.colorScheme.primary
                                )
                            }
                            IconButton(
                                onClick = { onRemoveContact(contact.id) },
                                modifier = Modifier.size(40.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.DeleteOutline,
                                    contentDescription = strings.deleteLabel,
                                    tint = MaterialTheme.colorScheme.error
                                )
                            }
                        }
                    }
                }
            }
        }

        // Add New Phone Contact Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = newName,
                onValueChange = { newName = it },
                placeholder = { Text(strings.contactNameHint, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .weight(1f)
                    .testTag("sos_contact_name_input")
            )
            OutlinedTextField(
                value = newPhone,
                onValueChange = { newPhone = it },
                placeholder = { Text(strings.phoneNumberHint, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .weight(1f)
                    .testTag("sos_contact_phone_input")
            )
            Button(
                onClick = {
                    if (newName.isNotBlank() && newPhone.isNotBlank()) {
                        onAddContact(newName, newPhone)
                        newName = ""
                        newPhone = ""
                    }
                },
                enabled = newName.isNotBlank() && newPhone.isNotBlank(),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .height(52.dp)
                    .testTag("sos_add_contact_button")
            ) {
                Icon(Icons.Rounded.Add, contentDescription = strings.addEmergencyContactLabel)
            }
        }

        sentSummary?.let { summary ->
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = RoadSuccess.copy(alpha = 0.16f),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Rounded.CheckCircle,
                        contentDescription = null,
                        tint = RoadSuccess
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = summary,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }

        // Primary SOS Trigger Button
        Button(
            onClick = {
                onSendSosSignal(customNote) { distressText, phones, inAppCount ->
                    sentSummary = buildString {
                        append(strings.sosSentNotice)
                        if (inAppCount > 0 || phones.isNotEmpty()) {
                            append(" ($inAppCount ThumbWay, ${phones.size} SMS)")
                        }
                    }
                    if (phones.isNotEmpty()) {
                        val smsUri = Uri.parse("smsto:${phones.joinToString(";")}")
                        val smsIntent = Intent(Intent.ACTION_SENDTO, smsUri).apply {
                            putExtra("sms_body", distressText)
                        }
                        val launched = runCatching {
                            context.startActivity(smsIntent)
                        }.isSuccess
                        if (!launched) {
                            runCatching {
                                val fallback = Intent(Intent.ACTION_SEND).apply {
                                    type = "text/plain"
                                    putExtra(Intent.EXTRA_TEXT, distressText)
                                }
                                context.startActivity(Intent.createChooser(fallback, strings.sosSheetTitle))
                            }
                        }
                    } else if (inAppCount == 0) {
                        runCatching {
                            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                type = "text/plain"
                                putExtra(Intent.EXTRA_TEXT, distressText)
                            }
                            context.startActivity(Intent.createChooser(shareIntent, strings.sosSheetTitle))
                        }
                    }
                }
            },
            colors = ButtonDefaults.buttonColors(
                containerColor = Color(0xFFD32F2F),
                contentColor = Color.White
            ),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(54.dp)
                .testTag("sos_send_button")
        ) {
            Icon(Icons.Rounded.Warning, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = strings.sendSosSignalLabel,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        }

        // Secondary Actions: Share via Apps + Dial 112 + Close
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedButton(
                onClick = {
                    val text = ThumbWayRepository.buildSosDistressMessage(
                        sender = currentUser,
                        latitude = uiState.liveLocation.latitude,
                        longitude = uiState.liveLocation.longitude,
                        localityLabel = uiState.liveLocation.localityLabel,
                        customNote = customNote
                    )
                    runCatching {
                        val shareIntent = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_TEXT, text)
                        }
                        context.startActivity(Intent.createChooser(shareIntent, strings.sosSheetTitle))
                    }
                },
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp)
                    .testTag("sos_share_intent_button")
            ) {
                Icon(Icons.Rounded.Share, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(strings.shareDistressLabel, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }

            OutlinedButton(
                onClick = {
                    runCatching {
                        context.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:112")))
                    }
                },
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .height(48.dp)
                    .testTag("sos_dial_helpline_button")
            ) {
                Icon(Icons.Rounded.Phone, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(strings.callHelplineLabel, maxLines = 1)
            }
        }

        Spacer(modifier = Modifier.height(6.dp))
    }
}
