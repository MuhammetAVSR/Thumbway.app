package com.example.ui.viewmodel

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.ChatMessageEntity
import com.example.data.local.ChatMessageType
import com.example.data.local.EmergencyContactEntity
import com.example.data.local.MapNoteEntity
import com.example.data.local.PhotoStorageHelper
import com.example.data.local.PostEntity
import com.example.data.local.SpotType
import com.example.data.local.ThumbWayDatabase
import com.example.data.local.TravelRouteEntity
import com.example.data.local.UserEntity
import com.example.data.local.UserPreferencesDataStore
import java.io.File
import com.example.data.location.LiveLocationState
import com.example.data.location.LocationTracker
import com.example.data.location.RouteStop
import com.example.data.remote.MapWeatherState
import com.example.data.remote.NearbyBusiness
import com.example.data.remote.NearbyPlacesRepository
import com.example.data.remote.PlaceSearchRepository
import com.example.data.remote.PlaceSearchResult
import com.example.data.remote.WeatherRepository
import com.example.data.repository.ThumbWayRepository
import com.example.ui.i18n.AppLanguage
import com.example.ui.theme.ThemeMode
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class ThumbWayUiState(
    val isReady: Boolean = false,
    val currentUser: UserEntity? = null,
    val allUsers: List<UserEntity> = emptyList(),
    val followedIds: Set<String> = emptySet(),
    val blockedIds: Set<String> = emptySet(),
    val blockedUsers: List<UserEntity> = emptyList(),
    val followedTravelersSharing: List<UserEntity> = emptyList(),
    val visibleMapNotes: List<MapNoteEntity> = emptyList(),
    val hiddenNoteCount: Int = 0,
    val followingFeedPosts: List<PostEntity> = emptyList(),
    val savedPosts: List<PostEntity> = emptyList(),
    val savedPostIds: Set<String> = emptySet(),
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val language: AppLanguage = AppLanguage.EN,
    val liveLocation: LiveLocationState = LiveLocationState(),
    val nearbyBusinesses: List<NearbyBusiness> = emptyList(),
    val isLoadingBusinesses: Boolean = false,
    val businessError: String? = null,
    val placeSearchResults: List<PlaceSearchResult> = emptyList(),
    val isSearchingPlaces: Boolean = false,
    val placeSearchError: String? = null,
    val savedRoutes: List<TravelRouteEntity> = emptyList(),
    val friendUsers: List<UserEntity> = emptyList(),
    val chatMessages: List<ChatMessageEntity> = emptyList(),
    val emergencyContacts: List<EmergencyContactEntity> = emptyList(),
    val weatherState: MapWeatherState = MapWeatherState(),
    val userPostCounts: Map<String, Int> = emptyMap(),
    val authError: String? = null,
    val statusBanner: String? = null
)

private data class LocalSocialBundle(
    val currentUser: UserEntity?,
    val allUsers: List<UserEntity>,
    val followedIds: List<String>,
    val blockedIds: List<String>,
    val notes: List<MapNoteEntity>,
    val dismissedNoteIds: List<String>,
    val posts: List<PostEntity>,
    val savedPostIds: List<String>
)

private data class SettingsAndLocationBundle(
    val themeMode: ThemeMode,
    val language: AppLanguage,
    val location: LiveLocationState,
    val businesses: List<NearbyBusiness>,
    val loadingBusinesses: Boolean,
    val businessError: String?,
    val authError: String?,
    val statusBanner: String?,
    val isReady: Boolean
)

class ThumbWayViewModel(application: Application) : AndroidViewModel(application) {
    private val db = ThumbWayDatabase.getInstance(application)
    private val prefs = UserPreferencesDataStore(application)
    private val repository = ThumbWayRepository(db.dao(), prefs)
    private val placesRepository = NearbyPlacesRepository()
    private val placeSearchRepository = PlaceSearchRepository(application)
    private val weatherRepository = WeatherRepository()
    val locationTracker = LocationTracker(application)

    private val _nearbyBusinesses = MutableStateFlow<List<NearbyBusiness>>(emptyList())
    private val _isLoadingBusinesses = MutableStateFlow(false)
    private val _businessError = MutableStateFlow<String?>(null)
    private val _placeSearchResults = MutableStateFlow<List<PlaceSearchResult>>(emptyList())
    private val _isSearchingPlaces = MutableStateFlow(false)
    private val _placeSearchError = MutableStateFlow<String?>(null)
    private val _weatherState = MutableStateFlow(MapWeatherState())
    private val _authError = MutableStateFlow<String?>(null)
    private val _statusBanner = MutableStateFlow<String?>(null)
    private val _isReady = MutableStateFlow(false)

    private var searchJob: Job? = null
    private var weatherJob: Job? = null
    private var lastFetchedLat: Double? = null
    private var lastFetchedLng: Double? = null
    private var lastWeatherLat: Double? = null
    private var lastWeatherLng: Double? = null
    private var lastWeatherStopIds: List<String> = emptyList()

    init {
        viewModelScope.launch {
            repository.ensureSeeded()
            _isReady.value = true
        }
        if (locationTracker.hasLocationPermission()) {
            locationTracker.startUpdates()
        }
        // Sync live device coordinates to active user profile when available
        viewModelScope.launch {
            combine(
                repository.currentUser,
                locationTracker.locationState
            ) { user, loc -> user to loc }
                .collect { (user, loc) ->
                    if (user != null && loc.hasRealFix) {
                        repository.updateLiveLocation(user.id, loc.latitude, loc.longitude)
                    }
                }
        }
    }

    private val userAndSocialFlow = combine(
        repository.currentUser,
        repository.allUsers,
        repository.followedIds,
        repository.blockedIds
    ) { user, users, followed, blocked ->
        Quad(user, users, followed, blocked)
    }

    private val contentFlow = combine(
        repository.allMapNotes,
        repository.dismissedNoteIds,
        repository.allPosts,
        repository.savedPostIds
    ) { notes, dismissed, posts, saved ->
        Quad(notes, dismissed, posts, saved)
    }

    private val localSocialFlow = combine(userAndSocialFlow, contentFlow) { social, content ->
        LocalSocialBundle(
            currentUser = social.first,
            allUsers = social.second,
            followedIds = social.third,
            blockedIds = social.fourth,
            notes = content.first,
            dismissedNoteIds = content.second,
            posts = content.third,
            savedPostIds = content.fourth
        )
    }

    private val metaFlow = combine(
        repository.themeMode,
        repository.language,
        locationTracker.locationState,
        _nearbyBusinesses,
        _isLoadingBusinesses
    ) { theme, lang, loc, biz, loading ->
        Penta(theme, lang, loc, biz, loading)
    }

    private val feedbackFlow = combine(
        _businessError,
        _authError,
        _statusBanner,
        _isReady
    ) { bizErr, authErr, banner, ready ->
        Quad(bizErr, authErr, banner, ready)
    }

    private val settingsAndLocationFlow = combine(metaFlow, feedbackFlow) { meta, fb ->
        SettingsAndLocationBundle(
            themeMode = meta.first,
            language = meta.second,
            location = meta.third,
            businesses = meta.fourth,
            loadingBusinesses = meta.fifth,
            businessError = fb.first,
            authError = fb.second,
            statusBanner = fb.third,
            isReady = fb.fourth
        )
    }

    private val searchBundleFlow = combine(
        _placeSearchResults,
        _isSearchingPlaces,
        _placeSearchError,
        repository.savedRoutes,
        repository.chatMessagesForCurrentUser
    ) { results, searching, error, routes, chatMessages ->
        Penta(results, searching, error, routes, chatMessages)
    }

    val uiState: StateFlow<ThumbWayUiState> = combine(
        localSocialFlow,
        settingsAndLocationFlow,
        searchBundleFlow,
        repository.emergencyContacts,
        _weatherState
    ) { social, env, search, emergencyContacts, weather ->
        val me = social.currentUser
        val blockedSet = social.blockedIds.toSet()
        val followedSet = social.followedIds.toSet()
        val dismissedSet = social.dismissedNoteIds.toSet()
        val savedSet = social.savedPostIds.toSet()

        val unblockedNotes = social.notes.filter { it.authorId !in blockedSet }
        val visibleNotes = unblockedNotes.filter { it.id !in dismissedSet }
        val hiddenCount = unblockedNotes.size - visibleNotes.size

        val followingFeed = social.posts.filter { post ->
            post.authorId !in blockedSet &&
                (post.authorId == me?.id || post.authorId in followedSet)
        }
        val savedPosts = social.posts.filter { post ->
            post.id in savedSet && post.authorId !in blockedSet
        }
        val otherUsers = social.allUsers.filter { it.id != me?.id }
        val friendUsers = otherUsers.filter { traveler ->
            traveler.id in followedSet && traveler.id !in blockedSet
        }
        val followedSharing = friendUsers.filter { traveler ->
            traveler.isLocationSharingEnabled &&
                traveler.latitude != null &&
                traveler.longitude != null
        }
        val blockedUsers = social.allUsers.filter { it.id in blockedSet }
        val visibleChatMessages = search.fifth.filter { msg ->
            msg.senderId !in blockedSet && msg.recipientId !in blockedSet
        }
        val postCountsByAuthor = social.posts.groupingBy { it.authorId }.eachCount()

        ThumbWayUiState(
            isReady = env.isReady,
            currentUser = me,
            allUsers = otherUsers,
            followedIds = followedSet,
            blockedIds = blockedSet,
            blockedUsers = blockedUsers,
            followedTravelersSharing = followedSharing,
            visibleMapNotes = visibleNotes,
            hiddenNoteCount = hiddenCount,
            followingFeedPosts = followingFeed,
            savedPosts = savedPosts,
            savedPostIds = savedSet,
            themeMode = env.themeMode,
            language = env.language,
            liveLocation = env.location,
            nearbyBusinesses = env.businesses,
            isLoadingBusinesses = env.loadingBusinesses,
            businessError = env.businessError,
            placeSearchResults = search.first,
            isSearchingPlaces = search.second,
            placeSearchError = search.third,
            savedRoutes = search.fourth,
            friendUsers = friendUsers,
            chatMessages = visibleChatMessages,
            emergencyContacts = emergencyContacts,
            weatherState = weather,
            userPostCounts = postCountsByAuthor,
            authError = env.authError,
            statusBanner = env.statusBanner
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000L),
        initialValue = ThumbWayUiState()
    )

    fun onLocationPermissionGranted() {
        locationTracker.startUpdates()
    }

    fun clearAuthError() {
        _authError.value = null
    }

    fun clearStatusBanner() {
        _statusBanner.value = null
    }

    fun createProfile(
        username: String,
        displayName: String,
        password: String,
        aboutUs: String,
        avatarUri: Uri?
    ) {
        viewModelScope.launch {
            _authError.value = null
            val persistedUri = avatarUri?.let {
                PhotoStorageHelper.persistPickerUri(getApplication(), it)
            }
            val loc = locationTracker.locationState.value
            val result = repository.createProfile(
                username = username,
                displayName = displayName,
                password = password,
                aboutUs = aboutUs,
                avatarUri = persistedUri,
                lat = loc.latitude,
                lng = loc.longitude
            )
            result.onFailure { _authError.value = it.message ?: "Could not create profile." }
        }
    }

    fun login(username: String, password: String) {
        viewModelScope.launch {
            _authError.value = null
            repository.login(username, password)
                .onFailure { _authError.value = it.message ?: "Login failed." }
        }
    }

    fun quickLogin(userId: String) {
        viewModelScope.launch {
            _authError.value = null
            repository.quickLoginExisting(userId)
                .onFailure { _authError.value = it.message ?: "Login failed." }
        }
    }

    fun logout() {
        viewModelScope.launch {
            repository.logout()
        }
    }

    fun setThemeMode(mode: ThemeMode) {
        viewModelScope.launch { repository.setThemeMode(mode) }
    }

    fun setLanguage(language: AppLanguage) {
        viewModelScope.launch { repository.setLanguage(language) }
    }

    fun updateProfile(displayName: String, aboutUs: String, newAvatarUri: Uri?) {
        val user = uiState.value.currentUser ?: return
        viewModelScope.launch {
            val finalAvatar = if (newAvatarUri != null) {
                PhotoStorageHelper.persistPickerUri(getApplication(), newAvatarUri) ?: user.avatarUri
            } else {
                user.avatarUri
            }
            repository.updateProfile(user.id, displayName, aboutUs, finalAvatar)
                .onSuccess { _statusBanner.value = "Profile updated" }
                .onFailure { _statusBanner.value = it.message ?: "Update failed" }
        }
    }

    fun updatePassword(currentPassword: String, newPassword: String, onDone: (Boolean, String) -> Unit) {
        val user = uiState.value.currentUser ?: return
        viewModelScope.launch {
            repository.updatePassword(user.id, currentPassword, newPassword)
                .onSuccess { onDone(true, "Password updated") }
                .onFailure { onDone(false, it.message ?: "Password update failed") }
        }
    }

    fun toggleLocationSharing(enabled: Boolean) {
        val user = uiState.value.currentUser ?: return
        viewModelScope.launch {
            repository.setLocationSharing(user.id, enabled)
        }
    }

    fun syncTsmLocation() {
        val user = uiState.value.currentUser ?: return
        val updated = locationTracker.syncTsmToCurrent()
        viewModelScope.launch {
            repository.updateTsmLocation(
                user.id,
                updated.tsmLatitude,
                updated.tsmLongitude,
                updated.tsmLabel
            )
            _statusBanner.value = "TSM location synced"
        }
    }

    fun pinTsmLocationAt(lat: Double, lng: Double, label: String?) {
        val user = uiState.value.currentUser ?: return
        val updated = locationTracker.updateTsmPoint(lat, lng, label)
        viewModelScope.launch {
            repository.updateTsmLocation(
                user.id,
                updated.tsmLatitude,
                updated.tsmLongitude,
                updated.tsmLabel
            )
            _statusBanner.value = "TSM marker updated"
        }
    }

    fun refreshNearbyBusinesses(lat: Double, lng: Double, force: Boolean = false) {
        val prevLat = lastFetchedLat
        val prevLng = lastFetchedLng
        if (!force && prevLat != null && prevLng != null) {
            val moved = NearbyPlacesRepository.distanceMeters(prevLat, prevLng, lat, lng)
            if (moved < 500 && _nearbyBusinesses.value.isNotEmpty()) return
        }
        lastFetchedLat = lat
        lastFetchedLng = lng
        viewModelScope.launch {
            _isLoadingBusinesses.value = true
            _businessError.value = null
            placesRepository.fetchNearbyBusinesses(lat, lng)
                .onSuccess { list ->
                    _nearbyBusinesses.value = list
                }
                .onFailure { err ->
                    _businessError.value = err.message ?: "Unable to fetch nearby businesses"
                }
            _isLoadingBusinesses.value = false
        }
    }

    fun searchPlaces(query: String, centerLat: Double, centerLng: Double, immediate: Boolean = false) {
        searchJob?.cancel()
        val trimmed = query.trim()
        if (trimmed.length < 2) {
            _placeSearchResults.value = emptyList()
            _isSearchingPlaces.value = false
            _placeSearchError.value = null
            return
        }
        searchJob = viewModelScope.launch {
            if (!immediate) delay(350L)
            _isSearchingPlaces.value = true
            _placeSearchError.value = null
            placeSearchRepository.searchPlaces(
                query = trimmed,
                centerLat = centerLat,
                centerLng = centerLng,
                languageCode = uiState.value.language.code,
                cachedBusinesses = _nearbyBusinesses.value
            ).onSuccess { results ->
                _placeSearchResults.value = results
            }.onFailure { err ->
                _placeSearchError.value = err.message ?: "Search failed"
                _placeSearchResults.value = emptyList()
            }
            _isSearchingPlaces.value = false
        }
    }

    fun clearPlaceSearch() {
        searchJob?.cancel()
        _placeSearchResults.value = emptyList()
        _isSearchingPlaces.value = false
        _placeSearchError.value = null
    }

    fun refreshMapWeather(
        centerLat: Double,
        centerLng: Double,
        centerLabel: String,
        routeStops: List<RouteStop>,
        force: Boolean = false
    ) {
        val stopIds = routeStops.map { it.id }
        val prevLat = lastWeatherLat
        val prevLng = lastWeatherLng
        val elapsedMs = System.currentTimeMillis() - _weatherState.value.lastUpdatedAtMs
        if (!force &&
            prevLat != null &&
            prevLng != null &&
            stopIds == lastWeatherStopIds &&
            elapsedMs < 300_000L &&
            _weatherState.value.primaryWeather != null
        ) {
            val moved = NearbyPlacesRepository.distanceMeters(prevLat, prevLng, centerLat, centerLng)
            if (moved < 2000) return
        }
        lastWeatherLat = centerLat
        lastWeatherLng = centerLng
        lastWeatherStopIds = stopIds

        weatherJob?.cancel()
        weatherJob = viewModelScope.launch {
            _weatherState.value = _weatherState.value.copy(isLoading = true, error = null)
            weatherRepository.fetchMapWeather(
                centerLat = centerLat,
                centerLng = centerLng,
                centerLabel = centerLabel,
                routeStops = routeStops
            ).onSuccess { fresh ->
                _weatherState.value = fresh
            }.onFailure { err ->
                _weatherState.value = _weatherState.value.copy(
                    isLoading = false,
                    error = err.message ?: "Unable to fetch weather"
                )
            }
        }
    }

    fun addMapNote(
        title: String,
        noteText: String,
        spotType: SpotType,
        lat: Double,
        lng: Double,
        locationLabel: String,
        photoUri: Uri?,
        prePersistedPath: String? = null
    ) {
        val user = uiState.value.currentUser ?: return
        viewModelScope.launch {
            val persistedPhoto = prePersistedPath ?: photoUri?.let {
                PhotoStorageHelper.persistPickerUri(getApplication(), it)
            }
            repository.addMapNote(
                author = user,
                title = title,
                noteText = noteText,
                spotType = spotType,
                latitude = lat,
                longitude = lng,
                locationLabel = locationLabel,
                photoUri = persistedPhoto
            )
            _statusBanner.value = "Map note bubble pinned"
        }
    }

    fun dismissNoteBubble(noteId: String) {
        val user = uiState.value.currentUser ?: return
        viewModelScope.launch {
            repository.dismissNoteBubble(user.id, noteId)
        }
    }

    fun restoreDismissedNotes() {
        val user = uiState.value.currentUser ?: return
        viewModelScope.launch {
            repository.restoreDismissedNotes(user.id)
        }
    }

    fun deleteMapNote(noteId: String) {
        viewModelScope.launch {
            repository.deleteMapNote(noteId)
        }
    }

    fun toggleFollow(targetUserId: String) {
        val me = uiState.value.currentUser ?: return
        val currentlyFollowing = targetUserId in uiState.value.followedIds
        viewModelScope.launch {
            repository.toggleFollow(me.id, targetUserId, currentlyFollowing)
        }
    }

    fun blockUser(targetUserId: String) {
        val me = uiState.value.currentUser ?: return
        viewModelScope.launch {
            repository.blockUser(me.id, targetUserId)
            _statusBanner.value = "User blocked"
        }
    }

    fun unblockUser(targetUserId: String) {
        val me = uiState.value.currentUser ?: return
        viewModelScope.launch {
            repository.unblockUser(me.id, targetUserId)
            _statusBanner.value = "User unblocked"
        }
    }

    fun createPost(
        caption: String,
        photoUri: Uri?,
        prePersistedPath: String? = null,
        locationName: String?,
        lat: Double?,
        lng: Double?
    ) {
        val user = uiState.value.currentUser ?: return
        viewModelScope.launch {
            val persistedPhoto = prePersistedPath ?: photoUri?.let {
                PhotoStorageHelper.persistPickerUri(getApplication(), it)
            }
            repository.createPost(
                author = user,
                caption = caption,
                photoUri = persistedPhoto,
                locationName = locationName,
                latitude = lat,
                longitude = lng
            )
            _statusBanner.value = "Post published"
        }
    }

    fun deletePost(postId: String) {
        viewModelScope.launch {
            repository.deletePost(postId)
        }
    }

    fun toggleSavePost(postId: String) {
        val user = uiState.value.currentUser ?: return
        val saved = postId in uiState.value.savedPostIds
        viewModelScope.launch {
            repository.toggleSavePost(user.id, postId, saved)
        }
    }

    fun saveTravelRoute(routeId: String?, title: String, stops: List<RouteStop>, onSaved: (TravelRouteEntity) -> Unit = {}) {
        val user = uiState.value.currentUser ?: return
        viewModelScope.launch {
            repository.saveTravelRoute(user.id, routeId, title, stops)
                .onSuccess { saved ->
                    _statusBanner.value = "Route saved (${saved.title})"
                    onSaved(saved)
                }
        }
    }

    fun deleteTravelRoute(routeId: String) {
        viewModelScope.launch {
            repository.deleteTravelRoute(routeId)
        }
    }

    fun sendTextChatMessage(recipientId: String, text: String) {
        val me = uiState.value.currentUser ?: return
        viewModelScope.launch {
            repository.sendChatMessage(
                senderId = me.id,
                recipientId = recipientId,
                type = ChatMessageType.TEXT,
                text = text
            )
        }
    }

    fun sendMediaChatMessage(recipientId: String, uri: Uri, caption: String = "") {
        val me = uiState.value.currentUser ?: return
        viewModelScope.launch {
            val persisted = PhotoStorageHelper.persistChatMediaUri(getApplication(), uri)
            if (persisted == null) {
                _statusBanner.value = "Could not attach media"
                return@launch
            }
            val msgType = if (persisted.isVideo) ChatMessageType.VIDEO else ChatMessageType.PHOTO
            val durationMs = if (persisted.isVideo) {
                PhotoStorageHelper.getMediaDurationMs(getApplication(), persisted.uriString)
            } else {
                0L
            }
            repository.sendChatMessage(
                senderId = me.id,
                recipientId = recipientId,
                type = msgType,
                text = caption,
                mediaUri = persisted.uriString,
                durationMs = durationMs
            )
        }
    }

    fun sendPersistedPhotoChatMessage(recipientId: String, persistedUri: String, caption: String = "") {
        val me = uiState.value.currentUser ?: return
        viewModelScope.launch {
            repository.sendChatMessage(
                senderId = me.id,
                recipientId = recipientId,
                type = ChatMessageType.PHOTO,
                text = caption,
                mediaUri = persistedUri
            )
        }
    }

    fun sendPersistedVideoChatMessage(recipientId: String, persistedUri: String, caption: String = "") {
        val me = uiState.value.currentUser ?: return
        viewModelScope.launch {
            val durationMs = PhotoStorageHelper.getMediaDurationMs(getApplication(), persistedUri)
            repository.sendChatMessage(
                senderId = me.id,
                recipientId = recipientId,
                type = ChatMessageType.VIDEO,
                text = caption,
                mediaUri = persistedUri,
                durationMs = durationMs
            )
        }
    }

    fun sendAudioChatMessage(recipientId: String, audioFilePath: String, recordedDurationMs: Long) {
        val me = uiState.value.currentUser ?: return
        viewModelScope.launch {
            val uriString = Uri.fromFile(File(audioFilePath)).toString()
            val measured = PhotoStorageHelper.getMediaDurationMs(getApplication(), uriString)
            val finalDuration = if (measured > 0L) measured else recordedDurationMs
            repository.sendChatMessage(
                senderId = me.id,
                recipientId = recipientId,
                type = ChatMessageType.AUDIO,
                mediaUri = uriString,
                durationMs = finalDuration
            )
        }
    }

    fun deleteChatMessage(messageId: String) {
        viewModelScope.launch {
            repository.deleteChatMessage(messageId)
        }
    }

    fun addEmergencyContact(name: String, phoneNumber: String) {
        val me = uiState.value.currentUser ?: return
        viewModelScope.launch {
            repository.addEmergencyContact(
                ownerId = me.id,
                name = name,
                phoneNumber = phoneNumber
            ).onSuccess {
                _statusBanner.value = "Emergency contact added"
            }.onFailure { err ->
                _statusBanner.value = err.message ?: "Could not add contact"
            }
        }
    }

    fun removeEmergencyContact(contactId: String) {
        viewModelScope.launch {
            repository.removeEmergencyContact(contactId)
        }
    }

    fun toggleFriendEmergencyContact(friend: UserEntity) {
        val me = uiState.value.currentUser ?: return
        val existing = uiState.value.emergencyContacts.firstOrNull { it.linkedFriendId == friend.id }
        viewModelScope.launch {
            if (existing != null) {
                repository.removeEmergencyContact(existing.id)
            } else {
                repository.addEmergencyContact(
                    ownerId = me.id,
                    name = friend.displayName,
                    phoneNumber = "",
                    linkedFriendId = friend.id
                )
            }
        }
    }

    fun sendInAppSosSignal(
        customNote: String,
        onPrepared: (distressText: String, phoneNumbers: List<String>, inAppCount: Int) -> Unit
    ) {
        val state = uiState.value
        val me = state.currentUser ?: return
        val loc = state.liveLocation
        val distressText = ThumbWayRepository.buildSosDistressMessage(
            sender = me,
            latitude = loc.latitude,
            longitude = loc.longitude,
            localityLabel = loc.localityLabel,
            customNote = customNote
        )
        val linkedFriendIds = state.emergencyContacts.mapNotNull { it.linkedFriendId }
        val phoneNumbers = state.emergencyContacts
            .map { it.phoneNumber.trim() }
            .filter { it.isNotBlank() }

        viewModelScope.launch {
            val sentCount = repository.dispatchInAppSos(
                senderId = me.id,
                recipientFriendIds = linkedFriendIds,
                distressMessage = distressText
            )
            onPrepared(distressText, phoneNumbers, sentCount)
        }
    }

    override fun onCleared() {
        super.onCleared()
        locationTracker.stopUpdates()
    }
}

private data class Quad<A, B, C, D>(val first: A, val second: B, val third: C, val fourth: D)
private data class Penta<A, B, C, D, E>(val first: A, val second: B, val third: C, val fourth: D, val fifth: E)
