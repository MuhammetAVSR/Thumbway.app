package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.Chat
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.rounded.CameraAlt
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.PermMedia
import androidx.compose.material.icons.rounded.PhotoLibrary
import androidx.compose.material.icons.rounded.Videocam
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.example.data.local.ChatMessageEntity
import com.example.data.local.ChatMessageType
import com.example.data.local.PhotoStorageHelper
import com.example.data.local.UserEntity
import com.example.ui.components.TravelerAvatar
import com.example.ui.components.TravelerLevelBadge
import com.example.ui.i18n.AppStrings
import com.example.ui.i18n.stringsFor
import com.example.ui.viewmodel.ThumbWayUiState
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File

@Composable
fun ChatScreen(
    uiState: ThumbWayUiState,
    initialFriendId: String?,
    onBack: () -> Unit,
    onOpenCommunityTravelers: () -> Unit,
    onSendText: (recipientId: String, text: String) -> Unit,
    onSendMediaUri: (recipientId: String, uri: Uri, caption: String) -> Unit,
    onSendPersistedPhoto: (recipientId: String, persistedUri: String, caption: String) -> Unit,
    onSendPersistedVideo: (recipientId: String, persistedUri: String, caption: String) -> Unit,
    onSendAudio: (recipientId: String, audioFilePath: String, durationMs: Long) -> Unit,
    onDeleteMessage: (messageId: String) -> Unit
) {
    val currentUser = uiState.currentUser ?: return
    val strings = stringsFor(uiState.language)
    val friends = uiState.friendUsers
    var selectedFriendId by remember(initialFriendId) { mutableStateOf(initialFriendId) }
    val selectedFriend = remember(friends, selectedFriendId) {
        friends.firstOrNull { it.id == selectedFriendId }
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val isExpanded = maxWidth >= 720.dp
        if (isExpanded) {
            Row(modifier = Modifier.fillMaxSize()) {
                FriendsListWindow(
                    friends = friends,
                    currentUserId = currentUser.id,
                    userPostCounts = uiState.userPostCounts,
                    allMessages = uiState.chatMessages,
                    selectedFriendId = selectedFriend?.id,
                    strings = strings,
                    onBack = onBack,
                    onSelectFriend = { selectedFriendId = it.id },
                    onFindTravelers = onOpenCommunityTravelers,
                    modifier = Modifier
                        .width(320.dp)
                        .fillMaxHeight()
                )
                HorizontalDivider(
                    modifier = Modifier
                        .width(1.dp)
                        .fillMaxHeight()
                )
                Box(modifier = Modifier.weight(1f).fillMaxHeight()) {
                    if (selectedFriend == null) {
                        Box(
                            modifier = Modifier.fillMaxSize(),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = strings.selectFriendHint,
                                style = MaterialTheme.typography.bodyLarge,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    } else {
                        FriendConversationWindow(
                            currentUser = currentUser,
                            friend = selectedFriend,
                            friendPostCount = uiState.userPostCounts[selectedFriend.id] ?: 0,
                            messages = uiState.chatMessages.filter {
                                (it.senderId == currentUser.id && it.recipientId == selectedFriend.id) ||
                                    (it.senderId == selectedFriend.id && it.recipientId == currentUser.id)
                            },
                            strings = strings,
                            showBackButton = false,
                            onBack = { selectedFriendId = null },
                            onSendText = { onSendText(selectedFriend.id, it) },
                            onSendMediaUri = { uri -> onSendMediaUri(selectedFriend.id, uri, "") },
                            onSendPersistedPhoto = { uri -> onSendPersistedPhoto(selectedFriend.id, uri, "") },
                            onSendPersistedVideo = { uri -> onSendPersistedVideo(selectedFriend.id, uri, "") },
                            onSendAudio = { path, dur -> onSendAudio(selectedFriend.id, path, dur) },
                            onDeleteMessage = onDeleteMessage
                        )
                    }
                }
            }
        } else {
            if (selectedFriend != null) {
                BackHandler { selectedFriendId = null }
                FriendConversationWindow(
                    currentUser = currentUser,
                    friend = selectedFriend,
                    friendPostCount = uiState.userPostCounts[selectedFriend.id] ?: 0,
                    messages = uiState.chatMessages.filter {
                        (it.senderId == currentUser.id && it.recipientId == selectedFriend.id) ||
                            (it.senderId == selectedFriend.id && it.recipientId == currentUser.id)
                    },
                    strings = strings,
                    showBackButton = true,
                    onBack = { selectedFriendId = null },
                    onSendText = { onSendText(selectedFriend.id, it) },
                    onSendMediaUri = { uri -> onSendMediaUri(selectedFriend.id, uri, "") },
                    onSendPersistedPhoto = { uri -> onSendPersistedPhoto(selectedFriend.id, uri, "") },
                    onSendPersistedVideo = { uri -> onSendPersistedVideo(selectedFriend.id, uri, "") },
                    onSendAudio = { path, dur -> onSendAudio(selectedFriend.id, path, dur) },
                    onDeleteMessage = onDeleteMessage
                )
            } else {
                FriendsListWindow(
                    friends = friends,
                    currentUserId = currentUser.id,
                    userPostCounts = uiState.userPostCounts,
                    allMessages = uiState.chatMessages,
                    selectedFriendId = null,
                    strings = strings,
                    onBack = onBack,
                    onSelectFriend = { selectedFriendId = it.id },
                    onFindTravelers = onOpenCommunityTravelers,
                    modifier = Modifier.fillMaxSize()
                )
            }
        }
    }
}

@Composable
private fun FriendsListWindow(
    friends: List<UserEntity>,
    currentUserId: String,
    userPostCounts: Map<String, Int>,
    allMessages: List<ChatMessageEntity>,
    selectedFriendId: String?,
    strings: AppStrings,
    onBack: () -> Unit,
    onSelectFriend: (UserEntity) -> Unit,
    onFindTravelers: () -> Unit,
    modifier: Modifier = Modifier
) {
    Scaffold(
        modifier = modifier,
        topBar = {
            Surface(tonalElevation = 2.dp) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .statusBarsPadding()
                        .padding(horizontal = 8.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier
                            .size(48.dp)
                            .testTag("chat_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                            contentDescription = strings.cancel
                        )
                    }
                    Spacer(modifier = Modifier.width(4.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = strings.chatTitle,
                            style = MaterialTheme.typography.titleLarge
                        )
                        Text(
                            text = "${strings.friendsLabel} (${friends.size})",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        if (friends.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Surface(
                        shape = CircleShape,
                        color = MaterialTheme.colorScheme.secondaryContainer,
                        modifier = Modifier.size(64.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Rounded.Chat,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onSecondaryContainer,
                                modifier = Modifier.size(30.dp)
                            )
                        }
                    }
                    Text(
                        text = strings.noFriendsYet,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Button(
                        onClick = onFindTravelers,
                        modifier = Modifier.height(48.dp),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Text(strings.findTravelers)
                    }
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(friends, key = { it.id }) { friend ->
                    val lastMessage = allMessages.lastOrNull {
                        (it.senderId == currentUserId && it.recipientId == friend.id) ||
                            (it.senderId == friend.id && it.recipientId == currentUserId)
                    }
                    val previewText = when (lastMessage?.let { ChatMessageType.fromCode(it.type) }) {
                        ChatMessageType.TEXT -> lastMessage.text
                        ChatMessageType.PHOTO -> strings.photoMessageLabel
                        ChatMessageType.VIDEO -> strings.videoMessageLabel
                        ChatMessageType.AUDIO -> strings.audioMessageLabel
                        null -> "@${friend.username}"
                    }
                    val isSelected = selectedFriendId == friend.id

                    Surface(
                        shape = RoundedCornerShape(18.dp),
                        color = if (isSelected) {
                            MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.65f)
                        } else {
                            MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(18.dp))
                            .clickable { onSelectFriend(friend) }
                            .testTag("chat_friend_${friend.id}")
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            TravelerAvatar(
                                displayName = friend.displayName,
                                avatarUri = friend.avatarUri,
                                size = 48.dp
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = friend.displayName,
                                        style = MaterialTheme.typography.titleMedium,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        modifier = Modifier.weight(1f)
                                    )
                                    if (lastMessage != null) {
                                        Text(
                                            text = formatMessageTime(lastMessage.createdAt),
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.height(2.dp))
                                TravelerLevelBadge(
                                    postCount = userPostCounts[friend.id] ?: 0,
                                    strings = strings,
                                    compact = true
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = previewText,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun FriendConversationWindow(
    currentUser: UserEntity,
    friend: UserEntity,
    friendPostCount: Int,
    messages: List<ChatMessageEntity>,
    strings: AppStrings,
    showBackButton: Boolean,
    onBack: () -> Unit,
    onSendText: (String) -> Unit,
    onSendMediaUri: (Uri) -> Unit,
    onSendPersistedPhoto: (String) -> Unit,
    onSendPersistedVideo: (String) -> Unit,
    onSendAudio: (filePath: String, durationMs: Long) -> Unit,
    onDeleteMessage: (String) -> Unit
) {
    val context = LocalContext.current
    val focusManager = LocalFocusManager.current
    val keyboardController = LocalSoftwareKeyboardController.current
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }
    val listState = rememberLazyListState()

    var draftText by remember(friend.id) { mutableStateOf("") }
    var showAttachmentMenu by remember { mutableStateOf(false) }
    var previewPhotoUri by remember { mutableStateOf<String?>(null) }
    var previewVideoUri by remember { mutableStateOf<String?>(null) }

    // Camera capture pending URIs
    var pendingCameraPhotoPath by remember { mutableStateOf<String?>(null) }
    var pendingCameraVideoPath by remember { mutableStateOf<String?>(null) }
    var pendingCameraAction by remember { mutableStateOf<Int?>(null) } // 1 = photo, 2 = video

    // Audio recording state
    var isRecording by remember { mutableStateOf(false) }
    var recordingStartMs by remember { mutableLongStateOf(0L) }
    var recordingElapsedMs by remember { mutableLongStateOf(0L) }
    var activeRecorder by remember { mutableStateOf<MediaRecorder?>(null) }
    var activeAudioFile by remember { mutableStateOf<File?>(null) }

    // Audio playback state
    var mediaPlayer by remember { mutableStateOf<MediaPlayer?>(null) }
    var playingMessageId by remember { mutableStateOf<String?>(null) }
    var playingProgress by remember { mutableStateOf(0f) }

    fun stopAudioPlayback() {
        runCatching {
            mediaPlayer?.stop()
        }
        runCatching {
            mediaPlayer?.release()
        }
        mediaPlayer = null
        playingMessageId = null
        playingProgress = 0f
    }

    fun startRecordingAudio() {
        stopAudioPlayback()
        val file = PhotoStorageHelper.createAudioOutputFile(context)
        try {
            @Suppress("DEPRECATION")
            val recorder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                MediaRecorder(context)
            } else {
                MediaRecorder()
            }
            recorder.apply {
                setAudioSource(MediaRecorder.AudioSource.MIC)
                setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                setAudioEncodingBitRate(96_000)
                setAudioSamplingRate(44_100)
                setOutputFile(file.absolutePath)
                prepare()
                start()
            }
            activeRecorder = recorder
            activeAudioFile = file
            recordingStartMs = System.currentTimeMillis()
            recordingElapsedMs = 0L
            isRecording = true
        } catch (_: Exception) {
            runCatching { file.delete() }
            activeRecorder = null
            activeAudioFile = null
            isRecording = false
            scope.launch {
                snackbarHostState.showSnackbar(strings.micPermissionNeeded)
            }
        }
    }

    fun cancelRecordingAudio() {
        runCatching { activeRecorder?.stop() }
        runCatching { activeRecorder?.release() }
        activeRecorder = null
        runCatching { activeAudioFile?.delete() }
        activeAudioFile = null
        isRecording = false
        recordingElapsedMs = 0L
    }

    fun stopAndSendAudio() {
        val recorder = activeRecorder
        val file = activeAudioFile
        val elapsed = (System.currentTimeMillis() - recordingStartMs).coerceAtLeast(recordingElapsedMs)
        activeRecorder = null
        activeAudioFile = null
        isRecording = false
        recordingElapsedMs = 0L
        if (recorder == null || file == null) return
        val stoppedCleanly = runCatching {
            recorder.stop()
        }.isSuccess
        runCatching { recorder.release() }
        if (stoppedCleanly && file.exists() && file.length() > 0L) {
            onSendAudio(file.absolutePath, elapsed)
        } else {
            runCatching { file.delete() }
        }
    }

    DisposableEffect(friend.id) {
        onDispose {
            focusManager.clearFocus(force = true)
            keyboardController?.hide()
            stopAudioPlayback()
            cancelRecordingAudio()
        }
    }

    LaunchedEffect(isRecording) {
        while (isRecording) {
            recordingElapsedMs = System.currentTimeMillis() - recordingStartMs
            delay(200L)
        }
    }

    LaunchedEffect(playingMessageId) {
        while (playingMessageId != null) {
            val mp = mediaPlayer
            if (mp != null && runCatching { mp.isPlaying }.getOrDefault(false)) {
                val dur = runCatching { mp.duration }.getOrDefault(1).coerceAtLeast(1)
                val pos = runCatching { mp.currentPosition }.getOrDefault(0)
                playingProgress = pos.toFloat() / dur.toFloat()
            }
            delay(150L)
        }
    }

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.lastIndex)
        }
    }

    val mediaPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) onSendMediaUri(uri)
    }

    val cameraPhotoLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.TakePicture()
    ) { success ->
        val path = pendingCameraPhotoPath
        pendingCameraPhotoPath = null
        if (success && !path.isNullOrBlank()) {
            onSendPersistedPhoto(path)
        }
    }

    val cameraVideoLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CaptureVideo()
    ) { success ->
        val path = pendingCameraVideoPath
        pendingCameraVideoPath = null
        if (success && !path.isNullOrBlank()) {
            onSendPersistedVideo(path)
        }
    }

    val cameraPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        val action = pendingCameraAction
        pendingCameraAction = null
        if (granted) {
            when (action) {
                1 -> {
                    val (contentUri, fileUri) = PhotoStorageHelper.createCameraOutputUri(context)
                    pendingCameraPhotoPath = fileUri
                    cameraPhotoLauncher.launch(contentUri)
                }
                2 -> {
                    val (contentUri, fileUri) = PhotoStorageHelper.createCameraVideoOutputUri(context)
                    pendingCameraVideoPath = fileUri
                    cameraVideoLauncher.launch(contentUri)
                }
            }
        }
    }

    val micPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            startRecordingAudio()
        } else {
            scope.launch {
                snackbarHostState.showSnackbar(strings.micPermissionNeeded)
            }
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            Surface(tonalElevation = 2.dp) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .statusBarsPadding()
                        .padding(horizontal = 8.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (showBackButton) {
                        IconButton(
                            onClick = {
                                focusManager.clearFocus(force = true)
                                keyboardController?.hide()
                                onBack()
                            },
                            modifier = Modifier
                                .size(48.dp)
                                .testTag("chat_thread_back_button")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                                contentDescription = strings.cancel
                            )
                        }
                    } else {
                        Spacer(modifier = Modifier.width(8.dp))
                    }
                    TravelerAvatar(
                        displayName = friend.displayName,
                        avatarUri = friend.avatarUri,
                        size = 40.dp
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(2.dp)
                    ) {
                        Text(
                            text = friend.displayName,
                            style = MaterialTheme.typography.titleMedium,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        TravelerLevelBadge(
                            postCount = friendPostCount,
                            strings = strings,
                            compact = true
                        )
                    }
                }
            }
        },
        bottomBar = {
            Surface(
                tonalElevation = 4.dp,
                shadowElevation = 8.dp
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .navigationBarsPadding()
                        .imePadding()
                        .padding(horizontal = 10.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (isRecording) {
                        IconButton(
                            onClick = { cancelRecordingAudio() },
                            modifier = Modifier
                                .size(48.dp)
                                .testTag("chat_cancel_audio_button")
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Delete,
                                contentDescription = strings.cancel,
                                tint = MaterialTheme.colorScheme.error
                            )
                        }
                        Surface(
                            shape = RoundedCornerShape(20.dp),
                            color = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.6f),
                            modifier = Modifier.weight(1f)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(10.dp)
                                            .clip(CircleShape)
                                            .background(MaterialTheme.colorScheme.error)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = strings.recordingAudioLabel,
                                        style = MaterialTheme.typography.labelLarge,
                                        color = MaterialTheme.colorScheme.onErrorContainer
                                    )
                                }
                                Text(
                                    text = formatDuration(recordingElapsedMs),
                                    style = MaterialTheme.typography.titleSmall,
                                    color = MaterialTheme.colorScheme.onErrorContainer
                                )
                            }
                        }
                        Surface(
                            shape = CircleShape,
                            color = MaterialTheme.colorScheme.primary
                        ) {
                            IconButton(
                                onClick = { stopAndSendAudio() },
                                modifier = Modifier
                                    .size(48.dp)
                                    .testTag("chat_send_audio_button")
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Rounded.Send,
                                    contentDescription = strings.stopAndSendLabel,
                                    tint = MaterialTheme.colorScheme.onPrimary
                                )
                            }
                        }
                    } else {
                        Box {
                            IconButton(
                                onClick = { showAttachmentMenu = true },
                                modifier = Modifier
                                    .size(48.dp)
                                    .testTag("chat_attach_media_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.PermMedia,
                                    contentDescription = strings.sendPhotoOrVideo,
                                    tint = MaterialTheme.colorScheme.primary
                                )
                            }
                            DropdownMenu(
                                expanded = showAttachmentMenu,
                                onDismissRequest = { showAttachmentMenu = false }
                            ) {
                                DropdownMenuItem(
                                    text = { Text(strings.sendPhotoOrVideo) },
                                    leadingIcon = { Icon(Icons.Rounded.PhotoLibrary, contentDescription = null) },
                                    onClick = {
                                        showAttachmentMenu = false
                                        mediaPicker.launch(
                                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo)
                                        )
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text(strings.capturePhotoLabel) },
                                    leadingIcon = { Icon(Icons.Rounded.CameraAlt, contentDescription = null) },
                                    onClick = {
                                        showAttachmentMenu = false
                                        val hasCam = ContextCompat.checkSelfPermission(
                                            context,
                                            Manifest.permission.CAMERA
                                        ) == PackageManager.PERMISSION_GRANTED
                                        if (hasCam) {
                                            val (contentUri, fileUri) = PhotoStorageHelper.createCameraOutputUri(context)
                                            pendingCameraPhotoPath = fileUri
                                            cameraPhotoLauncher.launch(contentUri)
                                        } else {
                                            pendingCameraAction = 1
                                            cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
                                        }
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text(strings.recordVideoLabel) },
                                    leadingIcon = { Icon(Icons.Rounded.Videocam, contentDescription = null) },
                                    onClick = {
                                        showAttachmentMenu = false
                                        val hasCam = ContextCompat.checkSelfPermission(
                                            context,
                                            Manifest.permission.CAMERA
                                        ) == PackageManager.PERMISSION_GRANTED
                                        if (hasCam) {
                                            val (contentUri, fileUri) = PhotoStorageHelper.createCameraVideoOutputUri(context)
                                            pendingCameraVideoPath = fileUri
                                            cameraVideoLauncher.launch(contentUri)
                                        } else {
                                            pendingCameraAction = 2
                                            cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
                                        }
                                    }
                                )
                            }
                        }

                        OutlinedTextField(
                            value = draftText,
                            onValueChange = { draftText = it },
                            placeholder = { Text(strings.typeMessageHint, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                            maxLines = 4,
                            shape = RoundedCornerShape(24.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("chat_message_input")
                        )

                        if (draftText.isNotBlank()) {
                            Surface(
                                shape = CircleShape,
                                color = MaterialTheme.colorScheme.primary
                            ) {
                                IconButton(
                                    onClick = {
                                        val msg = draftText
                                        draftText = ""
                                        onSendText(msg)
                                    },
                                    modifier = Modifier
                                        .size(48.dp)
                                        .testTag("chat_send_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.AutoMirrored.Rounded.Send,
                                        contentDescription = strings.sendLabel,
                                        tint = MaterialTheme.colorScheme.onPrimary
                                    )
                                }
                            }
                        } else {
                            Surface(
                                shape = CircleShape,
                                color = MaterialTheme.colorScheme.secondaryContainer
                            ) {
                                IconButton(
                                    onClick = {
                                        val hasMic = ContextCompat.checkSelfPermission(
                                            context,
                                            Manifest.permission.RECORD_AUDIO
                                        ) == PackageManager.PERMISSION_GRANTED
                                        if (hasMic) {
                                            startRecordingAudio()
                                        } else {
                                            micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                        }
                                    },
                                    modifier = Modifier
                                        .size(48.dp)
                                        .testTag("chat_record_audio_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.Mic,
                                        contentDescription = strings.recordAudioLabel,
                                        tint = MaterialTheme.colorScheme.onSecondaryContainer
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    ) { innerPadding ->
        if (messages.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = strings.noMessagesYet,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding),
                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(messages, key = { it.id }) { message ->
                    val isPlayingThis = playingMessageId == message.id
                    ChatMessageBubble(
                        message = message,
                        isMine = message.senderId == currentUser.id,
                        strings = strings,
                        isAudioPlaying = isPlayingThis,
                        audioProgress = if (isPlayingThis) playingProgress else 0f,
                        onToggleAudio = {
                            if (isPlayingThis) {
                                stopAudioPlayback()
                            } else {
                                val uri = message.mediaUri ?: return@ChatMessageBubble
                                stopAudioPlayback()
                                try {
                                    val player = MediaPlayer().apply {
                                        setDataSource(context, Uri.parse(uri))
                                        setOnCompletionListener {
                                            stopAudioPlayback()
                                        }
                                        prepare()
                                        start()
                                    }
                                    mediaPlayer = player
                                    playingMessageId = message.id
                                    playingProgress = 0f
                                } catch (_: Exception) {
                                    stopAudioPlayback()
                                }
                            }
                        },
                        onOpenPhoto = { previewPhotoUri = it },
                        onOpenVideo = { previewVideoUri = it },
                        onDelete = { onDeleteMessage(message.id) }
                    )
                }
            }
        }
    }

    previewPhotoUri?.let { uri ->
        PhotoPreviewDialog(
            photoUri = uri,
            closeContentDescription = strings.cancel,
            onDismiss = { previewPhotoUri = null }
        )
    }

    previewVideoUri?.let { uri ->
        VideoPlayerDialog(
            videoUri = uri,
            closeContentDescription = strings.cancel,
            onDismiss = { previewVideoUri = null }
        )
    }
}
