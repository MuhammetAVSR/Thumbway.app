package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.layout.heightIn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.AddAPhoto
import androidx.compose.material.icons.rounded.AddLocationAlt
import androidx.compose.material.icons.rounded.AltRoute
import androidx.compose.material.icons.rounded.ArrowUpward
import androidx.compose.material.icons.rounded.Block
import androidx.compose.material.icons.rounded.Bookmarks
import androidx.compose.material.icons.rounded.CameraAlt
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Cloud
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.DirectionsCar
import androidx.compose.material.icons.rounded.DirectionsWalk
import androidx.compose.material.icons.rounded.Explore
import androidx.compose.material.icons.rounded.Landscape
import androidx.compose.material.icons.rounded.LocalCafe
import androidx.compose.material.icons.rounded.LocalGasStation
import androidx.compose.material.icons.rounded.MyLocation
import androidx.compose.material.icons.rounded.NotificationsActive
import androidx.compose.material.icons.rounded.PersonPinCircle
import androidx.compose.material.icons.rounded.PhotoLibrary
import androidx.compose.material.icons.rounded.PinDrop
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Remove
import androidx.compose.material.icons.rounded.Restaurant
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.Storefront
import androidx.compose.material.icons.rounded.Straighten
import androidx.compose.material.icons.rounded.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SmallFloatingActionButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.BuildConfig
import com.example.data.local.MapNoteEntity
import com.example.data.local.PhotoStorageHelper
import com.example.data.local.SpotType
import com.example.data.local.TravelRouteEntity
import com.example.data.local.UserEntity
import com.example.data.location.GeoMeasurementHelper
import com.example.data.location.RouteStop
import com.example.data.remote.BusinessCategory
import com.example.data.remote.NearbyBusiness
import com.example.data.remote.NearbyPlacesRepository
import com.example.data.remote.PlaceSearchResult
import com.example.data.remote.WeatherPointOverlay
import com.example.ui.components.InteractiveTileMap
import com.example.ui.components.TravelerAvatar
import com.example.ui.i18n.AppStrings
import com.example.ui.i18n.stringsFor
import com.example.ui.viewmodel.ThumbWayUiState
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.model.BitmapDescriptorFactory
import com.google.android.gms.maps.model.CameraPosition
import com.google.android.gms.maps.model.Dash
import com.google.android.gms.maps.model.Gap
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.UrlTileProvider
import com.google.maps.android.compose.GoogleMap
import com.google.maps.android.compose.MapProperties
import com.google.maps.android.compose.MapUiSettings
import com.google.maps.android.compose.Marker
import com.google.maps.android.compose.MarkerState
import com.google.maps.android.compose.Polyline
import com.google.maps.android.compose.TileOverlay
import com.google.maps.android.compose.rememberCameraPositionState
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MapScreen(
    uiState: ThumbWayUiState,
    focusLat: Double?,
    focusLng: Double?,
    onBack: () -> Unit,
    onLocationPermissionGranted: () -> Unit,
    onRefreshBusinesses: (lat: Double, lng: Double, force: Boolean) -> Unit,
    onSyncTsm: () -> Unit,
    onPinTsmAt: (lat: Double, lng: Double, label: String?) -> Unit,
    onAddNote: (
        title: String,
        noteText: String,
        spotType: SpotType,
        lat: Double,
        lng: Double,
        locationLabel: String,
        photoUri: Uri?,
        prePersistedPath: String?
    ) -> Unit,
    onDismissBubble: (noteId: String) -> Unit,
    onRestoreBubbles: () -> Unit,
    onDeleteNote: (noteId: String) -> Unit,
    onBlockUser: (userId: String) -> Unit,
    onSearchPlaces: (query: String, centerLat: Double, centerLng: Double, immediate: Boolean) -> Unit,
    onClearPlaceSearch: () -> Unit,
    onSaveRoute: (routeId: String?, title: String, stops: List<RouteStop>, onSaved: (TravelRouteEntity) -> Unit) -> Unit,
    onDeleteRoute: (routeId: String) -> Unit,
    onAddEmergencyContact: (name: String, phone: String) -> Unit,
    onRemoveEmergencyContact: (contactId: String) -> Unit,
    onToggleFriendEmergencyContact: (UserEntity) -> Unit,
    onSendSosSignal: (
        customNote: String,
        onPrepared: (distressText: String, phoneNumbers: List<String>, inAppCount: Int) -> Unit
    ) -> Unit,
    onRefreshWeather: (
        centerLat: Double,
        centerLng: Double,
        centerLabel: String,
        routeStops: List<RouteStop>,
        force: Boolean
    ) -> Unit
) {
    val strings = stringsFor(uiState.language)
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val density = LocalDensity.current
    val focusManager = LocalFocusManager.current
    val keyboardController = LocalSoftwareKeyboardController.current

    DisposableEffect(Unit) {
        onDispose {
            focusManager.clearFocus(force = true)
            keyboardController?.hide()
        }
    }

    var hasLocationPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
                ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        )
    }
    val locationLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { perms ->
        val granted = perms[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
            perms[Manifest.permission.ACCESS_COARSE_LOCATION] == true
        hasLocationPermission = granted
        if (granted) onLocationPermissionGranted()
    }

    val initialTarget = remember(focusLat, focusLng) {
        LatLng(
            focusLat ?: uiState.liveLocation.latitude,
            focusLng ?: uiState.liveLocation.longitude
        )
    }
    val cameraPositionState = rememberCameraPositionState {
        position = CameraPosition.fromLatLngZoom(initialTarget, 15.2f)
    }

    var showBusinesses by remember { mutableStateOf(true) }
    var showFollowers by remember { mutableStateOf(true) }
    var showNotes by remember { mutableStateOf(true) }

    var pendingPinLocation by remember { mutableStateOf<LatLng?>(null) }
    var pendingPinLabel by remember { mutableStateOf("") }
    var pendingPinSpotType by remember { mutableStateOf(SpotType.ROADSIDE) }
    var showAddNoteSheet by remember { mutableStateOf(false) }

    var selectedNoteForDetail by remember { mutableStateOf<MapNoteEntity?>(null) }
    var selectedBusiness by remember { mutableStateOf<NearbyBusiness?>(null) }
    var selectedFollower by remember { mutableStateOf<UserEntity?>(null) }

    var isMeasureMode by remember { mutableStateOf(false) }
    var measuredTarget by remember { mutableStateOf<LatLng?>(null) }
    var measuredTargetLabel by remember { mutableStateOf<String?>(null) }
    var useImperialUnits by remember { mutableStateOf(false) }

    var isRouteMode by remember { mutableStateOf(false) }
    var activeRouteId by remember { mutableStateOf<String?>(null) }
    var activeRouteTitle by remember { mutableStateOf("") }
    var routeStops by remember { mutableStateOf<List<RouteStop>>(emptyList()) }
    var showSavedRoutesSheet by remember { mutableStateOf(false) }
    var showSaveRouteDialog by remember { mutableStateOf(false) }
    var pendingRouteTitleInput by remember { mutableStateOf("") }
    var showSosSheet by remember { mutableStateOf(false) }
    var showWeatherOverlay by remember { mutableStateOf(true) }
    var showWeatherSheet by remember { mutableStateOf(false) }
    var focusedWeatherPoint by remember { mutableStateOf<WeatherPointOverlay?>(null) }

    val routeSummary = remember(routeStops) {
        GeoMeasurementHelper.measureRoute(routeStops)
    }

    val activeMeasurement = remember(
        uiState.liveLocation.latitude,
        uiState.liveLocation.longitude,
        measuredTarget
    ) {
        measuredTarget?.let { target ->
            GeoMeasurementHelper.measure(
                fromLat = uiState.liveLocation.latitude,
                fromLng = uiState.liveLocation.longitude,
                toLat = target.latitude,
                toLng = target.longitude
            )
        }
    }
    val measuredBadgeLabel = activeMeasurement?.let {
        if (useImperialUnits) it.milesFormatted else it.metricFormatted
    }

    fun startMeasureTo(latLng: LatLng, label: String?) {
        isRouteMode = false
        isMeasureMode = true
        measuredTarget = latLng
        measuredTargetLabel = label?.takeIf { it.isNotBlank() }
            ?: String.format(Locale.US, "%.4f, %.4f", latLng.latitude, latLng.longitude)
        pendingPinLocation = null
    }

    fun addRouteStop(lat: Double, lng: Double, label: String?) {
        isMeasureMode = false
        measuredTarget = null
        measuredTargetLabel = null
        isRouteMode = true
        pendingPinLocation = null
        val stopLabel = label?.takeIf { it.isNotBlank() }
            ?: "Stop ${routeStops.size + 1} (${String.format(Locale.US, "%.3f, %.3f", lat, lng)})"
        routeStops = routeStops + RouteStop(
            id = "stop_${UUID.randomUUID()}",
            label = stopLabel,
            latitude = lat,
            longitude = lng
        )
    }

    // Fetch real-time businesses when entering the map or camera settles significantly
    LaunchedEffect(initialTarget) {
        onRefreshBusinesses(initialTarget.latitude, initialTarget.longitude, true)
    }

    LaunchedEffect(cameraPositionState.isMoving) {
        if (!cameraPositionState.isMoving) {
            val target = cameraPositionState.position.target
            onRefreshBusinesses(target.latitude, target.longitude, false)
            if (showWeatherOverlay) {
                onRefreshWeather(
                    target.latitude,
                    target.longitude,
                    uiState.liveLocation.localityLabel,
                    routeStops,
                    false
                )
            }
        }
    }

    // Request location permission on first open if not yet granted
    LaunchedEffect(Unit) {
        if (!hasLocationPermission) {
            locationLauncher.launch(
                arrayOf(
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION
                )
            )
        }
    }

    val hasValidGoogleMapsKey = remember {
        BuildConfig.MAPS_API_KEY.isNotBlank() &&
            BuildConfig.MAPS_API_KEY != "MY_MAPS_API_KEY" &&
            !BuildConfig.MAPS_API_KEY.startsWith("MY_")
    }

    var fallbackCenterLat by remember { mutableStateOf(initialTarget.latitude) }
    var fallbackCenterLng by remember { mutableStateOf(initialTarget.longitude) }
    var fallbackZoom by remember { mutableStateOf(15.2f) }

    LaunchedEffect(fallbackCenterLat, fallbackCenterLng, hasValidGoogleMapsKey) {
        if (!hasValidGoogleMapsKey) {
            delay(400L)
            onRefreshBusinesses(fallbackCenterLat, fallbackCenterLng, false)
            if (showWeatherOverlay) {
                onRefreshWeather(
                    fallbackCenterLat,
                    fallbackCenterLng,
                    uiState.liveLocation.localityLabel,
                    routeStops,
                    false
                )
            }
        }
    }

    LaunchedEffect(showWeatherOverlay, routeStops) {
        if (showWeatherOverlay) {
            val target = if (hasValidGoogleMapsKey) {
                cameraPositionState.position.target
            } else {
                LatLng(fallbackCenterLat, fallbackCenterLng)
            }
            onRefreshWeather(
                target.latitude,
                target.longitude,
                uiState.liveLocation.localityLabel,
                routeStops,
                true
            )
        }
    }

    var searchQuery by remember { mutableStateOf("") }
    var showSearchResultsDropdown by remember { mutableStateOf(false) }

    val mapProperties = remember(hasLocationPermission) {
        MapProperties(
            isMyLocationEnabled = hasLocationPermission,
            isBuildingEnabled = true
        )
    }
    val mapUiSettings = remember {
        MapUiSettings(
            zoomControlsEnabled = false,
            myLocationButtonEnabled = false,
            compassEnabled = true,
            zoomGesturesEnabled = true,
            scrollGesturesEnabled = true
        )
    }

    fun activeMapCenter(): LatLng = if (hasValidGoogleMapsKey) {
        cameraPositionState.position.target
    } else {
        LatLng(fallbackCenterLat, fallbackCenterLng)
    }

    fun selectPlaceResult(result: PlaceSearchResult) {
        focusManager.clearFocus()
        showSearchResultsDropdown = false
        val target = LatLng(result.latitude, result.longitude)
        when {
            isRouteMode -> addRouteStop(result.latitude, result.longitude, result.name)
            isMeasureMode -> {
                measuredTarget = target
                measuredTargetLabel = result.name
                pendingPinLocation = null
            }
            else -> {
                pendingPinLocation = target
                pendingPinLabel = result.name
                pendingPinSpotType = SpotType.BUSINESS
            }
        }
        onRefreshBusinesses(result.latitude, result.longitude, true)
        if (hasValidGoogleMapsKey) {
            scope.launch {
                cameraPositionState.animate(CameraUpdateFactory.newLatLngZoom(target, 16f))
            }
        } else {
            fallbackCenterLat = result.latitude
            fallbackCenterLng = result.longitude
            fallbackZoom = 16f
        }
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val maxWidthPx = with(density) { maxWidth.toPx() }
        val maxHeightPx = with(density) { maxHeight.toPx() }

        if (hasValidGoogleMapsKey) {
            GoogleMap(
            modifier = Modifier.fillMaxSize(),
            cameraPositionState = cameraPositionState,
            properties = mapProperties,
            uiSettings = mapUiSettings,
            onMapClick = { latLng ->
                showSearchResultsDropdown = false
                focusManager.clearFocus()
                val coordLabel = String.format(Locale.US, "%.4f, %.4f", latLng.latitude, latLng.longitude)
                when {
                    isRouteMode -> addRouteStop(latLng.latitude, latLng.longitude, coordLabel)
                    isMeasureMode -> {
                        measuredTarget = latLng
                        measuredTargetLabel = coordLabel
                    }
                    else -> {
                        pendingPinLocation = latLng
                        pendingPinLabel = coordLabel
                        pendingPinSpotType = SpotType.ROADSIDE
                    }
                }
            }
        ) {
            // Own live location marker (always synchronous even if system blue dot unavailable)
            Marker(
                state = MarkerState(
                    position = LatLng(uiState.liveLocation.latitude, uiState.liveLocation.longitude)
                ),
                title = uiState.currentUser?.displayName ?: "You",
                snippet = "Live GPS • ${uiState.liveLocation.localityLabel}",
                icon = BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_AZURE)
            )

            // Synchronized TSM Location marker
            Marker(
                state = MarkerState(
                    position = LatLng(uiState.liveLocation.tsmLatitude, uiState.liveLocation.tsmLongitude)
                ),
                title = strings.tsmLocationTitle,
                snippet = uiState.liveLocation.tsmLabel,
                icon = BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_GREEN)
            )

            // Followed travelers sharing live locations
            if (showFollowers) {
                uiState.followedTravelersSharing.forEach { traveler ->
                    val tLat = traveler.latitude ?: return@forEach
                    val tLng = traveler.longitude ?: return@forEach
                    Marker(
                        state = MarkerState(position = LatLng(tLat, tLng)),
                        title = traveler.displayName,
                        snippet = traveler.tsmLabel.ifBlank { "Live location" },
                        icon = BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_VIOLET),
                        onClick = {
                            selectedFollower = traveler
                            true
                        }
                    )
                }
            }

            // Real-time nearby businesses (from Overpass API)
            if (showBusinesses) {
                uiState.nearbyBusinesses.forEach { business ->
                    Marker(
                        state = MarkerState(position = LatLng(business.latitude, business.longitude)),
                        title = business.name,
                        snippet = "${business.category.label} • ${business.distanceMeters}m",
                        icon = BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_ORANGE),
                        onClick = {
                            selectedBusiness = business
                            true
                        }
                    )
                }
            }

            // Pin anchors for map notes
            if (showNotes) {
                uiState.visibleMapNotes.forEach { note ->
                    Marker(
                        state = MarkerState(position = LatLng(note.latitude, note.longitude)),
                        title = note.title,
                        snippet = note.authorName,
                        icon = BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_ROSE),
                        onClick = {
                            selectedNoteForDetail = note
                            true
                        }
                    )
                }
            }

            // Search result pins
            uiState.placeSearchResults.forEach { result ->
                Marker(
                    state = MarkerState(position = LatLng(result.latitude, result.longitude)),
                    title = result.name,
                    snippet = result.address.ifBlank { result.category },
                    icon = BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_MAGENTA),
                    onClick = {
                        selectPlaceResult(result)
                        true
                    }
                )
            }

            // Pending tapped point marker
            pendingPinLocation?.let { pin ->
                Marker(
                    state = MarkerState(position = pin),
                    title = "Selected Spot",
                    icon = BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_YELLOW)
                )
            }

            // Distance measurement polyline + target marker
            measuredTarget?.let { target ->
                val origin = LatLng(uiState.liveLocation.latitude, uiState.liveLocation.longitude)
                Polyline(
                    points = listOf(origin, target),
                    color = MaterialTheme.colorScheme.primary,
                    width = 10f,
                    geodesic = true,
                    pattern = listOf(Dash(28f), Gap(16f))
                )
                Marker(
                    state = MarkerState(position = target),
                    title = measuredBadgeLabel ?: strings.measureDistance,
                    snippet = measuredTargetLabel,
                    icon = BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_CYAN)
                )
            }

            // Multi-stop travel route polyline + numbered stop markers
            if (routeStops.isNotEmpty()) {
                if (routeStops.size >= 2) {
                    Polyline(
                        points = routeStops.map { LatLng(it.latitude, it.longitude) },
                        color = Color(0xFF00796B),
                        width = 12f,
                        geodesic = true
                    )
                }
                routeStops.forEachIndexed { index, stop ->
                    val hue = when (index) {
                        0 -> BitmapDescriptorFactory.HUE_GREEN
                        routeStops.lastIndex -> BitmapDescriptorFactory.HUE_RED
                        else -> BitmapDescriptorFactory.HUE_CYAN
                    }
                    Marker(
                        state = MarkerState(position = LatLng(stop.latitude, stop.longitude)),
                        title = "${index + 1}. ${stop.label}",
                        icon = BitmapDescriptorFactory.defaultMarker(hue)
                    )
                }
            }

            // Real-time RainViewer precipitation radar tile overlay + Open-Meteo weather markers
            val radarTemplate = uiState.weatherState.radarTileUrlTemplate
            if (showWeatherOverlay && !radarTemplate.isNullOrBlank()) {
                val tileProvider = remember(radarTemplate) {
                    object : UrlTileProvider(256, 256) {
                        override fun getTileUrl(x: Int, y: Int, zoom: Int): URL? {
                            if (zoom > 12) return null
                            val urlStr = radarTemplate
                                .replace("{z}", zoom.toString())
                                .replace("{x}", x.toString())
                                .replace("{y}", y.toString())
                            return runCatching { URL(urlStr) }.getOrNull()
                        }
                    }
                }
                TileOverlay(
                    tileProvider = tileProvider,
                    transparency = 0.45f
                )
            }
            if (showWeatherOverlay) {
                uiState.weatherState.overlayPoints.forEach { wp ->
                    Marker(
                        state = MarkerState(position = LatLng(wp.latitude, wp.longitude)),
                        title = "${wp.label}: ${wp.temperatureC.roundToInt()}°C • ${wp.conditionLabel}",
                        snippet = wp.hitchAdvisory,
                        icon = BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_CYAN),
                        onClick = {
                            focusedWeatherPoint = wp
                            showWeatherSheet = true
                            true
                        }
                    )
                }
            }
        }

        // Synchronous Floating Notification Bubbles for Map Notes!
        // Projected onto screen coordinates so both the "X" close button and body click work reliably.
        if (showNotes) {
            val projection = cameraPositionState.projection
            if (projection != null) {
                val bubbleWidthPx = with(density) { 196.dp.toPx() }
                val bubbleHeightOffsetPx = with(density) { 88.dp.toPx() }
                uiState.visibleMapNotes.forEach { note ->
                    key(note.id) {
                        val screenPt = projection.toScreenLocation(LatLng(note.latitude, note.longitude))
                        if (screenPt.x in -150..maxWidthPx.roundToInt() + 150 &&
                            screenPt.y in 80..maxHeightPx.roundToInt() - 80
                        ) {
                            val xPos = (screenPt.x - bubbleWidthPx / 2f).roundToInt()
                            val yPos = (screenPt.y - bubbleHeightOffsetPx).roundToInt()
                            MapNoteNotificationBubble(
                                note = note,
                                closeContentDesc = strings.closeNoteBubble,
                                onClick = { selectedNoteForDetail = note },
                                onClose = { onDismissBubble(note.id) },
                                modifier = Modifier
                                    .offset { IntOffset(xPos, yPos) }
                                    .testTag("note_bubble_${note.id}")
                            )
                        }
                    }
                }
            }
        }
        } else {
            InteractiveTileMap(
                centerLat = fallbackCenterLat,
                centerLng = fallbackCenterLng,
                zoom = fallbackZoom,
                liveLat = uiState.liveLocation.latitude,
                liveLng = uiState.liveLocation.longitude,
                tsmLat = uiState.liveLocation.tsmLatitude,
                tsmLng = uiState.liveLocation.tsmLongitude,
                showFollowers = showFollowers,
                followers = uiState.followedTravelersSharing,
                showBusinesses = showBusinesses,
                businesses = uiState.nearbyBusinesses,
                showNotes = showNotes,
                notes = uiState.visibleMapNotes,
                searchResults = uiState.placeSearchResults,
                pendingPin = pendingPinLocation,
                measuredTarget = measuredTarget,
                measuredDistanceLabel = measuredBadgeLabel,
                routeStops = routeStops,
                showWeather = showWeatherOverlay,
                weatherPoints = uiState.weatherState.overlayPoints,
                radarTileUrlTemplate = uiState.weatherState.radarTileUrlTemplate,
                onWeatherPointClick = { wp ->
                    focusedWeatherPoint = wp
                    showWeatherSheet = true
                },
                onPanZoom = { newLat, newLng, newZoom ->
                    fallbackCenterLat = newLat
                    fallbackCenterLng = newLng
                    fallbackZoom = newZoom
                },
                onTapCoordinate = { latLng ->
                    showSearchResultsDropdown = false
                    focusManager.clearFocus()
                    val coordLabel = String.format(Locale.US, "%.4f, %.4f", latLng.latitude, latLng.longitude)
                    when {
                        isRouteMode -> addRouteStop(latLng.latitude, latLng.longitude, coordLabel)
                        isMeasureMode -> {
                            measuredTarget = latLng
                            measuredTargetLabel = coordLabel
                        }
                        else -> {
                            pendingPinLocation = latLng
                            pendingPinLabel = coordLabel
                            pendingPinSpotType = SpotType.ROADSIDE
                        }
                    }
                },
                onFollowerClick = { traveler ->
                    val tLat = traveler.latitude
                    val tLng = traveler.longitude
                    when {
                        isRouteMode && tLat != null && tLng != null -> addRouteStop(tLat, tLng, traveler.displayName)
                        isMeasureMode && tLat != null && tLng != null -> startMeasureTo(LatLng(tLat, tLng), traveler.displayName)
                        else -> selectedFollower = traveler
                    }
                },
                onBusinessClick = { biz ->
                    when {
                        isRouteMode -> addRouteStop(biz.latitude, biz.longitude, biz.name)
                        isMeasureMode -> startMeasureTo(LatLng(biz.latitude, biz.longitude), biz.name)
                        else -> selectedBusiness = biz
                    }
                },
                onNoteClick = { note ->
                    when {
                        isRouteMode -> addRouteStop(note.latitude, note.longitude, note.title)
                        isMeasureMode -> startMeasureTo(LatLng(note.latitude, note.longitude), note.title)
                        else -> selectedNoteForDetail = note
                    }
                },
                onSearchResultClick = { selectPlaceResult(it) },
                noteBubbleOverlay = { note, sx, sy ->
                    val bubbleWidthPx = with(density) { 196.dp.toPx() }
                    val bubbleHeightOffsetPx = with(density) { 88.dp.toPx() }
                    val xPos = (sx - bubbleWidthPx / 2f).roundToInt()
                    val yPos = (sy - bubbleHeightOffsetPx).roundToInt()
                    MapNoteNotificationBubble(
                        note = note,
                        closeContentDesc = strings.closeNoteBubble,
                        onClick = { selectedNoteForDetail = note },
                        onClose = { onDismissBubble(note.id) },
                        modifier = Modifier
                            .offset { IntOffset(xPos, yPos) }
                            .testTag("note_bubble_${note.id}")
                    )
                }
            )
        }

        // Top Overlay: Back, TSM Location Status, Layer Filters
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Surface(
                    shape = CircleShape,
                    color = MaterialTheme.colorScheme.surface.copy(alpha = 0.94f),
                    shadowElevation = 4.dp
                ) {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier
                            .size(48.dp)
                            .testTag("map_back_button")
                    ) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Back")
                    }
                }

                // Live TSM Location Pill
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = MaterialTheme.colorScheme.surface.copy(alpha = 0.94f),
                    shadowElevation = 4.dp,
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(20.dp))
                        .clickable {
                            onSyncTsm()
                            if (hasValidGoogleMapsKey) {
                                scope.launch {
                                    cameraPositionState.animate(
                                        CameraUpdateFactory.newLatLngZoom(
                                            LatLng(uiState.liveLocation.latitude, uiState.liveLocation.longitude),
                                            15.5f
                                        )
                                    )
                                }
                            } else {
                                fallbackCenterLat = uiState.liveLocation.latitude
                                fallbackCenterLng = uiState.liveLocation.longitude
                                fallbackZoom = 15.5f
                            }
                        }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 9.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.PinDrop,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = uiState.liveLocation.tsmLabel,
                                style = MaterialTheme.typography.labelLarge,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = String.format(
                                    Locale.US,
                                    "TSM %.4f, %.4f",
                                    uiState.liveLocation.tsmLatitude,
                                    uiState.liveLocation.tsmLongitude
                                ),
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                // Prominent Emergency SOS Button
                Surface(
                    shape = RoundedCornerShape(24.dp),
                    color = Color(0xFFD32F2F),
                    shadowElevation = 6.dp,
                    modifier = Modifier
                        .height(48.dp)
                        .clip(RoundedCornerShape(24.dp))
                        .clickable { showSosSheet = true }
                        .testTag("map_sos_button")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(5.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Warning,
                            contentDescription = strings.sosSheetTitle,
                            tint = Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                        Text(
                            text = strings.sosButtonLabel,
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color.White
                        )
                    }
                }
            }

            // Google Places Search Bar
            Surface(
                shape = RoundedCornerShape(22.dp),
                color = MaterialTheme.colorScheme.surface.copy(alpha = 0.96f),
                shadowElevation = 5.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                TextField(
                    value = searchQuery,
                    onValueChange = { next ->
                        searchQuery = next
                        showSearchResultsDropdown = next.trim().length >= 2
                        val center = activeMapCenter()
                        onSearchPlaces(next, center.latitude, center.longitude, false)
                    },
                    placeholder = {
                        Text(
                            text = strings.searchPlacesHint,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Rounded.Search,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary
                        )
                    },
                    trailingIcon = {
                        if (uiState.isSearchingPlaces) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(20.dp),
                                strokeWidth = 2.dp
                            )
                        } else if (searchQuery.isNotEmpty()) {
                            IconButton(
                                onClick = {
                                    searchQuery = ""
                                    showSearchResultsDropdown = false
                                    onClearPlaceSearch()
                                    focusManager.clearFocus()
                                },
                                modifier = Modifier.testTag("clear_map_search_button")
                            ) {
                                Icon(Icons.Rounded.Close, contentDescription = strings.cancel)
                            }
                        }
                    },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    keyboardActions = KeyboardActions(
                        onSearch = {
                            val center = activeMapCenter()
                            showSearchResultsDropdown = searchQuery.trim().length >= 2
                            onSearchPlaces(searchQuery, center.latitude, center.longitude, true)
                            focusManager.clearFocus()
                        }
                    ),
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = Color.Transparent,
                        unfocusedContainerColor = Color.Transparent,
                        focusedIndicatorColor = Color.Transparent,
                        unfocusedIndicatorColor = Color.Transparent
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("map_search_input")
                )
            }

            // Search Results Dropdown
            if (showSearchResultsDropdown && searchQuery.trim().length >= 2) {
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = MaterialTheme.colorScheme.surface.copy(alpha = 0.98f),
                    shadowElevation = 8.dp,
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 240.dp)
                        .testTag("map_search_results_card")
                ) {
                    when {
                        uiState.isSearchingPlaces && uiState.placeSearchResults.isEmpty() -> {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                CircularProgressIndicator(modifier = Modifier.size(24.dp), strokeWidth = 2.dp)
                            }
                        }
                        uiState.placeSearchResults.isEmpty() -> {
                            Text(
                                text = uiState.placeSearchError ?: strings.noSearchResults,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(16.dp)
                            )
                        }
                        else -> {
                            LazyColumn {
                                items(uiState.placeSearchResults, key = { it.id }) { item ->
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable { selectPlaceResult(item) }
                                            .padding(horizontal = 14.dp, vertical = 10.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(
                                            imageVector = Icons.Rounded.PinDrop,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.size(20.dp)
                                        )
                                        Spacer(modifier = Modifier.width(10.dp))
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = item.name,
                                                style = MaterialTheme.typography.titleMedium,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                            Text(
                                                text = item.address.ifBlank { item.category },
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        }
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Column(horizontalAlignment = Alignment.End) {
                                            item.rating?.let { rating ->
                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                    Icon(
                                                        imageVector = Icons.Rounded.Star,
                                                        contentDescription = null,
                                                        tint = MaterialTheme.colorScheme.secondary,
                                                        modifier = Modifier.size(14.dp)
                                                    )
                                                    Spacer(modifier = Modifier.width(2.dp))
                                                    Text(
                                                        text = String.format(Locale.US, "%.1f", rating),
                                                        style = MaterialTheme.typography.labelSmall
                                                    )
                                                }
                                            }
                                            val distText = if (item.distanceMeters >= 1000) {
                                                String.format(Locale.US, "%.1f km", item.distanceMeters / 1000.0)
                                            } else {
                                                "${item.distanceMeters} m"
                                            }
                                            Text(
                                                text = distText,
                                                style = MaterialTheme.typography.labelSmall,
                                                color = MaterialTheme.colorScheme.primary
                                            )
                                        }
                                    }
                                    HorizontalDivider(thickness = 0.5.dp)
                                }
                            }
                        }
                    }
                }
            }

            // Filter Chips Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = showBusinesses,
                    onClick = { showBusinesses = !showBusinesses },
                    label = {
                        Text("${strings.nearbyBusinesses} (${uiState.nearbyBusinesses.size})")
                    },
                    leadingIcon = {
                        Icon(Icons.Rounded.Storefront, contentDescription = null, modifier = Modifier.size(16.dp))
                    }
                )
                FilterChip(
                    selected = showFollowers,
                    onClick = { showFollowers = !showFollowers },
                    label = {
                        Text("${strings.followersOnMap} (${uiState.followedTravelersSharing.size})")
                    },
                    leadingIcon = {
                        Icon(Icons.Rounded.PersonPinCircle, contentDescription = null, modifier = Modifier.size(16.dp))
                    }
                )
                FilterChip(
                    selected = showNotes,
                    onClick = { showNotes = !showNotes },
                    label = {
                        Text("${strings.mapNotesToggle} (${uiState.visibleMapNotes.size})")
                    },
                    leadingIcon = {
                        Icon(Icons.Rounded.NotificationsActive, contentDescription = null, modifier = Modifier.size(16.dp))
                    }
                )
                FilterChip(
                    selected = showWeatherOverlay,
                    onClick = { showWeatherOverlay = !showWeatherOverlay },
                    label = {
                        val temp = uiState.weatherState.primaryWeather?.temperatureC?.roundToInt()
                        Text(
                            if (temp != null) "${strings.weatherOverlayToggle} • ${temp}°C" else strings.weatherOverlayToggle
                        )
                    },
                    leadingIcon = {
                        Icon(Icons.Rounded.Cloud, contentDescription = null, modifier = Modifier.size(16.dp))
                    },
                    modifier = Modifier.testTag("map_weather_chip")
                )
                if (uiState.hiddenNoteCount > 0) {
                    FilterChip(
                        selected = false,
                        onClick = onRestoreBubbles,
                        label = { Text("${strings.restoreClosedNotes} (${uiState.hiddenNoteCount})") }
                    )
                }
            }

            if (showWeatherOverlay) {
                WeatherHudPill(
                    weatherState = uiState.weatherState,
                    strings = strings,
                    onClick = {
                        focusedWeatherPoint = uiState.weatherState.primaryWeather
                        showWeatherSheet = true
                    }
                )
            }

            if (!hasValidGoogleMapsKey) {
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.94f)
                ) {
                    Text(
                        text = "OpenStreetMap live preview active. Add your Google Maps key (MAPS_API_KEY) in AI Studio Secrets for Google Maps tiles.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSecondaryContainer,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                    )
                }
            }
        }

        // Right-side Zoom In / Out + My Location + Scan Area Controls
        Column(
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .padding(end = 12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            SmallFloatingActionButton(
                onClick = {
                    if (hasValidGoogleMapsKey) {
                        scope.launch { cameraPositionState.animate(CameraUpdateFactory.zoomIn()) }
                    } else {
                        fallbackZoom = (fallbackZoom + 1f).coerceIn(3f, 18f)
                    }
                },
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier
                    .size(48.dp)
                    .testTag("map_zoom_in_button")
            ) {
                Icon(Icons.Rounded.Add, contentDescription = "Zoom in")
            }
            SmallFloatingActionButton(
                onClick = {
                    if (hasValidGoogleMapsKey) {
                        scope.launch { cameraPositionState.animate(CameraUpdateFactory.zoomOut()) }
                    } else {
                        fallbackZoom = (fallbackZoom - 1f).coerceIn(3f, 18f)
                    }
                },
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier
                    .size(48.dp)
                    .testTag("map_zoom_out_button")
            ) {
                Icon(Icons.Rounded.Remove, contentDescription = "Zoom out")
            }
            SmallFloatingActionButton(
                onClick = {
                    if (hasValidGoogleMapsKey) {
                        scope.launch {
                            cameraPositionState.animate(
                                CameraUpdateFactory.newLatLngZoom(
                                    LatLng(uiState.liveLocation.latitude, uiState.liveLocation.longitude),
                                    15.8f
                                )
                            )
                        }
                    } else {
                        fallbackCenterLat = uiState.liveLocation.latitude
                        fallbackCenterLng = uiState.liveLocation.longitude
                        fallbackZoom = 15.8f
                    }
                },
                containerColor = MaterialTheme.colorScheme.primaryContainer,
                contentColor = MaterialTheme.colorScheme.onPrimaryContainer,
                modifier = Modifier
                    .size(48.dp)
                    .testTag("map_my_location_button")
            ) {
                Icon(Icons.Rounded.MyLocation, contentDescription = "Center on my location")
            }
            SmallFloatingActionButton(
                onClick = {
                    if (hasValidGoogleMapsKey) {
                        val target = cameraPositionState.position.target
                        onRefreshBusinesses(target.latitude, target.longitude, true)
                    } else {
                        onRefreshBusinesses(fallbackCenterLat, fallbackCenterLng, true)
                    }
                },
                containerColor = MaterialTheme.colorScheme.secondaryContainer,
                contentColor = MaterialTheme.colorScheme.onSecondaryContainer,
                modifier = Modifier
                    .size(48.dp)
                    .testTag("map_scan_businesses_button")
            ) {
                Icon(Icons.Rounded.Refresh, contentDescription = strings.refreshNearbyPlaces)
            }
            SmallFloatingActionButton(
                onClick = {
                    if (isMeasureMode) {
                        isMeasureMode = false
                        measuredTarget = null
                        measuredTargetLabel = null
                    } else {
                        isRouteMode = false
                        isMeasureMode = true
                        pendingPinLocation?.let { pin ->
                            measuredTarget = pin
                            measuredTargetLabel = pendingPinLabel.ifBlank {
                                String.format(Locale.US, "%.4f, %.4f", pin.latitude, pin.longitude)
                            }
                            pendingPinLocation = null
                        }
                    }
                },
                containerColor = if (isMeasureMode) {
                    MaterialTheme.colorScheme.primary
                } else {
                    MaterialTheme.colorScheme.surface
                },
                contentColor = if (isMeasureMode) {
                    MaterialTheme.colorScheme.onPrimary
                } else {
                    MaterialTheme.colorScheme.onSurface
                },
                modifier = Modifier
                    .size(48.dp)
                    .testTag("map_measure_toggle_button")
            ) {
                Icon(Icons.Rounded.Straighten, contentDescription = strings.measureDistance)
            }
            SmallFloatingActionButton(
                onClick = {
                    if (isRouteMode) {
                        isRouteMode = false
                    } else {
                        isMeasureMode = false
                        measuredTarget = null
                        measuredTargetLabel = null
                        isRouteMode = true
                        pendingPinLocation?.let { pin ->
                            addRouteStop(pin.latitude, pin.longitude, pendingPinLabel)
                        }
                    }
                },
                containerColor = if (isRouteMode) {
                    MaterialTheme.colorScheme.primary
                } else {
                    MaterialTheme.colorScheme.surface
                },
                contentColor = if (isRouteMode) {
                    MaterialTheme.colorScheme.onPrimary
                } else {
                    MaterialTheme.colorScheme.onSurface
                },
                modifier = Modifier
                    .size(48.dp)
                    .testTag("map_route_toggle_button")
            ) {
                Icon(Icons.Rounded.AltRoute, contentDescription = strings.routePlannerTitle)
            }
        }

        // Bottom Controls: Route Planner Card OR Distance Measurement Card OR Selected Map Point Action Bar OR "+ Add Note" FAB
        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            val pin = pendingPinLocation
            if (isRouteMode) {
                Surface(
                    shape = RoundedCornerShape(22.dp),
                    color = MaterialTheme.colorScheme.surface,
                    shadowElevation = 8.dp,
                    modifier = Modifier
                        .widthIn(max = 540.dp)
                        .fillMaxWidth()
                        .testTag("route_planner_card")
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.AltRoute,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = activeRouteTitle.ifBlank { strings.routePlannerTitle },
                                    style = MaterialTheme.typography.titleMedium,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = "${routeStops.size} ${strings.stopsLabel}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                            TextButton(
                                onClick = { showSavedRoutesSheet = true },
                                modifier = Modifier.testTag("open_saved_routes_button")
                            ) {
                                Icon(Icons.Rounded.Bookmarks, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("${strings.savedRoutesLabel} (${uiState.savedRoutes.size})")
                            }
                            IconButton(
                                onClick = { isRouteMode = false },
                                modifier = Modifier.testTag("close_route_mode_button")
                            ) {
                                Icon(Icons.Rounded.Close, contentDescription = strings.cancel)
                            }
                        }

                        if (routeStops.size >= 2) {
                            Surface(
                                shape = RoundedCornerShape(14.dp),
                                color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.7f),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(14.dp))
                                    .clickable { useImperialUnits = !useImperialUnits }
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(
                                            text = if (useImperialUnits) routeSummary.totalMilesFormatted else routeSummary.totalMetricFormatted,
                                            style = MaterialTheme.typography.titleLarge,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.onPrimaryContainer
                                        )
                                        Text(
                                            text = if (useImperialUnits) routeSummary.totalMetricFormatted else routeSummary.totalMilesFormatted,
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                                        )
                                    }
                                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(Icons.Rounded.DirectionsCar, contentDescription = null, modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.onPrimaryContainer)
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text(
                                                text = "${strings.hitchEstLabel}: ${GeoMeasurementHelper.formatDurationMinutes(routeSummary.totalRideMinutes)}",
                                                style = MaterialTheme.typography.labelMedium,
                                                color = MaterialTheme.colorScheme.onPrimaryContainer
                                            )
                                        }
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(Icons.Rounded.DirectionsWalk, contentDescription = null, modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.onPrimaryContainer)
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text(
                                                text = GeoMeasurementHelper.formatDurationMinutes(routeSummary.totalWalkMinutes),
                                                style = MaterialTheme.typography.labelMedium,
                                                color = MaterialTheme.colorScheme.onPrimaryContainer
                                            )
                                        }
                                    }
                                }
                            }
                        } else {
                            Text(
                                text = strings.tapToAddRouteStopsHint,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        if (routeStops.isNotEmpty()) {
                            LazyColumn(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .heightIn(max = 150.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                items(routeStops.size) { index ->
                                    val stop = routeStops[index]
                                    val leg = if (index > 0 && index - 1 < routeSummary.legs.size) {
                                        routeSummary.legs[index - 1]
                                    } else null
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(10.dp))
                                            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f))
                                            .padding(horizontal = 10.dp, vertical = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Surface(
                                            shape = CircleShape,
                                            color = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.size(22.dp)
                                        ) {
                                            Box(contentAlignment = Alignment.Center) {
                                                Text(
                                                    text = "${index + 1}",
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = MaterialTheme.colorScheme.onPrimary
                                                )
                                            }
                                        }
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = stop.label,
                                                style = MaterialTheme.typography.bodySmall,
                                                fontWeight = FontWeight.Medium,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                            if (leg != null) {
                                                val legDist = if (useImperialUnits) leg.milesFormatted else leg.metricFormatted
                                                Text(
                                                    text = "+$legDist (${GeoMeasurementHelper.formatDurationMinutes(leg.rideMinutes)} ${strings.drivingTimeLabel.lowercase()} • ${leg.compassDirection})",
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = MaterialTheme.colorScheme.primary
                                                )
                                            }
                                        }
                                        if (index > 0) {
                                            IconButton(
                                                onClick = {
                                                    val mutable = routeStops.toMutableList()
                                                    val prev = mutable[index - 1]
                                                    mutable[index - 1] = mutable[index]
                                                    mutable[index] = prev
                                                    routeStops = mutable
                                                },
                                                modifier = Modifier.size(30.dp)
                                            ) {
                                                Icon(Icons.Rounded.ArrowUpward, contentDescription = "Move stop up", modifier = Modifier.size(16.dp))
                                            }
                                        }
                                        IconButton(
                                            onClick = {
                                                routeStops = routeStops.filterNot { it.id == stop.id }
                                            },
                                            modifier = Modifier.size(30.dp)
                                        ) {
                                            Icon(Icons.Rounded.Close, contentDescription = "Remove stop", modifier = Modifier.size(16.dp))
                                        }
                                    }
                                }
                            }
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilledTonalButton(
                                onClick = {
                                    addRouteStop(
                                        uiState.liveLocation.latitude,
                                        uiState.liveLocation.longitude,
                                        uiState.liveLocation.localityLabel
                                    )
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .height(44.dp)
                                    .testTag("add_my_location_stop_button")
                            ) {
                                Text(strings.addMyLocationStop, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                            if (routeStops.isNotEmpty()) {
                                OutlinedButton(
                                    onClick = {
                                        activeRouteId = null
                                        activeRouteTitle = ""
                                        routeStops = emptyList()
                                    },
                                    modifier = Modifier.height(44.dp)
                                ) {
                                    Text(strings.clearMeasurement)
                                }
                            }
                            Button(
                                onClick = {
                                    pendingRouteTitleInput = activeRouteTitle.ifBlank {
                                        if (routeStops.size >= 2) "${routeStops.first().label} → ${routeStops.last().label}" else ""
                                    }
                                    showSaveRouteDialog = true
                                },
                                enabled = routeStops.size >= 2,
                                modifier = Modifier
                                    .weight(1f)
                                    .height(44.dp)
                                    .testTag("save_route_button")
                            ) {
                                Text(strings.saveRoute, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                        }
                    }
                }
            } else if (isMeasureMode) {
                Surface(
                    shape = RoundedCornerShape(22.dp),
                    color = MaterialTheme.colorScheme.surface,
                    shadowElevation = 8.dp,
                    modifier = Modifier
                        .widthIn(max = 520.dp)
                        .fillMaxWidth()
                        .testTag("distance_measure_card")
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Straighten,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = strings.measureDistance,
                                    style = MaterialTheme.typography.titleMedium
                                )
                                Text(
                                    text = measuredTargetLabel ?: strings.tapToMeasureHint,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            IconButton(
                                onClick = {
                                    isMeasureMode = false
                                    measuredTarget = null
                                    measuredTargetLabel = null
                                },
                                modifier = Modifier.testTag("close_measure_mode_button")
                            ) {
                                Icon(Icons.Rounded.Close, contentDescription = strings.cancel)
                            }
                        }

                        if (activeMeasurement != null && measuredTarget != null) {
                            val primaryDist = if (useImperialUnits) {
                                activeMeasurement.milesFormatted
                            } else {
                                activeMeasurement.metricFormatted
                            }
                            val secondaryDist = if (useImperialUnits) {
                                activeMeasurement.metricFormatted
                            } else {
                                activeMeasurement.milesFormatted
                            }
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Surface(
                                    shape = RoundedCornerShape(14.dp),
                                    color = MaterialTheme.colorScheme.primaryContainer,
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(14.dp))
                                        .clickable { useImperialUnits = !useImperialUnits }
                                        .testTag("measure_unit_toggle")
                                ) {
                                    Column(modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)) {
                                        Text(
                                            text = primaryDist,
                                            style = MaterialTheme.typography.headlineMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.onPrimaryContainer
                                        )
                                        Text(
                                            text = "$secondaryDist • ${strings.distanceFromYou}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                                        )
                                    }
                                }
                                Column(
                                    modifier = Modifier.weight(1f),
                                    verticalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = Icons.Rounded.Explore,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = "${strings.bearingLabel}: ${activeMeasurement.compassDirection} (${activeMeasurement.bearingDegrees.roundToInt()}°)",
                                            style = MaterialTheme.typography.bodySmall
                                        )
                                    }
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = Icons.Rounded.DirectionsWalk,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.secondary,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = "${strings.walkingTimeLabel}: ${GeoMeasurementHelper.formatDurationMinutes(activeMeasurement.walkMinutes)}",
                                            style = MaterialTheme.typography.bodySmall
                                        )
                                    }
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = Icons.Rounded.DirectionsCar,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.tertiary,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = "${strings.drivingTimeLabel}: ${GeoMeasurementHelper.formatDurationMinutes(activeMeasurement.driveMinutes)}",
                                            style = MaterialTheme.typography.bodySmall
                                        )
                                    }
                                }
                            }

                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                OutlinedButton(
                                    onClick = {
                                        measuredTarget = null
                                        measuredTargetLabel = null
                                    },
                                    modifier = Modifier.weight(1f).height(48.dp)
                                ) {
                                    Text(strings.clearMeasurement)
                                }
                                Button(
                                    onClick = {
                                        pendingPinLocation = measuredTarget
                                        pendingPinLabel = measuredTargetLabel ?: "Measured Spot"
                                        pendingPinSpotType = SpotType.ROADSIDE
                                        showAddNoteSheet = true
                                    },
                                    modifier = Modifier.weight(1f).height(48.dp)
                                ) {
                                    Text(strings.addNoteOnMap, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                            }
                        }
                    }
                }
            } else if (pin != null) {
                val pinMeasurement = remember(
                    uiState.liveLocation.latitude,
                    uiState.liveLocation.longitude,
                    pin
                ) {
                    GeoMeasurementHelper.measure(
                        uiState.liveLocation.latitude,
                        uiState.liveLocation.longitude,
                        pin.latitude,
                        pin.longitude
                    )
                }
                Surface(
                    shape = RoundedCornerShape(22.dp),
                    color = MaterialTheme.colorScheme.surface,
                    shadowElevation = 8.dp,
                    modifier = Modifier.widthIn(max = 520.dp).fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Rounded.AddLocationAlt, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.width(8.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = pendingPinLabel.ifBlank { "Selected Spot" },
                                    style = MaterialTheme.typography.titleMedium,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = "${pinMeasurement.metricFormatted} (${pinMeasurement.milesFormatted}) • ${pinMeasurement.compassDirection}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                            IconButton(onClick = { addRouteStop(pin.latitude, pin.longitude, pendingPinLabel) }) {
                                Icon(Icons.Rounded.AltRoute, contentDescription = strings.addStopToRoute)
                            }
                            IconButton(onClick = { startMeasureTo(pin, pendingPinLabel) }) {
                                Icon(Icons.Rounded.Straighten, contentDescription = strings.measureDistance)
                            }
                            IconButton(onClick = { pendingPinLocation = null }) {
                                Icon(Icons.Rounded.Close, contentDescription = strings.cancel)
                            }
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            OutlinedButton(
                                onClick = {
                                    onPinTsmAt(pin.latitude, pin.longitude, pendingPinLabel)
                                    pendingPinLocation = null
                                },
                                modifier = Modifier.weight(1f).height(48.dp)
                            ) {
                                Text(strings.syncTsmSpot, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                            Button(
                                onClick = { showAddNoteSheet = true },
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp)
                                    .testTag("pin_note_here_button")
                            ) {
                                Text(strings.addNoteOnMap, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                        }
                    }
                }
            } else {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.surface.copy(alpha = 0.9f),
                    shadowElevation = 2.dp
                ) {
                    Text(
                        text = strings.tapMapToDropNote,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                    )
                }

                ExtendedFloatingActionButton(
                    onClick = {
                        pendingPinLocation = LatLng(
                            uiState.liveLocation.latitude,
                            uiState.liveLocation.longitude
                        )
                        pendingPinLabel = uiState.liveLocation.localityLabel
                        pendingPinSpotType = SpotType.ROADSIDE
                        showAddNoteSheet = true
                    },
                    icon = { Icon(Icons.Rounded.AddLocationAlt, contentDescription = null) },
                    text = { Text(strings.addNoteOnMap) },
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary,
                    elevation = FloatingActionButtonDefaults.elevation(defaultElevation = 6.dp),
                    modifier = Modifier.testTag("add_map_note_fab")
                )
            }
        }
    }

    // SOS Emergency Distress Bottom Sheet
    if (showSosSheet) {
        val sosSheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
        val sheetFocusManager = LocalFocusManager.current
        val sheetKeyboardController = LocalSoftwareKeyboardController.current
        ModalBottomSheet(
            onDismissRequest = {
                sheetFocusManager.clearFocus(force = true)
                sheetKeyboardController?.hide()
                showSosSheet = false
            },
            sheetState = sosSheetState
        ) {
            SosEmergencySheetContent(
                uiState = uiState,
                strings = strings,
                onAddContact = onAddEmergencyContact,
                onRemoveContact = onRemoveEmergencyContact,
                onToggleFriendEmergencyContact = onToggleFriendEmergencyContact,
                onSendSosSignal = onSendSosSignal,
                onClose = {
                    sheetFocusManager.clearFocus(force = true)
                    sheetKeyboardController?.hide()
                    showSosSheet = false
                }
            )
        }
    }

    // Live Weather & Route Conditions Bottom Sheet
    if (showWeatherSheet) {
        val weatherSheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
        ModalBottomSheet(
            onDismissRequest = { showWeatherSheet = false },
            sheetState = weatherSheetState
        ) {
            WeatherConditionsSheetContent(
                weatherState = uiState.weatherState,
                focusedPoint = focusedWeatherPoint,
                strings = strings,
                onRefresh = {
                    val center = activeMapCenter()
                    onRefreshWeather(
                        center.latitude,
                        center.longitude,
                        uiState.liveLocation.localityLabel,
                        routeStops,
                        true
                    )
                }
            )
        }
    }

    // Add Note + Photo Modal Sheet
    if (showAddNoteSheet && pendingPinLocation != null) {
        val target = pendingPinLocation!!
        val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
        val sheetFocusManager = LocalFocusManager.current
        val sheetKeyboardController = LocalSoftwareKeyboardController.current
        ModalBottomSheet(
            onDismissRequest = {
                sheetFocusManager.clearFocus(force = true)
                sheetKeyboardController?.hide()
                showAddNoteSheet = false
            },
            sheetState = sheetState
        ) {
            AddMapNoteSheetContent(
                strings = strings,
                initialLabel = pendingPinLabel,
                initialSpotType = pendingPinSpotType,
                latitude = target.latitude,
                longitude = target.longitude,
                onSubmit = { title, body, spotType, label, photoUri, prePersisted ->
                    sheetFocusManager.clearFocus(force = true)
                    sheetKeyboardController?.hide()
                    onAddNote(title, body, spotType, target.latitude, target.longitude, label, photoUri, prePersisted)
                    showAddNoteSheet = false
                    pendingPinLocation = null
                },
                onCancel = {
                    sheetFocusManager.clearFocus(force = true)
                    sheetKeyboardController?.hide()
                    showAddNoteSheet = false
                }
            )
        }
    }

    // Note Bubble Detail Sheet
    selectedNoteForDetail?.let { note ->
        val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
        ModalBottomSheet(
            onDismissRequest = { selectedNoteForDetail = null },
            sheetState = sheetState
        ) {
            NoteDetailSheetContent(
                note = note,
                strings = strings,
                isOwner = note.authorId == uiState.currentUser?.id,
                onCloseBubble = {
                    onDismissBubble(note.id)
                    selectedNoteForDetail = null
                },
                onDelete = {
                    onDeleteNote(note.id)
                    selectedNoteForDetail = null
                },
                onBlockAuthor = {
                    onBlockUser(note.authorId)
                    selectedNoteForDetail = null
                }
            )
        }
    }

    // Business Detail Sheet
    selectedBusiness?.let { biz ->
        ModalBottomSheet(onDismissRequest = { selectedBusiness = null }) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(businessIcon(biz.category), contentDescription = null, tint = MaterialTheme.colorScheme.secondary)
                    Spacer(modifier = Modifier.width(10.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(biz.name, style = MaterialTheme.typography.headlineMedium)
                        Text(
                            text = "${biz.category.label} • ${biz.distanceMeters}m away",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                Text(biz.address, style = MaterialTheme.typography.bodyMedium)
                biz.openingHours?.let {
                    Text("Hours: $it", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = {
                            startMeasureTo(LatLng(biz.latitude, biz.longitude), biz.name)
                            selectedBusiness = null
                        },
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                    ) {
                        Icon(Icons.Rounded.Straighten, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(strings.measureDistance, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    FilledTonalButton(
                        onClick = {
                            addRouteStop(biz.latitude, biz.longitude, biz.name)
                            selectedBusiness = null
                        },
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                    ) {
                        Icon(Icons.Rounded.AltRoute, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(strings.addStopToRoute, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
                Button(
                    onClick = {
                        pendingPinLocation = LatLng(biz.latitude, biz.longitude)
                        pendingPinLabel = biz.name
                        pendingPinSpotType = SpotType.BUSINESS
                        selectedBusiness = null
                        showAddNoteSheet = true
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                ) {
                    Icon(Icons.Rounded.AddLocationAlt, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(strings.addNoteOnMap, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }

    // Followed Traveler Detail Sheet
    selectedFollower?.let { traveler ->
        ModalBottomSheet(onDismissRequest = { selectedFollower = null }) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    TravelerAvatar(
                        displayName = traveler.displayName,
                        avatarUri = traveler.avatarUri,
                        size = 52.dp
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(traveler.displayName, style = MaterialTheme.typography.titleLarge)
                        Text("@${traveler.username}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                Text(traveler.aboutUs, style = MaterialTheme.typography.bodyMedium)
                val dist = NearbyPlacesRepository.distanceMeters(
                    uiState.liveLocation.latitude,
                    uiState.liveLocation.longitude,
                    traveler.latitude ?: uiState.liveLocation.latitude,
                    traveler.longitude ?: uiState.liveLocation.longitude
                )
                Text(
                    text = "${traveler.tsmLabel} • ${dist}m away",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary
                )
                OutlinedButton(
                    onClick = {
                        onBlockUser(traveler.id)
                        selectedFollower = null
                    },
                    modifier = Modifier.fillMaxWidth().height(48.dp)
                ) {
                    Icon(Icons.Rounded.Block, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(strings.blockUser)
                }
                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }

    // Save Multi-Stop Route Dialog
    if (showSaveRouteDialog) {
        val dialogFocusManager = LocalFocusManager.current
        val dialogKeyboardController = LocalSoftwareKeyboardController.current
        AlertDialog(
            onDismissRequest = {
                dialogFocusManager.clearFocus(force = true)
                dialogKeyboardController?.hide()
                showSaveRouteDialog = false
            },
            title = { Text(strings.saveRoute) },
            text = {
                DisposableEffect(Unit) {
                    onDispose {
                        dialogFocusManager.clearFocus(force = true)
                        dialogKeyboardController?.hide()
                    }
                }
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = pendingRouteTitleInput,
                        onValueChange = { pendingRouteTitleInput = it },
                        label = { Text(strings.routeTitleHint) },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("route_title_input")
                    )
                    Text(
                        text = "${routeStops.size} ${strings.stopsLabel} • ${routeSummary.totalMetricFormatted} (${routeSummary.totalMilesFormatted}) • ${strings.hitchEstLabel} ${GeoMeasurementHelper.formatDurationMinutes(routeSummary.totalRideMinutes)}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        dialogFocusManager.clearFocus(force = true)
                        dialogKeyboardController?.hide()
                        onSaveRoute(activeRouteId, pendingRouteTitleInput, routeStops) { saved ->
                            activeRouteId = saved.id
                            activeRouteTitle = saved.title
                        }
                        showSaveRouteDialog = false
                    },
                    enabled = routeStops.size >= 2,
                    modifier = Modifier.testTag("confirm_save_route_button")
                ) {
                    Text(strings.saveRoute)
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        dialogFocusManager.clearFocus(force = true)
                        dialogKeyboardController?.hide()
                        showSaveRouteDialog = false
                    }
                ) {
                    Text(strings.cancel)
                }
            }
        )
    }

    // Saved Travel Routes Sheet
    if (showSavedRoutesSheet) {
        val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
        ModalBottomSheet(
            onDismissRequest = { showSavedRoutesSheet = false },
            sheetState = sheetState
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 8.dp)
                    .testTag("saved_routes_sheet"),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Rounded.Bookmarks, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = strings.savedRoutesLabel,
                        style = MaterialTheme.typography.headlineMedium,
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(onClick = { showSavedRoutesSheet = false }) {
                        Icon(Icons.Rounded.Close, contentDescription = strings.cancel)
                    }
                }

                if (uiState.savedRoutes.isEmpty()) {
                    Text(
                        text = strings.noSavedRoutesYet,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(vertical = 16.dp)
                    )
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 360.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(uiState.savedRoutes, key = { it.id }) { savedRoute ->
                            val parsedStops = remember(savedRoute.stopsJson) {
                                GeoMeasurementHelper.decodeStops(savedRoute.stopsJson)
                            }
                            Surface(
                                shape = RoundedCornerShape(16.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(
                                    modifier = Modifier.padding(14.dp),
                                    verticalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = savedRoute.title,
                                                style = MaterialTheme.typography.titleMedium,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                            Text(
                                                text = "${parsedStops.size} ${strings.stopsLabel} • ${GeoMeasurementHelper.formatMetric(savedRoute.totalDistanceMeters)} (${GeoMeasurementHelper.formatMiles(savedRoute.totalDistanceMeters)})",
                                                style = MaterialTheme.typography.labelMedium,
                                                color = MaterialTheme.colorScheme.primary
                                            )
                                        }
                                        IconButton(onClick = { onDeleteRoute(savedRoute.id) }) {
                                            Icon(Icons.Rounded.Delete, contentDescription = strings.deleteLabel)
                                        }
                                    }
                                    if (parsedStops.isNotEmpty()) {
                                        Text(
                                            text = parsedStops.joinToString(" → ") { it.label },
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            maxLines = 2,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "${strings.hitchEstLabel}: ${GeoMeasurementHelper.formatDurationMinutes(savedRoute.estimatedRideMinutes)} • ${strings.walkingTimeLabel}: ${GeoMeasurementHelper.formatDurationMinutes(savedRoute.estimatedWalkMinutes)}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        FilledTonalButton(
                                            onClick = {
                                                activeRouteId = savedRoute.id
                                                activeRouteTitle = savedRoute.title
                                                routeStops = parsedStops
                                                isMeasureMode = false
                                                measuredTarget = null
                                                isRouteMode = true
                                                showSavedRoutesSheet = false
                                                parsedStops.firstOrNull()?.let { firstStop ->
                                                    if (hasValidGoogleMapsKey) {
                                                        scope.launch {
                                                            cameraPositionState.animate(
                                                                CameraUpdateFactory.newLatLngZoom(
                                                                    LatLng(firstStop.latitude, firstStop.longitude),
                                                                    13.5f
                                                                )
                                                            )
                                                        }
                                                    } else {
                                                        fallbackCenterLat = firstStop.latitude
                                                        fallbackCenterLng = firstStop.longitude
                                                        fallbackZoom = 13.5f
                                                    }
                                                }
                                            },
                                            modifier = Modifier.height(40.dp)
                                        ) {
                                            Text(strings.loadRouteOnMap)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }
}

@Composable
private fun MapNoteNotificationBubble(
    note: MapNoteEntity,
    closeContentDesc: String,
    onClick: () -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    val spotType = SpotType.fromCode(note.spotType)
    Surface(
        modifier = modifier
            .width(196.dp)
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.96f),
        tonalElevation = 6.dp,
        shadowElevation = 8.dp
    ) {
        Row(
            modifier = Modifier.padding(start = 10.dp, top = 6.dp, bottom = 6.dp, end = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (!note.photoUri.isNullOrBlank()) {
                val context = LocalContext.current
                val thumbRequest = remember(note.photoUri) {
                    ImageRequest.Builder(context)
                        .data(note.photoUri)
                        .size(128, 128)
                        .build()
                }
                AsyncImage(
                    model = thumbRequest,
                    contentDescription = note.title,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .size(34.dp)
                        .clip(RoundedCornerShape(8.dp))
                )
            } else {
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.secondaryContainer),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = spotIcon(spotType),
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSecondaryContainer,
                        modifier = Modifier.size(17.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.width(8.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = note.title,
                    style = MaterialTheme.typography.labelLarge,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = note.authorName,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            IconButton(
                onClick = onClose,
                modifier = Modifier
                    .size(32.dp)
                    .testTag("close_note_bubble_${note.id}")
            ) {
                Icon(
                    imageVector = Icons.Rounded.Close,
                    contentDescription = closeContentDesc,
                    modifier = Modifier.size(16.dp),
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun AddMapNoteSheetContent(
    strings: AppStrings,
    initialLabel: String,
    initialSpotType: SpotType,
    latitude: Double,
    longitude: Double,
    onSubmit: (String, String, SpotType, String, Uri?, String?) -> Unit,
    onCancel: () -> Unit
) {
    val context = LocalContext.current
    var title by remember { mutableStateOf("") }
    var noteBody by remember { mutableStateOf("") }
    var label by remember { mutableStateOf(initialLabel) }
    var spotType by remember { mutableStateOf(initialSpotType) }
    var pickedPhotoUri by remember { mutableStateOf<Uri?>(null) }
    var capturedPhotoFileUri by remember { mutableStateOf<String?>(null) }
    var pendingCameraContentUri by remember { mutableStateOf<Uri?>(null) }

    val galleryLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            pickedPhotoUri = uri
            capturedPhotoFileUri = null
        }
    }

    val cameraLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.TakePicture()
    ) { success ->
        if (success && pendingCameraContentUri != null) {
            pickedPhotoUri = pendingCameraContentUri
        } else {
            capturedPhotoFileUri = null
        }
    }

    val cameraPermLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            val (contentUri, fileUri) = PhotoStorageHelper.createCameraOutputUri(context)
            pendingCameraContentUri = contentUri
            capturedPhotoFileUri = fileUri
            cameraLauncher.launch(contentUri)
        }
    }

    val noteFocusManager = LocalFocusManager.current
    val noteKeyboardController = LocalSoftwareKeyboardController.current
    DisposableEffect(Unit) {
        onDispose {
            noteFocusManager.clearFocus(force = true)
            noteKeyboardController?.hide()
        }
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .imePadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 24.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(strings.addNoteOnMap, style = MaterialTheme.typography.headlineMedium)
        Text(
            text = String.format(Locale.US, "%.5f, %.5f", latitude, longitude),
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.primary
        )

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf(
                SpotType.ROADSIDE to strings.spotRoadside,
                SpotType.BUSINESS to strings.spotBusiness,
                SpotType.OPEN_SPACE to strings.spotOpenSpace,
                SpotType.SAFE_SPOT to strings.spotSafeSpot
            ).forEach { (type, text) ->
                FilterChip(
                    selected = spotType == type,
                    onClick = { spotType = type },
                    leadingIcon = { Icon(spotIcon(type), contentDescription = null, modifier = Modifier.size(16.dp)) },
                    label = { Text(text) }
                )
            }
        }

        OutlinedTextField(
            value = label,
            onValueChange = { label = it },
            label = { Text(strings.specifyLocation) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = title,
            onValueChange = { title = it },
            label = { Text(strings.noteTitleHint) },
            singleLine = true,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("note_title_input")
        )
        OutlinedTextField(
            value = noteBody,
            onValueChange = { noteBody = it },
            label = { Text(strings.noteBodyHint) },
            minLines = 3,
            maxLines = 5,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("note_body_input")
        )

        val previewModel = capturedPhotoFileUri ?: pickedPhotoUri
        if (previewModel != null) {
            AsyncImage(
                model = previewModel,
                contentDescription = "Selected spot photo",
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(170.dp)
                    .clip(RoundedCornerShape(16.dp))
            )
        }

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            FilledTonalButton(
                onClick = {
                    galleryLauncher.launch(
                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                    )
                },
                modifier = Modifier.weight(1f).height(48.dp)
            ) {
                Icon(Icons.Rounded.PhotoLibrary, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(strings.attachPhoto)
            }
            OutlinedButton(
                onClick = {
                    val hasCam = ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) ==
                        PackageManager.PERMISSION_GRANTED
                    if (hasCam) {
                        val (contentUri, fileUri) = PhotoStorageHelper.createCameraOutputUri(context)
                        pendingCameraContentUri = contentUri
                        capturedPhotoFileUri = fileUri
                        cameraLauncher.launch(contentUri)
                    } else {
                        cameraPermLauncher.launch(Manifest.permission.CAMERA)
                    }
                },
                modifier = Modifier.weight(1f).height(48.dp)
            ) {
                Icon(Icons.Rounded.CameraAlt, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(strings.takePhoto)
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            TextButton(
                onClick = onCancel,
                modifier = Modifier.weight(1f).height(48.dp)
            ) {
                Text(strings.cancel)
            }
            Button(
                onClick = {
                    if (title.isNotBlank() || noteBody.isNotBlank()) {
                        onSubmit(
                            title.ifBlank { label },
                            noteBody.ifBlank { title },
                            spotType,
                            label,
                            if (capturedPhotoFileUri == null) pickedPhotoUri else null,
                            capturedPhotoFileUri
                        )
                    }
                },
                enabled = title.isNotBlank() || noteBody.isNotBlank(),
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp)
                    .testTag("submit_map_note_button")
            ) {
                Text(strings.publish)
            }
        }
        Spacer(modifier = Modifier.height(16.dp))
    }
}

@Composable
private fun NoteDetailSheetContent(
    note: MapNoteEntity,
    strings: AppStrings,
    isOwner: Boolean,
    onCloseBubble: () -> Unit,
    onDelete: () -> Unit,
    onBlockAuthor: () -> Unit
) {
    val spotType = SpotType.fromCode(note.spotType)
    val dateStr = remember(note.createdAt) {
        SimpleDateFormat("MMM d, HH:mm", Locale.getDefault()).format(Date(note.createdAt))
    }
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 24.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = MaterialTheme.colorScheme.secondaryContainer
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        spotIcon(spotType),
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSecondaryContainer,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = when (spotType) {
                            SpotType.ROADSIDE -> strings.spotRoadside
                            SpotType.BUSINESS -> strings.spotBusiness
                            SpotType.OPEN_SPACE -> strings.spotOpenSpace
                            SpotType.SAFE_SPOT -> strings.spotSafeSpot
                        },
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSecondaryContainer
                    )
                }
            }
            Spacer(modifier = Modifier.weight(1f))
            Text(dateStr, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }

        Text(note.title, style = MaterialTheme.typography.headlineMedium)

        if (!note.photoUri.isNullOrBlank()) {
            AsyncImage(
                model = note.photoUri,
                contentDescription = note.title,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(210.dp)
                    .clip(RoundedCornerShape(18.dp))
            )
        }

        Text(note.noteText, style = MaterialTheme.typography.bodyLarge)

        Surface(
            shape = RoundedCornerShape(14.dp),
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
        ) {
            Column(modifier = Modifier.fillMaxWidth().padding(12.dp)) {
                Text("${strings.addedBy}: ${note.authorName}", style = MaterialTheme.typography.labelLarge)
                Text(
                    text = "${note.locationLabel} • ${String.format(Locale.US, "%.5f, %.5f", note.latitude, note.longitude)}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedButton(
                onClick = onCloseBubble,
                modifier = Modifier.weight(1f).height(48.dp)
            ) {
                Icon(Icons.Rounded.Close, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(strings.closeNoteBubble, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            if (isOwner) {
                Button(
                    onClick = onDelete,
                    modifier = Modifier.weight(1f).height(48.dp)
                ) {
                    Icon(Icons.Rounded.Delete, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(strings.deleteLabel)
                }
            } else {
                FilledTonalButton(
                    onClick = onBlockAuthor,
                    modifier = Modifier.weight(1f).height(48.dp)
                ) {
                    Icon(Icons.Rounded.Block, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(strings.blockUser, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
        }
        Spacer(modifier = Modifier.height(16.dp))
    }
}

private fun spotIcon(type: SpotType): ImageVector = when (type) {
    SpotType.ROADSIDE -> Icons.Rounded.DirectionsCar
    SpotType.BUSINESS -> Icons.Rounded.Storefront
    SpotType.OPEN_SPACE -> Icons.Rounded.Landscape
    SpotType.SAFE_SPOT -> Icons.Rounded.Shield
}

private fun businessIcon(category: BusinessCategory): ImageVector = when (category) {
    BusinessCategory.FUEL -> Icons.Rounded.LocalGasStation
    BusinessCategory.CAFE -> Icons.Rounded.LocalCafe
    BusinessCategory.RESTAURANT -> Icons.Rounded.Restaurant
    BusinessCategory.SHOP -> Icons.Rounded.Storefront
    BusinessCategory.TRANSIT -> Icons.Rounded.DirectionsCar
    BusinessCategory.REST_AREA -> Icons.Rounded.Shield
    BusinessCategory.HOSTEL -> Icons.Rounded.Landscape
}
