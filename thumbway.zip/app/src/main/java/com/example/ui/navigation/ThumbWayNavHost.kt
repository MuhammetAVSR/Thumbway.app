package com.example.ui.navigation

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.key
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.toRoute
import com.example.ui.i18n.stringsFor
import com.example.ui.screens.ChatScreen
import com.example.ui.screens.CommunityScreen
import com.example.ui.screens.LaunchScreen
import com.example.ui.screens.MainScreen
import com.example.ui.screens.MapScreen
import com.example.ui.viewmodel.ThumbWayUiState
import com.example.ui.viewmodel.ThumbWayViewModel
import kotlinx.serialization.Serializable

@Serializable
data object MainRoute

@Serializable
data class MapRoute(
    val focusLat: Double? = null,
    val focusLng: Double? = null
)

@Serializable
data class CommunityRoute(
    val initialTab: Int = 0
)

@Serializable
data class ChatRoute(
    val friendId: String? = null
)

@Composable
fun ThumbWayAppRoot(
    uiState: ThumbWayUiState,
    viewModel: ThumbWayViewModel
) {
    if (!uiState.isReady) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator()
        }
        return
    }

    val currentUser = uiState.currentUser
    val rootFocusManager = LocalFocusManager.current
    val rootKeyboardController = LocalSoftwareKeyboardController.current
    LaunchedEffect(currentUser?.id) {
        rootFocusManager.clearFocus(force = true)
        rootKeyboardController?.hide()
    }

    if (currentUser == null) {
        LaunchScreen(
            strings = stringsFor(uiState.language),
            existingProfiles = uiState.allUsers.filter { !it.id.startsWith("seed_") },
            authError = uiState.authError,
            onClearError = viewModel::clearAuthError,
            onCreateProfile = viewModel::createProfile,
            onLogin = viewModel::login,
            onQuickLogin = viewModel::quickLogin
        )
    } else {
        key(currentUser.id) {
            val navController = rememberNavController()
            NavHost(
                navController = navController,
                startDestination = MainRoute
            ) {
                composable<MainRoute> {
                    MainScreen(
                        uiState = uiState,
                        onOpenMap = { lat, lng ->
                            navController.navigate(MapRoute(focusLat = lat, focusLng = lng))
                        },
                        onOpenCommunity = { tab ->
                            navController.navigate(CommunityRoute(initialTab = tab))
                        },
                        onOpenChat = {
                            navController.navigate(ChatRoute())
                        },
                        onToggleLocationSharing = viewModel::toggleLocationSharing,
                        onSyncTsm = viewModel::syncTsmLocation,
                        onLocationPermissionGranted = viewModel::onLocationPermissionGranted,
                        onUpdateProfile = viewModel::updateProfile,
                        onSelectLanguage = viewModel::setLanguage,
                        onSelectThemeMode = viewModel::setThemeMode,
                        onUpdatePassword = viewModel::updatePassword,
                        onUnblockUser = viewModel::unblockUser,
                        onLogout = viewModel::logout,
                        onClearBanner = viewModel::clearStatusBanner
                    )
                }

                composable<MapRoute> { backStackEntry ->
                    val route = backStackEntry.toRoute<MapRoute>()
                    MapScreen(
                        uiState = uiState,
                        focusLat = route.focusLat,
                        focusLng = route.focusLng,
                        onBack = { navController.popBackStack() },
                        onLocationPermissionGranted = viewModel::onLocationPermissionGranted,
                        onRefreshBusinesses = viewModel::refreshNearbyBusinesses,
                        onSyncTsm = viewModel::syncTsmLocation,
                        onPinTsmAt = viewModel::pinTsmLocationAt,
                        onAddNote = viewModel::addMapNote,
                        onDismissBubble = viewModel::dismissNoteBubble,
                        onRestoreBubbles = viewModel::restoreDismissedNotes,
                        onDeleteNote = viewModel::deleteMapNote,
                        onBlockUser = viewModel::blockUser,
                        onSearchPlaces = viewModel::searchPlaces,
                        onClearPlaceSearch = viewModel::clearPlaceSearch,
                        onSaveRoute = viewModel::saveTravelRoute,
                        onDeleteRoute = viewModel::deleteTravelRoute,
                        onAddEmergencyContact = viewModel::addEmergencyContact,
                        onRemoveEmergencyContact = viewModel::removeEmergencyContact,
                        onToggleFriendEmergencyContact = viewModel::toggleFriendEmergencyContact,
                        onSendSosSignal = viewModel::sendInAppSosSignal,
                        onRefreshWeather = viewModel::refreshMapWeather
                    )
                }

                composable<CommunityRoute> { backStackEntry ->
                    val route = backStackEntry.toRoute<CommunityRoute>()
                    CommunityScreen(
                        uiState = uiState,
                        initialTab = route.initialTab,
                        onBack = { navController.popBackStack() },
                        onOpenLocationOnMap = { lat, lng ->
                            navController.navigate(MapRoute(focusLat = lat, focusLng = lng))
                        },
                        onToggleSavePost = viewModel::toggleSavePost,
                        onCreatePost = viewModel::createPost,
                        onDeletePost = viewModel::deletePost,
                        onToggleFollow = viewModel::toggleFollow,
                        onBlockUser = viewModel::blockUser
                    )
                }

                composable<ChatRoute> { backStackEntry ->
                    val route = backStackEntry.toRoute<ChatRoute>()
                    ChatScreen(
                        uiState = uiState,
                        initialFriendId = route.friendId,
                        onBack = { navController.popBackStack() },
                        onOpenCommunityTravelers = {
                            navController.navigate(CommunityRoute(initialTab = 2))
                        },
                        onSendText = viewModel::sendTextChatMessage,
                        onSendMediaUri = viewModel::sendMediaChatMessage,
                        onSendPersistedPhoto = viewModel::sendPersistedPhotoChatMessage,
                        onSendPersistedVideo = viewModel::sendPersistedVideoChatMessage,
                        onSendAudio = viewModel::sendAudioChatMessage,
                        onDeleteMessage = viewModel::deleteChatMessage
                    )
                }
            }
        }
    }
}
