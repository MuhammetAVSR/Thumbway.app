package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Warm Trail & Asphalt Palette (Light)
val ForestPrimary = Color(0xFF1A4D3E)
val ForestOnPrimary = Color(0xFFFFFFFF)
val ForestPrimaryContainer = Color(0xFFBBEAD6)
val ForestOnPrimaryContainer = Color(0xFF042118)

val AmberSecondary = Color(0xFFC96A2B)
val AmberOnSecondary = Color(0xFFFFFFFF)
val AmberSecondaryContainer = Color(0xFFFFDCC7)
val AmberOnSecondaryContainer = Color(0xFF391700)

val SkyTertiary = Color(0xFF2D6E8E)
val SkyOnTertiary = Color(0xFFFFFFFF)
val SkyTertiaryContainer = Color(0xFFCBE6F7)
val SkyOnTertiaryContainer = Color(0xFF062535)

val ParchmentBackground = Color(0xFFFAF8F4)
val CharcoalOnBackground = Color(0xFF1A1D1B)
val ParchmentSurface = Color(0xFFFAF8F4)
val ParchmentSurfaceVariant = Color(0xFFE7E2D8)
val SlateOnSurfaceVariant = Color(0xFF454944)
val TrailOutline = Color(0xFF767A73)
val TrailOutlineVariant = Color(0xFFC6C7BE)

// Warm Trail & Asphalt Palette (Dark)
val MintPrimaryDark = Color(0xFF7FD6B6)
val ForestOnPrimaryDark = Color(0xFF003829)
val ForestPrimaryContainerDark = Color(0xFF00513D)
val MintOnPrimaryContainerDark = Color(0xFFBBEAD6)

val PeachSecondaryDark = Color(0xFFF2A365)
val BrownOnSecondaryDark = Color(0xFF4F2400)
val TerracottaContainerDark = Color(0xFF72370B)
val PeachOnContainerDark = Color(0xFFFFDCC7)

val IceTertiaryDark = Color(0xFF8AC7E6)
val DeepBlueOnTertiaryDark = Color(0xFF00354A)
val DeepBlueContainerDark = Color(0xFF0D4D69)
val IceOnContainerDark = Color(0xFFCBE6F7)

val NightSlateBackground = Color(0xFF111614)
val CreamOnBackgroundDark = Color(0xFFE4E3DD)
val NightSlateSurface = Color(0xFF111614)
val NightSlateSurfaceVariant = Color(0xFF28302C)
val WarmGrayOnSurfaceVariantDark = Color(0xFFC2C8C2)
val NightOutline = Color(0xFF8C938C)
val NightOutlineVariant = Color(0xFF414944)

// Semantic Accents
val RoadSuccess = Color(0xFF2E7D32)
val RoadWarning = Color(0xFFD97706)
val RoadDanger = Color(0xFFB3261E)

// Traveler Rank Scale Accents
val RankStarterAccent = Color(0xFF607D8B)
val RankNoviceAccent = Color(0xFF2A7B5D)
val RankSeasonedAccent = Color(0xFF1D6FA5)
val RankEnthusiastAccent = Color(0xFFD97706)
val RankMasterAccent = Color(0xFF6B46C1)
val RankAdventurerAccent = Color(0xFFC84B31)
val RankEvliyaGold = Color(0xFFB7791F)

