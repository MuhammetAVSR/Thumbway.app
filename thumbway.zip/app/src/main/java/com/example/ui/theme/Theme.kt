package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

enum class ThemeMode {
    SYSTEM,
    LIGHT,
    DARK
}

private val DarkColorScheme = darkColorScheme(
    primary = MintPrimaryDark,
    onPrimary = ForestOnPrimaryDark,
    primaryContainer = ForestPrimaryContainerDark,
    onPrimaryContainer = MintOnPrimaryContainerDark,
    secondary = PeachSecondaryDark,
    onSecondary = BrownOnSecondaryDark,
    secondaryContainer = TerracottaContainerDark,
    onSecondaryContainer = PeachOnContainerDark,
    tertiary = IceTertiaryDark,
    onTertiary = DeepBlueOnTertiaryDark,
    tertiaryContainer = DeepBlueContainerDark,
    onTertiaryContainer = IceOnContainerDark,
    background = NightSlateBackground,
    onBackground = CreamOnBackgroundDark,
    surface = NightSlateSurface,
    onSurface = CreamOnBackgroundDark,
    surfaceVariant = NightSlateSurfaceVariant,
    onSurfaceVariant = WarmGrayOnSurfaceVariantDark,
    outline = NightOutline,
    outlineVariant = NightOutlineVariant,
    error = RoadDanger
)

private val LightColorScheme = lightColorScheme(
    primary = ForestPrimary,
    onPrimary = ForestOnPrimary,
    primaryContainer = ForestPrimaryContainer,
    onPrimaryContainer = ForestOnPrimaryContainer,
    secondary = AmberSecondary,
    onSecondary = AmberOnSecondary,
    secondaryContainer = AmberSecondaryContainer,
    onSecondaryContainer = AmberOnSecondaryContainer,
    tertiary = SkyTertiary,
    onTertiary = SkyOnTertiary,
    tertiaryContainer = SkyTertiaryContainer,
    onTertiaryContainer = SkyOnTertiaryContainer,
    background = ParchmentBackground,
    onBackground = CharcoalOnBackground,
    surface = ParchmentSurface,
    onSurface = CharcoalOnBackground,
    surfaceVariant = ParchmentSurfaceVariant,
    onSurfaceVariant = SlateOnSurfaceVariant,
    outline = TrailOutline,
    outlineVariant = TrailOutlineVariant,
    error = RoadDanger
)

val ThumbWayShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(18.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(30.dp)
)

@Composable
fun ThumbWayTheme(
    themeMode: ThemeMode = ThemeMode.SYSTEM,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit,
) {
    val useDarkTheme = when (themeMode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }

    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (useDarkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        useDarkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        shapes = ThumbWayShapes,
        content = content
    )
}
