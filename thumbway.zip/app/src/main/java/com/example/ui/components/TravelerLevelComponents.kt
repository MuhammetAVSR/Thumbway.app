package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.DirectionsWalk
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Explore
import androidx.compose.material.icons.rounded.LocalFireDepartment
import androidx.compose.material.icons.rounded.MilitaryTech
import androidx.compose.material.icons.rounded.Route
import androidx.compose.material.icons.rounded.Terrain
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.example.data.local.TravelerLevelSystem
import com.example.data.local.TravelerRank
import com.example.ui.i18n.AppStrings
import com.example.ui.i18n.titleFor
import com.example.ui.theme.RankAdventurerAccent
import com.example.ui.theme.RankEnthusiastAccent
import com.example.ui.theme.RankEvliyaGold
import com.example.ui.theme.RankMasterAccent
import com.example.ui.theme.RankNoviceAccent
import com.example.ui.theme.RankSeasonedAccent
import com.example.ui.theme.RankStarterAccent

internal data class RankVisualStyle(
    val accent: Color,
    val icon: ImageVector
)

internal fun styleForRank(rank: TravelerRank): RankVisualStyle = when (rank) {
    TravelerRank.STARTER -> RankVisualStyle(RankStarterAccent, Icons.AutoMirrored.Rounded.DirectionsWalk)
    TravelerRank.NOVICE_TRAVELER -> RankVisualStyle(RankNoviceAccent, Icons.Rounded.Explore)
    TravelerRank.SEASONED_TRAVELER -> RankVisualStyle(RankSeasonedAccent, Icons.Rounded.Route)
    TravelerRank.ROAD_ENTHUSIAST -> RankVisualStyle(RankEnthusiastAccent, Icons.Rounded.LocalFireDepartment)
    TravelerRank.MASTER_OF_ROAD -> RankVisualStyle(RankMasterAccent, Icons.Rounded.MilitaryTech)
    TravelerRank.ADVENTURER -> RankVisualStyle(RankAdventurerAccent, Icons.Rounded.Terrain)
    TravelerRank.EVLIYA_CELEBI -> RankVisualStyle(RankEvliyaGold, Icons.Rounded.AutoAwesome)
}

@Composable
fun TravelerLevelBadge(
    postCount: Int,
    strings: AppStrings,
    modifier: Modifier = Modifier,
    compact: Boolean = false,
    onClick: (() -> Unit)? = null
) {
    val progress = remember(postCount) { TravelerLevelSystem.evaluate(postCount) }
    val style = styleForRank(progress.rank)
    val title = strings.titleFor(progress.rank)

    val clickMod = if (onClick != null) {
        Modifier.clickable(onClick = onClick)
    } else {
        Modifier
    }

    Surface(
        shape = RoundedCornerShape(999.dp),
        color = style.accent.copy(alpha = 0.14f),
        border = androidx.compose.foundation.BorderStroke(1.dp, style.accent.copy(alpha = 0.35f)),
        modifier = modifier
            .clip(RoundedCornerShape(999.dp))
            .then(clickMod)
    ) {
        Row(
            modifier = Modifier.padding(
                horizontal = if (compact) 8.dp else 10.dp,
                vertical = if (compact) 4.dp else 5.dp
            ),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            Icon(
                imageVector = style.icon,
                contentDescription = title,
                tint = style.accent,
                modifier = Modifier.size(if (compact) 13.dp else 15.dp)
            )
            Text(
                text = "${strings.levelShortLabel}${progress.rank.level} • $title",
                style = if (compact) MaterialTheme.typography.labelSmall else MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.SemiBold,
                color = style.accent,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun TravelerScaleProfileCard(
    postCount: Int,
    strings: AppStrings,
    modifier: Modifier = Modifier,
    compact: Boolean = false,
    onOpenScaleDialog: () -> Unit
) {
    val progress = remember(postCount) { TravelerLevelSystem.evaluate(postCount) }
    val currentStyle = styleForRank(progress.rank)
    val rankTitle = strings.titleFor(progress.rank)

    Card(
        shape = RoundedCornerShape(if (compact) 16.dp else 22.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = if (compact) 0.35f else 0.48f)
        ),
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(if (compact) 16.dp else 22.dp))
            .clickable(onClick = onOpenScaleDialog)
            .testTag("traveler_scale_card")
    ) {
        Column(
            modifier = Modifier.padding(if (compact) 12.dp else 16.dp),
            verticalArrangement = Arrangement.spacedBy(if (compact) 8.dp else 12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = CircleShape,
                    color = currentStyle.accent.copy(alpha = 0.18f),
                    modifier = Modifier.size(if (compact) 34.dp else 42.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = currentStyle.icon,
                            contentDescription = rankTitle,
                            tint = currentStyle.accent,
                            modifier = Modifier.size(if (compact) 18.dp else 22.dp)
                        )
                    }
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = rankTitle,
                            style = if (compact) MaterialTheme.typography.titleSmall else MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = currentStyle.accent
                        ) {
                            Text(
                                text = "${strings.levelShortLabel}${progress.rank.level}",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color.White,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                    Text(
                        text = "${progress.postCount} ${strings.postsCountLabel} • ${strings.travelerScaleTitle}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                Icon(
                    imageVector = Icons.Rounded.ChevronRight,
                    contentDescription = strings.travelerScaleTitle,
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(20.dp)
                )
            }

            // Segmented Milestone Scale Bar: 10 -> 20 -> 30 -> 40 -> 50 -> 60
            TravelerScaleTrack(
                postCount = progress.postCount,
                accent = currentStyle.accent,
                compact = compact
            )

            // Progress hint to next milestone
            val next = progress.nextRank
            val footerText = if (next == null) {
                strings.maxRankReachedLabel
            } else {
                val nextTitle = strings.titleFor(next)
                "${strings.nextRankLabel}: $nextTitle (${next.minPosts} ${strings.postsCountLabel} • ${progress.postsRemainingForNext} ${strings.postsLeftLabel})"
            }
            Text(
                text = footerText,
                style = MaterialTheme.typography.labelSmall,
                color = if (next == null) currentStyle.accent else MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun TravelerScaleTrack(
    postCount: Int,
    accent: Color,
    compact: Boolean
) {
    val milestones = TravelerLevelSystem.scaleMilestones
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(if (compact) 7.dp else 9.dp)
                .clip(RoundedCornerShape(999.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant)
        ) {
            val fraction = (postCount.toFloat() / TravelerLevelSystem.MAX_SCALE_POSTS.toFloat()).coerceIn(0f, 1f)
            Box(
                modifier = Modifier
                    .fillMaxWidth(fraction)
                    .fillMaxHeight()
                    .clip(RoundedCornerShape(999.dp))
                    .background(accent)
            )
        }
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "0",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            milestones.forEach { tier ->
                val unlocked = postCount >= tier.minPosts
                val tierColor = if (unlocked) styleForRank(tier).accent else MaterialTheme.colorScheme.outlineVariant
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(
                        modifier = Modifier
                            .size(if (compact) 6.dp else 8.dp)
                            .clip(CircleShape)
                            .background(if (unlocked) tierColor else MaterialTheme.colorScheme.surfaceVariant)
                            .border(1.dp, tierColor, CircleShape)
                    )
                    Text(
                        text = "${tier.minPosts}",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = if (unlocked) FontWeight.Bold else FontWeight.Normal,
                        color = if (unlocked) tierColor else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
fun TravelerScaleDialog(
    postCount: Int,
    strings: AppStrings,
    onDismiss: () -> Unit
) {
    val progress = remember(postCount) { TravelerLevelSystem.evaluate(postCount) }
    val currentStyle = styleForRank(progress.rank)
    val tiers = remember { TravelerRank.entries.sortedBy { it.minPosts } }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(28.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("traveler_scale_dialog")
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = strings.travelerScaleTitle,
                            style = MaterialTheme.typography.titleLarge
                        )
                        Text(
                            text = "${progress.postCount} ${strings.postsCountLabel} • ${strings.titleFor(progress.rank)}",
                            style = MaterialTheme.typography.bodySmall,
                            color = currentStyle.accent,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .size(48.dp)
                            .testTag("close_traveler_scale_dialog")
                    ) {
                        Icon(Icons.Rounded.Close, contentDescription = strings.cancel)
                    }
                }

                LinearProgressIndicator(
                    progress = { progress.progressToNext },
                    color = currentStyle.accent,
                    trackColor = MaterialTheme.colorScheme.surfaceVariant,
                    strokeCap = StrokeCap.Round,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .clip(RoundedCornerShape(999.dp))
                )

                val next = progress.nextRank
                Text(
                    text = if (next == null) {
                        strings.maxRankReachedLabel
                    } else {
                        "${strings.nextRankLabel}: ${strings.titleFor(next)} (${progress.postsRemainingForNext} ${strings.postsLeftLabel})"
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                HorizontalDivider()

                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    tiers.forEach { tier ->
                        val style = styleForRank(tier)
                        val unlocked = progress.postCount >= tier.minPosts
                        val isCurrent = progress.rank == tier

                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = when {
                                isCurrent -> style.accent.copy(alpha = 0.16f)
                                unlocked -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
                                else -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.2f)
                            },
                            border = if (isCurrent) {
                                androidx.compose.foundation.BorderStroke(1.5.dp, style.accent)
                            } else {
                                null
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Surface(
                                    shape = CircleShape,
                                    color = if (unlocked) style.accent.copy(alpha = 0.2f) else MaterialTheme.colorScheme.surfaceVariant,
                                    modifier = Modifier.size(36.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(
                                            imageVector = style.icon,
                                            contentDescription = strings.titleFor(tier),
                                            tint = if (unlocked) style.accent else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "${strings.levelShortLabel}${tier.level} • ${strings.titleFor(tier)}",
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Medium,
                                        color = if (unlocked) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Text(
                                        text = "${tier.minPosts}+ ${strings.postsCountLabel}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = if (unlocked) style.accent else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                if (unlocked) {
                                    Icon(
                                        imageVector = Icons.Rounded.CheckCircle,
                                        contentDescription = strings.granted,
                                        tint = style.accent,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
