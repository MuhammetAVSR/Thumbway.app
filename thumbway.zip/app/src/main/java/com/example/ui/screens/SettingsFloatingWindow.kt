package com.example.ui.screens

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Logout
import androidx.compose.material.icons.rounded.Block
import androidx.compose.material.icons.rounded.CameraAlt
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.DarkMode
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Language
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.MyLocation
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.Security
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.example.data.local.UserEntity
import com.example.ui.components.TravelerAvatar
import com.example.ui.components.TravelerLevelBadge
import com.example.ui.components.TravelerScaleDialog
import com.example.ui.components.TravelerScaleProfileCard
import com.example.ui.i18n.AppLanguage
import com.example.ui.i18n.AppStrings
import com.example.ui.theme.RoadSuccess
import com.example.ui.theme.RoadWarning
import com.example.ui.theme.ThemeMode

private enum class SettingsSection {
    PROFILE,
    LANGUAGE_THEME,
    PASSWORD,
    BLOCKED,
    PERMISSIONS
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SettingsFloatingWindow(
    visible: Boolean,
    strings: AppStrings,
    currentUser: UserEntity,
    currentUserPostCount: Int = 0,
    currentLanguage: AppLanguage,
    currentThemeMode: ThemeMode,
    blockedUsers: List<UserEntity>,
    onDismiss: () -> Unit,
    onUpdateProfile: (displayName: String, aboutUs: String, avatarUri: Uri?) -> Unit,
    onSelectLanguage: (AppLanguage) -> Unit,
    onSelectThemeMode: (ThemeMode) -> Unit,
    onUpdatePassword: (current: String, next: String, onDone: (Boolean, String) -> Unit) -> Unit,
    onUnblockUser: (userId: String) -> Unit,
    onLocationPermissionGranted: () -> Unit,
    onLogout: () -> Unit
) {
    val context = LocalContext.current
    val focusManager = LocalFocusManager.current
    val keyboardController = LocalSoftwareKeyboardController.current
    var activeSection by remember { mutableStateOf(SettingsSection.PROFILE) }
    var showScaleDialog by remember { mutableStateOf(false) }

    LaunchedEffect(visible) {
        if (!visible) {
            focusManager.clearFocus(force = true)
            keyboardController?.hide()
        }
    }

    var editName by remember(currentUser.id, currentUser.displayName) { mutableStateOf(currentUser.displayName) }
    var editAboutUs by remember(currentUser.id, currentUser.aboutUs) { mutableStateOf(currentUser.aboutUs) }
    var pendingAvatarUri by remember(currentUser.id) { mutableStateOf<Uri?>(null) }

    var currentPassword by remember { mutableStateOf("") }
    var newPassword by remember { mutableStateOf("") }
    var passwordFeedback by remember { mutableStateOf<Pair<Boolean, String>?>(null) }

    var hasLocation by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
                ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        )
    }
    var hasCamera by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        )
    }
    var hasMic by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        )
    }
    var hasNotifications by remember {
        mutableStateOf(
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
            } else {
                true
            }
        )
    }

    val locationLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { perms ->
        val granted = perms[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
            perms[Manifest.permission.ACCESS_COARSE_LOCATION] == true
        hasLocation = granted
        if (granted) onLocationPermissionGranted()
    }

    val cameraLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted -> hasCamera = granted }

    val micLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted -> hasMic = granted }

    val notificationLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted -> hasNotifications = granted }

    val avatarPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.PickVisualMedia()
    ) { uri -> if (uri != null) pendingAvatarUri = uri }

    Box(modifier = Modifier.fillMaxSize()) {
        AnimatedVisibility(
            visible = visible,
            enter = fadeIn(),
            exit = fadeOut()
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.45f))
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null,
                        onClick = onDismiss
                    )
            )
        }

        AnimatedVisibility(
            visible = visible,
            enter = slideInHorizontally(initialOffsetX = { -it }) + fadeIn(),
            exit = slideOutHorizontally(targetOffsetX = { -it }) + fadeOut(),
            modifier = Modifier.align(Alignment.CenterStart)
        ) {
            Surface(
                modifier = Modifier
                    .statusBarsPadding()
                    .navigationBarsPadding()
                    .padding(start = 12.dp, top = 12.dp, bottom = 12.dp, end = 24.dp)
                    .widthIn(min = 290.dp, max = 365.dp)
                    .fillMaxHeight()
                    .testTag("settings_floating_window"),
                shape = RoundedCornerShape(28.dp),
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 8.dp,
                shadowElevation = 16.dp
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(18.dp)
                ) {
                    // Header
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        TravelerAvatar(
                            displayName = currentUser.displayName,
                            avatarUri = pendingAvatarUri?.toString() ?: currentUser.avatarUri,
                            size = 44.dp
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = strings.settings,
                                style = MaterialTheme.typography.titleLarge
                            )
                            Text(
                                text = "@${currentUser.username}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            TravelerLevelBadge(
                                postCount = currentUserPostCount,
                                strings = strings,
                                compact = true,
                                onClick = { showScaleDialog = true }
                            )
                        }
                        IconButton(
                            onClick = {
                                focusManager.clearFocus(force = true)
                                keyboardController?.hide()
                                onDismiss()
                            },
                            modifier = Modifier.testTag("close_settings_button")
                        ) {
                            Icon(Icons.Rounded.Close, contentDescription = strings.cancel)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Section Selector Pills
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        SectionPill(
                            label = strings.editProfile,
                            icon = Icons.Rounded.Edit,
                            selected = activeSection == SettingsSection.PROFILE,
                            onClick = { activeSection = SettingsSection.PROFILE }
                        )
                        SectionPill(
                            label = "${strings.languageSettings} & ${strings.themeSettings}",
                            icon = Icons.Rounded.Language,
                            selected = activeSection == SettingsSection.LANGUAGE_THEME,
                            onClick = { activeSection = SettingsSection.LANGUAGE_THEME }
                        )
                        SectionPill(
                            label = strings.passwordSettings,
                            icon = Icons.Rounded.Lock,
                            selected = activeSection == SettingsSection.PASSWORD,
                            onClick = { activeSection = SettingsSection.PASSWORD }
                        )
                        SectionPill(
                            label = "${strings.blockedUsers} (${blockedUsers.size})",
                            icon = Icons.Rounded.Block,
                            selected = activeSection == SettingsSection.BLOCKED,
                            onClick = { activeSection = SettingsSection.BLOCKED }
                        )
                        SectionPill(
                            label = strings.devicePermissions,
                            icon = Icons.Rounded.Security,
                            selected = activeSection == SettingsSection.PERMISSIONS,
                            onClick = { activeSection = SettingsSection.PERMISSIONS }
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                    HorizontalDivider()
                    Spacer(modifier = Modifier.height(14.dp))

                    // Section Content
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        when (activeSection) {
                            SettingsSection.PROFILE -> {
                                TravelerScaleProfileCard(
                                    postCount = currentUserPostCount,
                                    strings = strings,
                                    compact = true,
                                    onOpenScaleDialog = { showScaleDialog = true }
                                )

                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    TravelerAvatar(
                                        displayName = editName.ifBlank { currentUser.displayName },
                                        avatarUri = pendingAvatarUri?.toString() ?: currentUser.avatarUri,
                                        size = 64.dp
                                    )
                                    OutlinedButton(
                                        onClick = {
                                            avatarPicker.launch(
                                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                            )
                                        },
                                        modifier = Modifier.testTag("edit_profile_photo_button")
                                    ) {
                                        Text(strings.chooseAvatar)
                                    }
                                }

                                OutlinedTextField(
                                    value = editName,
                                    onValueChange = { editName = it },
                                    label = { Text(strings.displayName) },
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth()
                                )

                                OutlinedTextField(
                                    value = editAboutUs,
                                    onValueChange = { editAboutUs = it },
                                    label = { Text(strings.aboutUs) },
                                    placeholder = { Text(strings.aboutUsHint) },
                                    minLines = 3,
                                    maxLines = 5,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("edit_about_us_input")
                                )

                                Button(
                                    onClick = {
                                        onUpdateProfile(editName, editAboutUs, pendingAvatarUri)
                                        pendingAvatarUri = null
                                    },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(48.dp)
                                        .testTag("save_profile_button"),
                                    shape = RoundedCornerShape(14.dp)
                                ) {
                                    Text(strings.saveChanges)
                                }

                                Surface(
                                    shape = RoundedCornerShape(16.dp),
                                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f)
                                ) {
                                    Column(modifier = Modifier.padding(14.dp)) {
                                        Text(
                                            text = "${strings.appName} • ${strings.aboutUs}",
                                            style = MaterialTheme.typography.titleMedium
                                        )
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = strings.tagline,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                            }

                            SettingsSection.LANGUAGE_THEME -> {
                                Text(
                                    text = strings.languageSettings,
                                    style = MaterialTheme.typography.titleMedium
                                )
                                FlowRow(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    AppLanguage.entries.forEach { lang ->
                                        FilterChip(
                                            selected = currentLanguage == lang,
                                            onClick = { onSelectLanguage(lang) },
                                            label = { Text(lang.displayName) },
                                            modifier = Modifier.testTag("lang_chip_${lang.code}")
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = strings.themeSettings,
                                    style = MaterialTheme.typography.titleMedium
                                )
                                FlowRow(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    listOf(
                                        ThemeMode.SYSTEM to strings.themeSystem,
                                        ThemeMode.LIGHT to strings.themeLight,
                                        ThemeMode.DARK to strings.themeDark
                                    ).forEach { (mode, label) ->
                                        FilterChip(
                                            selected = currentThemeMode == mode,
                                            onClick = { onSelectThemeMode(mode) },
                                            leadingIcon = {
                                                Icon(
                                                    imageVector = Icons.Rounded.DarkMode,
                                                    contentDescription = null,
                                                    modifier = Modifier.size(16.dp)
                                                )
                                            },
                                            label = { Text(label) },
                                            modifier = Modifier.testTag("theme_chip_${mode.name.lowercase()}")
                                        )
                                    }
                                }
                            }

                            SettingsSection.PASSWORD -> {
                                Text(
                                    text = strings.passwordSettings,
                                    style = MaterialTheme.typography.titleMedium
                                )
                                OutlinedTextField(
                                    value = currentPassword,
                                    onValueChange = { currentPassword = it },
                                    label = { Text(strings.currentPassword) },
                                    singleLine = true,
                                    visualTransformation = PasswordVisualTransformation(),
                                    modifier = Modifier.fillMaxWidth()
                                )
                                OutlinedTextField(
                                    value = newPassword,
                                    onValueChange = { newPassword = it },
                                    label = { Text(strings.newPassword) },
                                    singleLine = true,
                                    visualTransformation = PasswordVisualTransformation(),
                                    modifier = Modifier.fillMaxWidth()
                                )
                                passwordFeedback?.let { (ok, msg) ->
                                    Text(
                                        text = msg,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = if (ok) RoadSuccess else MaterialTheme.colorScheme.error
                                    )
                                }
                                Button(
                                    onClick = {
                                        onUpdatePassword(currentPassword, newPassword) { ok, msg ->
                                            passwordFeedback = ok to msg
                                            if (ok) {
                                                currentPassword = ""
                                                newPassword = ""
                                            }
                                        }
                                    },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(48.dp)
                                        .testTag("update_password_button"),
                                    shape = RoundedCornerShape(14.dp)
                                ) {
                                    Text(strings.updatePassword)
                                }
                            }

                            SettingsSection.BLOCKED -> {
                                Text(
                                    text = strings.blockedUsers,
                                    style = MaterialTheme.typography.titleMedium
                                )
                                if (blockedUsers.isEmpty()) {
                                    Text(
                                        text = strings.noBlockedUsers,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                } else {
                                    blockedUsers.forEach { blocked ->
                                        Surface(
                                            shape = RoundedCornerShape(14.dp),
                                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Row(
                                                modifier = Modifier.padding(12.dp),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                TravelerAvatar(
                                                    displayName = blocked.displayName,
                                                    avatarUri = blocked.avatarUri,
                                                    size = 38.dp
                                                )
                                                Spacer(modifier = Modifier.width(10.dp))
                                                Column(modifier = Modifier.weight(1f)) {
                                                    Text(blocked.displayName, style = MaterialTheme.typography.titleMedium)
                                                    Text("@${blocked.username}", style = MaterialTheme.typography.bodySmall)
                                                }
                                                TextButton(onClick = { onUnblockUser(blocked.id) }) {
                                                    Text(strings.unblock)
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                            SettingsSection.PERMISSIONS -> {
                                Text(
                                    text = strings.devicePermissions,
                                    style = MaterialTheme.typography.titleMedium
                                )
                                PermissionItemCard(
                                    icon = Icons.Rounded.MyLocation,
                                    title = strings.locationPermission,
                                    granted = hasLocation,
                                    grantedLabel = strings.granted,
                                    grantButtonLabel = strings.grantPermission,
                                    onGrant = {
                                        locationLauncher.launch(
                                            arrayOf(
                                                Manifest.permission.ACCESS_FINE_LOCATION,
                                                Manifest.permission.ACCESS_COARSE_LOCATION
                                            )
                                        )
                                    }
                                )
                                PermissionItemCard(
                                    icon = Icons.Rounded.CameraAlt,
                                    title = strings.cameraPermission,
                                    granted = hasCamera,
                                    grantedLabel = strings.granted,
                                    grantButtonLabel = strings.grantPermission,
                                    onGrant = { cameraLauncher.launch(Manifest.permission.CAMERA) }
                                )
                                PermissionItemCard(
                                    icon = Icons.Rounded.Mic,
                                    title = strings.microphonePermission,
                                    granted = hasMic,
                                    grantedLabel = strings.granted,
                                    grantButtonLabel = strings.grantPermission,
                                    onGrant = { micLauncher.launch(Manifest.permission.RECORD_AUDIO) }
                                )
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                    PermissionItemCard(
                                        icon = Icons.Rounded.Notifications,
                                        title = strings.notificationsPermission,
                                        granted = hasNotifications,
                                        grantedLabel = strings.granted,
                                        grantButtonLabel = strings.grantPermission,
                                        onGrant = {
                                            notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                                        }
                                    )
                                }
                                OutlinedButton(
                                    onClick = {
                                        val intent = Intent(
                                            Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                            Uri.fromParts("package", context.packageName, null)
                                        )
                                        context.startActivity(intent)
                                    },
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text(strings.openSystemSettings)
                                }
                            }
                        }
                    }

                    HorizontalDivider()
                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedButton(
                        onClick = {
                            focusManager.clearFocus(force = true)
                            keyboardController?.hide()
                            onLogout()
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("logout_button"),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Icon(Icons.AutoMirrored.Rounded.Logout, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(strings.logOut)
                    }
                }
            }
        }

        if (showScaleDialog) {
            TravelerScaleDialog(
                postCount = currentUserPostCount,
                strings = strings,
                onDismiss = { showScaleDialog = false }
            )
        }
    }
}

@Composable
private fun SectionPill(
    label: String,
    icon: ImageVector,
    selected: Boolean,
    onClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
        modifier = Modifier
            .clip(RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (selected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.labelMedium,
                color = if (selected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun PermissionItemCard(
    icon: ImageVector,
    title: String,
    granted: Boolean,
    grantedLabel: String,
    grantButtonLabel: String,
    onGrant: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(if (granted) RoadSuccess.copy(alpha = 0.16f) else RoadWarning.copy(alpha = 0.16f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = if (granted) RoadSuccess else RoadWarning,
                    modifier = Modifier.size(18.dp)
                )
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.labelLarge)
                if (granted) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Rounded.CheckCircle,
                            contentDescription = null,
                            tint = RoadSuccess,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(grantedLabel, style = MaterialTheme.typography.bodySmall, color = RoadSuccess)
                    }
                }
            }
            if (!granted) {
                Button(
                    onClick = onGrant,
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(grantButtonLabel, style = MaterialTheme.typography.labelMedium)
                }
            }
        }
    }
}
