package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Block
import androidx.compose.material.icons.rounded.Bookmark
import androidx.compose.material.icons.rounded.BookmarkBorder
import androidx.compose.material.icons.rounded.CameraAlt
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.LocationOn
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.MyLocation
import androidx.compose.material.icons.rounded.PhotoLibrary
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import coil.compose.AsyncImage
import com.example.data.local.PhotoStorageHelper
import com.example.data.local.PostEntity
import com.example.data.local.UserEntity
import com.example.ui.components.TravelerAvatar
import com.example.ui.components.TravelerLevelBadge
import com.example.ui.components.TravelerScaleDialog
import com.example.ui.components.TravelerScaleProfileCard
import com.example.ui.i18n.AppStrings
import com.example.ui.i18n.stringsFor
import com.example.ui.viewmodel.ThumbWayUiState
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CommunityScreen(
    uiState: ThumbWayUiState,
    initialTab: Int,
    onBack: () -> Unit,
    onOpenLocationOnMap: (lat: Double, lng: Double) -> Unit,
    onToggleSavePost: (postId: String) -> Unit,
    onCreatePost: (caption: String, photoUri: Uri?, prePersistedPath: String?, locationName: String?, lat: Double?, lng: Double?) -> Unit,
    onDeletePost: (postId: String) -> Unit,
    onToggleFollow: (userId: String) -> Unit,
    onBlockUser: (userId: String) -> Unit
) {
    val strings = stringsFor(uiState.language)
    var selectedTab by remember(initialTab) { mutableIntStateOf(initialTab.coerceIn(0, 2)) }
    var showCreatePostSheet by remember { mutableStateOf(false) }
    var scaleDialogPostCount by remember { mutableStateOf<Int?>(null) }

    Scaffold(
        topBar = {
            Surface(color = MaterialTheme.colorScheme.background, tonalElevation = 2.dp) {
                Column(modifier = Modifier.statusBarsPadding()) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 8.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = onBack,
                            modifier = Modifier.testTag("community_back_button")
                        ) {
                            Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Back")
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = strings.community,
                            style = MaterialTheme.typography.headlineMedium,
                            modifier = Modifier.weight(1f)
                        )
                    }
                    TabRow(selectedTabIndex = selectedTab) {
                        Tab(
                            selected = selectedTab == 0,
                            onClick = { selectedTab = 0 },
                            text = { Text(strings.followingTab) }
                        )
                        Tab(
                            selected = selectedTab == 1,
                            onClick = { selectedTab = 1 },
                            text = { Text("${strings.savedTab} (${uiState.savedPosts.size})") }
                        )
                        Tab(
                            selected = selectedTab == 2,
                            onClick = { selectedTab = 2 },
                            text = { Text(strings.travelersTab) }
                        )
                    }
                }
            }
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showCreatePostSheet = true },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier.testTag("create_post_button")
            ) {
                Icon(Icons.Rounded.Add, contentDescription = strings.createPost)
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentAlignment = Alignment.TopCenter
        ) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .widthIn(max = 680.dp),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                when (selectedTab) {
                    0 -> {
                        if (uiState.followingFeedPosts.isEmpty()) {
                            item {
                                EmptyCommunityCard(strings.noPostsYet)
                            }
                        } else {
                            items(uiState.followingFeedPosts, key = { it.id }) { post ->
                                val authorPosts = uiState.userPostCounts[post.authorId] ?: 1
                                CommunityPostCard(
                                    post = post,
                                    authorPostCount = authorPosts,
                                    isSaved = post.id in uiState.savedPostIds,
                                    isOwner = post.authorId == uiState.currentUser?.id,
                                    strings = strings,
                                    onToggleSave = { onToggleSavePost(post.id) },
                                    onOpenRankScale = { scaleDialogPostCount = authorPosts },
                                    onLocationClick = {
                                        if (post.latitude != null && post.longitude != null) {
                                            onOpenLocationOnMap(post.latitude, post.longitude)
                                        }
                                    },
                                    onDelete = { onDeletePost(post.id) },
                                    onBlockAuthor = { onBlockUser(post.authorId) }
                                )
                            }
                        }
                    }

                    1 -> {
                        if (uiState.savedPosts.isEmpty()) {
                            item {
                                EmptyCommunityCard(strings.noSavedPostsYet)
                            }
                        } else {
                            items(uiState.savedPosts, key = { it.id }) { post ->
                                val authorPosts = uiState.userPostCounts[post.authorId] ?: 1
                                CommunityPostCard(
                                    post = post,
                                    authorPostCount = authorPosts,
                                    isSaved = true,
                                    isOwner = post.authorId == uiState.currentUser?.id,
                                    strings = strings,
                                    onToggleSave = { onToggleSavePost(post.id) },
                                    onOpenRankScale = { scaleDialogPostCount = authorPosts },
                                    onLocationClick = {
                                        if (post.latitude != null && post.longitude != null) {
                                            onOpenLocationOnMap(post.latitude, post.longitude)
                                        }
                                    },
                                    onDelete = { onDeletePost(post.id) },
                                    onBlockAuthor = { onBlockUser(post.authorId) }
                                )
                            }
                        }
                    }

                    2 -> {
                        val visibleTravelers = uiState.allUsers.filter { it.id !in uiState.blockedIds }
                        items(visibleTravelers, key = { it.id }) { traveler ->
                            val travelerPostCount = uiState.userPostCounts[traveler.id] ?: 0
                            TravelerDirectoryCard(
                                traveler = traveler,
                                postCount = travelerPostCount,
                                isFollowing = traveler.id in uiState.followedIds,
                                strings = strings,
                                onToggleFollow = { onToggleFollow(traveler.id) },
                                onBlock = { onBlockUser(traveler.id) },
                                onOpenRankScale = { scaleDialogPostCount = travelerPostCount },
                                onViewMap = {
                                    if (traveler.latitude != null && traveler.longitude != null) {
                                        onOpenLocationOnMap(traveler.latitude, traveler.longitude)
                                    }
                                }
                            )
                        }
                    }
                }
            }
        }
    }

    if (showCreatePostSheet) {
        val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
        val sheetFocusManager = LocalFocusManager.current
        val sheetKeyboardController = LocalSoftwareKeyboardController.current
        ModalBottomSheet(
            onDismissRequest = {
                sheetFocusManager.clearFocus(force = true)
                sheetKeyboardController?.hide()
                showCreatePostSheet = false
            },
            sheetState = sheetState
        ) {
            CreatePostSheetContent(
                strings = strings,
                currentLat = uiState.liveLocation.latitude,
                currentLng = uiState.liveLocation.longitude,
                currentLocality = uiState.liveLocation.localityLabel,
                onPublish = { caption, photoUri, prePersisted, locName, lat, lng ->
                    sheetFocusManager.clearFocus(force = true)
                    sheetKeyboardController?.hide()
                    onCreatePost(caption, photoUri, prePersisted, locName, lat, lng)
                    showCreatePostSheet = false
                }
            )
        }
    }
    scaleDialogPostCount?.let { count ->
        TravelerScaleDialog(
            postCount = count,
            strings = strings,
            onDismiss = { scaleDialogPostCount = null }
        )
    }
}

@Composable
private fun CommunityPostCard(
    post: PostEntity,
    authorPostCount: Int,
    isSaved: Boolean,
    isOwner: Boolean,
    strings: AppStrings,
    onToggleSave: () -> Unit,
    onOpenRankScale: () -> Unit,
    onLocationClick: () -> Unit,
    onDelete: () -> Unit,
    onBlockAuthor: () -> Unit
) {
    var menuExpanded by remember { mutableStateOf(false) }
    val dateStr = remember(post.createdAt) {
        SimpleDateFormat("MMM d • HH:mm", Locale.getDefault()).format(Date(post.createdAt))
    }

    Card(
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                TravelerAvatar(
                    displayName = post.authorName,
                    avatarUri = post.authorAvatarUri,
                    size = 42.dp
                )
                Spacer(modifier = Modifier.width(10.dp))
                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(2.dp)
                ) {
                    Text(post.authorName, style = MaterialTheme.typography.titleMedium)
                    TravelerLevelBadge(
                        postCount = authorPostCount,
                        strings = strings,
                        compact = true,
                        onClick = onOpenRankScale
                    )
                    Text(dateStr, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }

                IconButton(
                    onClick = onToggleSave,
                    modifier = Modifier.testTag("save_post_button_${post.id}")
                ) {
                    Icon(
                        imageVector = if (isSaved) Icons.Rounded.Bookmark else Icons.Rounded.BookmarkBorder,
                        contentDescription = strings.savedTab,
                        tint = if (isSaved) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Box {
                    IconButton(onClick = { menuExpanded = true }) {
                        Icon(Icons.Rounded.MoreVert, contentDescription = "Options")
                    }
                    DropdownMenu(
                        expanded = menuExpanded,
                        onDismissRequest = { menuExpanded = false }
                    ) {
                        if (isOwner) {
                            DropdownMenuItem(
                                text = { Text(strings.deleteLabel) },
                                leadingIcon = { Icon(Icons.Rounded.Delete, contentDescription = null) },
                                onClick = {
                                    menuExpanded = false
                                    onDelete()
                                }
                            )
                        } else {
                            DropdownMenuItem(
                                text = { Text(strings.blockUser) },
                                leadingIcon = { Icon(Icons.Rounded.Block, contentDescription = null) },
                                onClick = {
                                    menuExpanded = false
                                    onBlockAuthor()
                                }
                            )
                        }
                    }
                }
            }

            if (!post.locationName.isNullOrBlank()) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.65f),
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .clickable(enabled = post.latitude != null && post.longitude != null, onClick = onLocationClick)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.LocationOn,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onPrimaryContainer,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = post.locationName,
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }

            if (!post.photoUri.isNullOrBlank()) {
                AsyncImage(
                    model = post.photoUri,
                    contentDescription = post.caption,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(220.dp)
                        .clip(RoundedCornerShape(16.dp))
                )
            }

            Text(
                text = post.caption,
                style = MaterialTheme.typography.bodyLarge
            )
        }
    }
}

@Composable
private fun TravelerDirectoryCard(
    traveler: UserEntity,
    postCount: Int,
    isFollowing: Boolean,
    strings: AppStrings,
    onToggleFollow: () -> Unit,
    onBlock: () -> Unit,
    onOpenRankScale: () -> Unit,
    onViewMap: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(20.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                TravelerAvatar(
                    displayName = traveler.displayName,
                    avatarUri = traveler.avatarUri,
                    size = 48.dp
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(traveler.displayName, style = MaterialTheme.typography.titleMedium)
                    Text("@${traveler.username}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                if (isFollowing) {
                    OutlinedButton(onClick = onToggleFollow) {
                        Text(strings.following)
                    }
                } else {
                    Button(onClick = onToggleFollow) {
                        Text(strings.follow)
                    }
                }
            }
            Text(
                text = traveler.aboutUs,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            TravelerScaleProfileCard(
                postCount = postCount,
                strings = strings,
                compact = true,
                onOpenScaleDialog = onOpenRankScale
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (traveler.isLocationSharingEnabled && traveler.latitude != null) {
                    FilledTonalButton(onClick = onViewMap, modifier = Modifier.weight(1f)) {
                        Icon(Icons.Rounded.LocationOn, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(strings.viewOnMap, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
                OutlinedButton(onClick = onBlock) {
                    Icon(Icons.Rounded.Block, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(strings.blockUser)
                }
            }
        }
    }
}

@Composable
private fun CreatePostSheetContent(
    strings: AppStrings,
    currentLat: Double,
    currentLng: Double,
    currentLocality: String,
    onPublish: (caption: String, photoUri: Uri?, prePersistedPath: String?, locationName: String?, lat: Double?, lng: Double?) -> Unit
) {
    val context = LocalContext.current
    var caption by remember { mutableStateOf("") }
    var includeLocation by remember { mutableStateOf(true) }
    var locationName by remember { mutableStateOf(currentLocality) }
    var attachCoords by remember { mutableStateOf(true) }
    var pickedPhotoUri by remember { mutableStateOf<Uri?>(null) }
    var capturedPhotoFileUri by remember { mutableStateOf<String?>(null) }
    var pendingCameraContentUri by remember { mutableStateOf<Uri?>(null) }

    val galleryLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            pickedPhotoUri = uri
            capturedPhotoFileUri = null
        }
    }

    val cameraLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.TakePicture()
    ) { success ->
        if (success && pendingCameraContentUri != null) {
            pickedPhotoUri = pendingCameraContentUri
        } else {
            capturedPhotoFileUri = null
        }
    }

    val cameraPermLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            val (contentUri, fileUri) = PhotoStorageHelper.createCameraOutputUri(context)
            pendingCameraContentUri = contentUri
            capturedPhotoFileUri = fileUri
            cameraLauncher.launch(contentUri)
        }
    }

    val postFocusManager = LocalFocusManager.current
    val postKeyboardController = LocalSoftwareKeyboardController.current
    DisposableEffect(Unit) {
        onDispose {
            postFocusManager.clearFocus(force = true)
            postKeyboardController?.hide()
        }
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .imePadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 24.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(strings.createPost, style = MaterialTheme.typography.headlineMedium)

        OutlinedTextField(
            value = caption,
            onValueChange = { caption = it },
            label = { Text(strings.postCaptionHint) },
            minLines = 3,
            maxLines = 6,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("post_caption_input")
        )

        val previewModel = capturedPhotoFileUri ?: pickedPhotoUri
        if (previewModel != null) {
            AsyncImage(
                model = previewModel,
                contentDescription = "Post photo preview",
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp)
                    .clip(RoundedCornerShape(16.dp))
            )
        }

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            FilledTonalButton(
                onClick = {
                    galleryLauncher.launch(
                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                    )
                },
                modifier = Modifier.weight(1f).height(48.dp)
            ) {
                Icon(Icons.Rounded.PhotoLibrary, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(strings.attachPhoto)
            }
            OutlinedButton(
                onClick = {
                    val hasCam = ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) ==
                        PackageManager.PERMISSION_GRANTED
                    if (hasCam) {
                        val (contentUri, fileUri) = PhotoStorageHelper.createCameraOutputUri(context)
                        pendingCameraContentUri = contentUri
                        capturedPhotoFileUri = fileUri
                        cameraLauncher.launch(contentUri)
                    } else {
                        cameraPermLauncher.launch(Manifest.permission.CAMERA)
                    }
                },
                modifier = Modifier.weight(1f).height(48.dp)
            ) {
                Icon(Icons.Rounded.CameraAlt, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(strings.takePhoto)
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Rounded.MyLocation, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            Spacer(modifier = Modifier.width(8.dp))
            Text(strings.specifyLocation, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
            Switch(checked = includeLocation, onCheckedChange = { includeLocation = it })
        }

        if (includeLocation) {
            OutlinedTextField(
                value = locationName,
                onValueChange = { locationName = it },
                label = { Text(strings.specifyLocation) },
                singleLine = true,
                trailingIcon = {
                    IconButton(onClick = {
                        locationName = currentLocality
                        attachCoords = true
                    }) {
                        Icon(Icons.Rounded.MyLocation, contentDescription = strings.useCurrentLocation)
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("post_location_input")
            )
        }

        Button(
            onClick = {
                onPublish(
                    caption,
                    if (capturedPhotoFileUri == null) pickedPhotoUri else null,
                    capturedPhotoFileUri,
                    if (includeLocation) locationName.ifBlank { currentLocality } else null,
                    if (includeLocation && attachCoords) currentLat else null,
                    if (includeLocation && attachCoords) currentLng else null
                )
            },
            enabled = caption.isNotBlank() || previewModel != null,
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp)
                .testTag("publish_post_button")
        ) {
            Text(strings.publish)
        }
        Spacer(modifier = Modifier.height(16.dp))
    }
}

@Composable
private fun EmptyCommunityCard(message: String) {
    Surface(
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
        modifier = Modifier.fillMaxWidth()
    ) {
        Text(
            text = message,
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(20.dp)
        )
    }
}
