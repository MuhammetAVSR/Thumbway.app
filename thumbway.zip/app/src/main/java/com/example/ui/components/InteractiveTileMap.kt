package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.LocalCafe
import androidx.compose.material.icons.rounded.LocalGasStation
import androidx.compose.material.icons.rounded.MyLocation
import androidx.compose.material.icons.rounded.PersonPinCircle
import androidx.compose.material.icons.rounded.PinDrop
import androidx.compose.material.icons.rounded.Restaurant
import androidx.compose.material.icons.rounded.Storefront
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import coil.request.CachePolicy
import coil.request.ImageRequest
import com.example.data.local.MapNoteEntity
import com.example.data.local.UserEntity
import com.example.data.location.RouteStop
import com.example.data.remote.BusinessCategory
import com.example.data.remote.NearbyBusiness
import com.example.data.remote.PlaceSearchResult
import com.example.data.remote.WeatherPointOverlay
import com.example.ui.screens.weatherIconForCode
import com.example.ui.screens.weatherSeverityColor
import com.google.android.gms.maps.model.LatLng
import kotlin.math.PI
import kotlin.math.atan
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.ln
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sinh
import kotlin.math.tan

@Composable
fun InteractiveTileMap(
    centerLat: Double,
    centerLng: Double,
    zoom: Float,
    liveLat: Double,
    liveLng: Double,
    tsmLat: Double,
    tsmLng: Double,
    showFollowers: Boolean,
    followers: List<UserEntity>,
    showBusinesses: Boolean,
    businesses: List<NearbyBusiness>,
    showNotes: Boolean,
    notes: List<MapNoteEntity>,
    searchResults: List<PlaceSearchResult>,
    pendingPin: LatLng?,
    measuredTarget: LatLng? = null,
    measuredDistanceLabel: String? = null,
    routeStops: List<RouteStop> = emptyList(),
    showWeather: Boolean = false,
    weatherPoints: List<WeatherPointOverlay> = emptyList(),
    radarTileUrlTemplate: String? = null,
    onWeatherPointClick: (WeatherPointOverlay) -> Unit = {},
    onPanZoom: (newLat: Double, newLng: Double, newZoom: Float) -> Unit,
    onTapCoordinate: (LatLng) -> Unit,
    onFollowerClick: (UserEntity) -> Unit,
    onBusinessClick: (NearbyBusiness) -> Unit,
    onNoteClick: (MapNoteEntity) -> Unit,
    onSearchResultClick: (PlaceSearchResult) -> Unit,
    noteBubbleOverlay: @Composable (note: MapNoteEntity, screenX: Int, screenY: Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val density = LocalDensity.current

    val currentCenterLat by rememberUpdatedState(centerLat)
    val currentCenterLng by rememberUpdatedState(centerLng)
    val currentZoom by rememberUpdatedState(zoom)
    val currentOnPanZoom by rememberUpdatedState(onPanZoom)
    val currentOnTap by rememberUpdatedState(onTapCoordinate)

    BoxWithConstraints(
        modifier = modifier
            .fillMaxSize()
            .clipToBounds()
            .background(Color(0xFFE7EFEA))
    ) {
        val widthPx = with(density) { maxWidth.toPx() }
        val heightPx = with(density) { maxHeight.toPx() }
        val currentWidthPx by rememberUpdatedState(widthPx)
        val currentHeightPx by rememberUpdatedState(heightPx)

        val tileZoom = zoom.roundToInt().coerceIn(3, 18)
        val tileBasePx = with(density) { 256.dp.toPx() }
        val tileSizePx = tileBasePx * 2f.pow(zoom - tileZoom)

        val centerTileX = lngToTileX(centerLng, tileZoom)
        val centerTileY = latToTileY(centerLat, tileZoom)

        val minTileOffsetX = floor(-(widthPx / 2f) / tileSizePx).toInt() - 1
        val maxTileOffsetX = floor((widthPx / 2f) / tileSizePx).toInt() + 1
        val minTileOffsetY = floor(-(heightPx / 2f) / tileSizePx).toInt() - 1
        val maxTileOffsetY = floor((heightPx / 2f) / tileSizePx).toInt() + 1

        val baseTileX = floor(centerTileX).toInt()
        val baseTileY = floor(centerTileY).toInt()
        val fracX = centerTileX - baseTileX
        val fracY = centerTileY - baseTileY
        val maxIndex = (1 shl tileZoom) - 1

        Box(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    detectTapGestures { offset ->
                        val z = currentZoom
                        val tz = z.roundToInt().coerceIn(3, 18)
                        val tSizePx = tileBasePx * 2f.pow(z - tz)
                        val cTileX = lngToTileX(currentCenterLng, tz)
                        val cTileY = latToTileY(currentCenterLat, tz)
                        val worldDx = (offset.x - currentWidthPx / 2f) / tSizePx
                        val worldDy = (offset.y - currentHeightPx / 2f) / tSizePx
                        val tappedLat = tileYToLat(cTileY + worldDy, tz)
                        val tappedLng = tileXToLng(cTileX + worldDx, tz)
                        currentOnTap(LatLng(tappedLat, tappedLng))
                    }
                }
                .pointerInput(Unit) {
                    detectTransformGestures { _, pan, zoomChange, _ ->
                        val z = currentZoom
                        val tz = z.roundToInt().coerceIn(3, 18)
                        val nextZoom = if (zoomChange != 1f) {
                            (z + ln(zoomChange.toDouble()).toFloat() / ln(2f)).coerceIn(3f, 18f)
                        } else {
                            z
                        }
                        val currentTilePx = tileBasePx * 2f.pow(z - tz)
                        val cTileX = lngToTileX(currentCenterLng, tz)
                        val cTileY = latToTileY(currentCenterLat, tz)
                        val nextTileX = cTileX - pan.x / currentTilePx
                        val nextTileY = cTileY - pan.y / currentTilePx
                        val nextLat = tileYToLat(nextTileY, tz).coerceIn(-85.0, 85.0)
                        val nextLng = tileXToLng(nextTileX, tz)
                        currentOnPanZoom(nextLat, nextLng, nextZoom)
                    }
                }
        ) {
            // OpenStreetMap Raster Tiles
            val tileSizeDp = with(density) { (tileSizePx + 1f).toDp() }
            for (dx in minTileOffsetX..maxTileOffsetX) {
                for (dy in minTileOffsetY..maxTileOffsetY) {
                    val tx = ((baseTileX + dx) % (maxIndex + 1) + (maxIndex + 1)) % (maxIndex + 1)
                    val ty = baseTileY + dy
                    if (ty !in 0..maxIndex) continue

                    val screenX = widthPx / 2f + (dx - fracX) * tileSizePx
                    val screenY = heightPx / 2f + (dy - fracY) * tileSizePx
                    val url = "https://tile.openstreetmap.org/$tileZoom/$tx/$ty.png"

                    key(url) {
                        val request = remember(url) {
                            ImageRequest.Builder(context)
                                .data(url)
                                .size(256, 256)
                                .memoryCacheKey(url)
                                .diskCacheKey(url)
                                .memoryCachePolicy(CachePolicy.ENABLED)
                                .diskCachePolicy(CachePolicy.ENABLED)
                                .addHeader("User-Agent", "ThumbWay-Android/1.0")
                                .crossfade(false)
                                .build()
                        }
                        AsyncImage(
                            model = request,
                            contentDescription = null,
                            contentScale = ContentScale.FillBounds,
                            modifier = Modifier
                                .offset { IntOffset(screenX.roundToInt(), screenY.roundToInt()) }
                                .size(tileSizeDp)
                        )

                        // Real-time RainViewer precipitation radar tile overlay
                        if (showWeather && !radarTileUrlTemplate.isNullOrBlank() && tileZoom <= 12) {
                            val radarUrl = radarTileUrlTemplate
                                .replace("{z}", tileZoom.toString())
                                .replace("{x}", tx.toString())
                                .replace("{y}", ty.toString())
                            val radarRequest = remember(radarUrl) {
                                ImageRequest.Builder(context)
                                    .data(radarUrl)
                                    .size(256, 256)
                                    .memoryCacheKey(radarUrl)
                                    .diskCacheKey(radarUrl)
                                    .memoryCachePolicy(CachePolicy.ENABLED)
                                    .diskCachePolicy(CachePolicy.ENABLED)
                                    .crossfade(false)
                                    .build()
                            }
                            AsyncImage(
                                model = radarRequest,
                                contentDescription = null,
                                contentScale = ContentScale.FillBounds,
                                modifier = Modifier
                                    .offset { IntOffset(screenX.roundToInt(), screenY.roundToInt()) }
                                    .size(tileSizeDp)
                                    .alpha(0.5f)
                            )
                        }
                    }
                }
            }

            fun project(lat: Double, lng: Double): Offset {
                val tx = lngToTileX(lng, tileZoom)
                val ty = latToTileY(lat, tileZoom)
                val sx = widthPx / 2f + ((tx - centerTileX) * tileSizePx).toFloat()
                val sy = heightPx / 2f + ((ty - centerTileY) * tileSizePx).toFloat()
                return Offset(sx, sy)
            }

            // Nearby Business Markers
            if (showBusinesses) {
                businesses.forEach { biz ->
                    key(biz.id) {
                        val pt = project(biz.latitude, biz.longitude)
                        if (pt.x in -80f..(widthPx + 80f) && pt.y in -80f..(heightPx + 80f)) {
                            val icon = when (biz.category) {
                                BusinessCategory.FUEL -> Icons.Rounded.LocalGasStation
                                BusinessCategory.CAFE -> Icons.Rounded.LocalCafe
                                BusinessCategory.RESTAURANT -> Icons.Rounded.Restaurant
                                else -> Icons.Rounded.Storefront
                            }
                            Surface(
                                shape = CircleShape,
                                color = MaterialTheme.colorScheme.secondary,
                                shadowElevation = 4.dp,
                                modifier = Modifier
                                    .offset { IntOffset((pt.x - 16.dp.toPx()).roundToInt(), (pt.y - 16.dp.toPx()).roundToInt()) }
                                    .size(32.dp)
                                    .clip(CircleShape)
                                    .clickable { onBusinessClick(biz) }
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(icon, contentDescription = biz.name, tint = Color.White, modifier = Modifier.size(18.dp))
                                }
                            }
                        }
                    }
                }
            }

            // Followed Travelers
            if (showFollowers) {
                followers.forEach { traveler ->
                    val lat = traveler.latitude ?: return@forEach
                    val lng = traveler.longitude ?: return@forEach
                    key(traveler.id) {
                        val pt = project(lat, lng)
                        if (pt.x in -80f..(widthPx + 80f) && pt.y in -80f..(heightPx + 80f)) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier
                                    .offset { IntOffset((pt.x - 36.dp.toPx()).roundToInt(), (pt.y - 44.dp.toPx()).roundToInt()) }
                                    .clickable { onFollowerClick(traveler) }
                            ) {
                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    color = MaterialTheme.colorScheme.tertiary,
                                    shadowElevation = 4.dp
                                ) {
                                    Text(
                                        text = traveler.displayName,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onTertiary,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                                Icon(
                                    imageVector = Icons.Rounded.PersonPinCircle,
                                    contentDescription = traveler.displayName,
                                    tint = MaterialTheme.colorScheme.tertiary,
                                    modifier = Modifier.size(28.dp)
                                )
                            }
                        }
                    }
                }
            }

            // Note Pins + Floating Notification Bubbles
            if (showNotes) {
                notes.forEach { note ->
                    key(note.id) {
                        val pt = project(note.latitude, note.longitude)
                        if (pt.x in -150f..(widthPx + 150f) && pt.y in -150f..(heightPx + 150f)) {
                            Box(
                                modifier = Modifier
                                    .offset { IntOffset((pt.x - 8.dp.toPx()).roundToInt(), (pt.y - 8.dp.toPx()).roundToInt()) }
                                    .size(16.dp)
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.error)
                                    .border(2.dp, Color.White, CircleShape)
                                    .clickable { onNoteClick(note) }
                            )
                            noteBubbleOverlay(note, pt.x.roundToInt(), pt.y.roundToInt())
                        }
                    }
                }
            }

            // Search Result Pins
            searchResults.forEach { place ->
                key(place.id) {
                    val pt = project(place.latitude, place.longitude)
                    if (pt.x in -80f..(widthPx + 80f) && pt.y in -80f..(heightPx + 80f)) {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = Color(0xFF6A1B9A),
                            shadowElevation = 6.dp,
                            modifier = Modifier
                                .offset { IntOffset((pt.x - 42.dp.toPx()).roundToInt(), (pt.y - 34.dp.toPx()).roundToInt()) }
                                .clip(RoundedCornerShape(12.dp))
                                .clickable { onSearchResultClick(place) }
                        ) {
                            Text(
                                text = place.name,
                                style = MaterialTheme.typography.labelSmall,
                                color = Color.White,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }
                }
            }

            // Multi-Stop Travel Route Path + Numbered Stop Markers
            if (routeStops.isNotEmpty()) {
                val routePoints = routeStops.map { project(it.latitude, it.longitude) }
                val routeColor = Color(0xFF00796B)
                if (routePoints.size >= 2) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val routePath = Path().apply {
                            moveTo(routePoints.first().x, routePoints.first().y)
                            for (i in 1 until routePoints.size) {
                                lineTo(routePoints[i].x, routePoints[i].y)
                            }
                        }
                        drawPath(
                            path = routePath,
                            color = Color.White.copy(alpha = 0.9f),
                            style = Stroke(width = 9.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
                        )
                        drawPath(
                            path = routePath,
                            color = routeColor,
                            style = Stroke(width = 5.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
                        )
                    }
                }
                routeStops.forEachIndexed { index, stop ->
                    key(stop.id) {
                        val pt = routePoints[index]
                        if (pt.x in -60f..(widthPx + 60f) && pt.y in -60f..(heightPx + 60f)) {
                            Surface(
                                shape = CircleShape,
                                color = when (index) {
                                    0 -> Color(0xFF2E7D32)
                                    routeStops.lastIndex -> Color(0xFFD84315)
                                    else -> routeColor
                                },
                                shadowElevation = 6.dp,
                                modifier = Modifier
                                    .offset { IntOffset((pt.x - 14.dp.toPx()).roundToInt(), (pt.y - 14.dp.toPx()).roundToInt()) }
                                    .size(28.dp)
                                    .border(2.dp, Color.White, CircleShape)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Text(
                                        text = "${index + 1}",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Distance Measurement Line + Endpoint + Midpoint Label
            measuredTarget?.let { target ->
                val originPt = project(liveLat, liveLng)
                val targetPt = project(target.latitude, target.longitude)
                val lineColor = MaterialTheme.colorScheme.primary
                Canvas(modifier = Modifier.fillMaxSize()) {
                    drawLine(
                        color = Color.White.copy(alpha = 0.85f),
                        start = originPt,
                        end = targetPt,
                        strokeWidth = 7.dp.toPx(),
                        cap = StrokeCap.Round,
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(22f, 16f), 0f)
                    )
                    drawLine(
                        color = lineColor,
                        start = originPt,
                        end = targetPt,
                        strokeWidth = 4.dp.toPx(),
                        cap = StrokeCap.Round,
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(22f, 16f), 0f)
                    )
                    drawCircle(
                        color = Color.White,
                        radius = 10.dp.toPx(),
                        center = targetPt
                    )
                    drawCircle(
                        color = lineColor,
                        radius = 6.dp.toPx(),
                        center = targetPt
                    )
                }
                if (!measuredDistanceLabel.isNullOrBlank()) {
                    val midX = (originPt.x + targetPt.x) / 2f
                    val midY = (originPt.y + targetPt.y) / 2f
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.primary,
                        shadowElevation = 6.dp,
                        modifier = Modifier.offset {
                            IntOffset(
                                (midX - 42.dp.toPx()).roundToInt(),
                                (midY - 14.dp.toPx()).roundToInt()
                            )
                        }
                    ) {
                        Text(
                            text = measuredDistanceLabel,
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onPrimary,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }
                }
            }

            // TSM Location Marker
            val tsmPt = project(tsmLat, tsmLng)
            Icon(
                imageVector = Icons.Rounded.PinDrop,
                contentDescription = "TSM Location",
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier
                    .offset { IntOffset((tsmPt.x - 18.dp.toPx()).roundToInt(), (tsmPt.y - 34.dp.toPx()).roundToInt()) }
                    .size(36.dp)
            )

            // Live GPS Dot
            val livePt = project(liveLat, liveLng)
            Surface(
                shape = CircleShape,
                color = Color(0xFF1E88E5),
                shadowElevation = 4.dp,
                modifier = Modifier
                    .offset { IntOffset((livePt.x - 12.dp.toPx()).roundToInt(), (livePt.y - 12.dp.toPx()).roundToInt()) }
                    .size(24.dp)
                    .border(3.dp, Color.White, CircleShape)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.Rounded.MyLocation,
                        contentDescription = "My Live Location",
                        tint = Color.White,
                        modifier = Modifier.size(14.dp)
                    )
                }
            }

            // Pending Selected Pin
            pendingPin?.let { pin ->
                val pinPt = project(pin.latitude, pin.longitude)
                Icon(
                    imageVector = Icons.Rounded.PinDrop,
                    contentDescription = "Selected Spot",
                    tint = Color(0xFFE65100),
                    modifier = Modifier
                        .offset { IntOffset((pinPt.x - 20.dp.toPx()).roundToInt(), (pinPt.y - 38.dp.toPx()).roundToInt()) }
                        .size(40.dp)
                )
            }

            // Real-Time Weather Point Overlays
            if (showWeather) {
                weatherPoints.forEach { wp ->
                    key(wp.id) {
                        val pt = project(wp.latitude, wp.longitude)
                        if (pt.x in -100f..(widthPx + 100f) && pt.y in -100f..(heightPx + 100f)) {
                            val accent = weatherSeverityColor(wp.severity)
                            Surface(
                                shape = RoundedCornerShape(16.dp),
                                color = MaterialTheme.colorScheme.surface.copy(alpha = 0.94f),
                                shadowElevation = 6.dp,
                                modifier = Modifier
                                    .offset {
                                        IntOffset(
                                            (pt.x - 42.dp.toPx()).roundToInt(),
                                            (pt.y - 44.dp.toPx()).roundToInt()
                                        )
                                    }
                                    .clip(RoundedCornerShape(16.dp))
                                    .border(1.5.dp, accent, RoundedCornerShape(16.dp))
                                    .clickable { onWeatherPointClick(wp) }
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = weatherIconForCode(wp.weatherCode, wp.isDay),
                                        contentDescription = wp.conditionLabel,
                                        tint = accent,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "${wp.temperatureC.roundToInt()}°C",
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun lngToTileX(lng: Double, zoom: Int): Double =
    (lng + 180.0) / 360.0 * (1 shl zoom)

private fun latToTileY(lat: Double, zoom: Int): Double {
    val rad = Math.toRadians(lat.coerceIn(-85.0511, 85.0511))
    return (1.0 - ln(tan(rad) + 1.0 / cos(rad)) / PI) / 2.0 * (1 shl zoom)
}

private fun tileXToLng(tileX: Double, zoom: Int): Double =
    tileX / (1 shl zoom) * 360.0 - 180.0

private fun tileYToLat(tileY: Double, zoom: Int): Double {
    val n = PI - 2.0 * PI * tileY / (1 shl zoom)
    return Math.toDegrees(atan(sinh(n)))
}
